#!/usr/bin/env python3
# coding=utf-8
# Copyright © Huawei Technologies Co., Ltd. 2023-2023. All rights reserved.
#
#  this file licensed under the Mulan PSL v2.
#  You can use this software according to the terms and conditions of the Mulan PSL v2.
#  You may obtain a copy of Mulan PSL v2 at: http: //license.coscl.org.cn/MulanPSL2
#
#  THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
#  IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
#  PURPOSE.
#  See the Mulan PSL v2 for more details.
#
#  Author: xuhaijun
#  Create: 2023-03-21

import subprocess
import time
import shutil
import os
import sys
import json
import re
import stat
import xml.etree.ElementTree as ET
from io import FileIO
from io import TextIOWrapper

import yaml
from bmcgo import errors

from bmcgo import misc
from bmcgo_pro.utils.tools import Tools

tools = Tools("xml_codegen")
log = tools.log


def upper_name(stru):
    words = []
    match = re.match('[^A-Z]+', stru)
    if (match):
        words.append(match.group())
    split = re.findall('[A-Z][^A-Z]*', stru)
    last = ""
    for i in split:
        i = i.strip('_')
        if i.upper() == i:
            last = last + i
            continue
        if last != "":
            words.append(last)
            last = ""
        words.append(i)
    if last != "":
        words.append(last)
    return "_".join(words).upper()


class Annotation():
    def __init__(self, an: ET.Element, prefix: str = ""):
        prefix = prefix + "    "
        self.name = an.get("name")
        self.value = an.get("value")
        log.debug("{}Annotaion, name: {}, value: {}".format(
            prefix, self.name, self.value))

    def is_private_prop(self):
        if self.name == "bmc.kepler.Dbus.Property.Private" and self.value.lower() == "true":
            return True
        else:
            return False

    def is_private_interface(self):
        return self.name == "bmc.kepler.Dbus.Property.Private" and self.value.lower() == "true"

    def is_emit_changed_signal(self):
        return self.name == "org.freedesktop.DBus.Property.EmitsChangedSignal"

    def is_deprecated(self):
        return self.name == "org.freedesktop.DBus.Deprecated"

    def is_deprecated(self):
        return self.name == "org.freedesktop.DBus.Deprecated"

    def get_privilege(self, key="bmc.kepler.Security.Privileges"):
        if self.name != key:
            return ""
        splits = self.value.split(",", -1)
        privilege = []
        for split in splits:
            split = split.strip()
            if split == "UserMgmt":
                privilege.append("PRI_USER_MGMT")
            elif split == "BasicSetting":
                privilege.append("PRI_BASIC_SETTING")
            elif split == "KVMMgmt":
                privilege.append("PRI_KVM_MGMT")
            elif split == "VMMMgmt":
                privilege.append("PRI_VMM_MGMT")
            elif split == "SecurityMgmt":
                privilege.append("PRI_SECURITY_MGMT")
            elif split == "PowerMgmt":
                privilege.append("PRI_POWER_MGMT")
            elif split == "DiagnoseMgmt":
                privilege.append("PRI_DIAGNOSE_MGMT")
            elif split == "ReadOnly":
                privilege.append("PRI_READ_ONLY")
            elif split == "ConfigureSelf":
                privilege.append("PRI_CONFIG_SELF")
        if not privilege:
            return ""
        return " | ".join(privilege)

    def format_src(self):
        lines = []
        lines.append("{")
        lines.append("    .ref_count = -1,")
        lines.append(f"    .key = \"{self.name}\",")
        lines.append(f"    .value=\"{self.value}\",")
        lines.append("    .annotations = NULL,")
        lines.append("},")
        return lines


def format_annotations(annotations, interface: str, subname: str, src_fd: FileIO):
    annotation_name = "NULL"
    if annotations:
        annotation_name = f"{interface}_{subname}_annotations"
        src_fd.write(
            f"static GDBusAnnotationInfo {annotation_name}_i[] = {{\n")
        for annotation in annotations:
            lines = annotation.format_src()
            for line in lines:
                src_fd.write(f"    {line}\n")
        src_fd.write("};\n\n")
        src_fd.write(f"static GDBusAnnotationInfo *{annotation_name}[] = {{\n")
        index = 0
        for _ in annotations:
            src_fd.write(f"    &{annotation_name}_i[{index}], /* annotation id: {index} */\n")
            index = index + 1
        src_fd.write("    NULL,\n};\n\n")
    return annotation_name


class PropertyMap():
    def __init__(self, write_func, args_type, args_proto, args_next, args_in_declear,
                 args_in_free, args_out_free, args_out_pack, args_out_declear,
                 args_write_remote_declear, args_read_remote_declear):
        self.write_func = write_func
        self.type = args_type
        self.args_proto = args_proto
        self.args_next = args_next
        self.args_in_declear = args_in_declear
        self.args_out_declear = args_out_declear
        self.args_in_free = args_in_free
        self.args_out_free = args_out_free
        self.args_out_pack = args_out_pack
        self.args_write_remote_declear = args_write_remote_declear
        self.args_read_remote_declear = args_read_remote_declear


class Property():
    type_map = {
        "b": PropertyMap(write_func="boolean", args_type="gboolean ", args_proto="gboolean val", args_next="val",
                         args_write_remote_declear="GVariant *out_arg_ = g_variant_new_boolean(val);",
                         args_read_remote_declear="*<arg_name> = g_variant_get_boolean(_out_val);",
                         args_in_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                          "gboolean <arg_name> = g_variant_get_boolean(in_arg_);",
                                          "g_variant_unref(in_arg_);"],
                         args_out_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                           "*<arg_name> = g_variant_get_boolean(in_arg_);",
                                           "g_variant_unref(in_arg_);"],
                         args_in_free=[],
                         args_out_free=[],
                         args_out_pack=["g_variant_builder_add_value(&builder, g_variant_new_boolean(<arg_name>));"]),
        "y": PropertyMap(write_func="uint8", args_type="guint8 ", args_proto="guint8 val", args_next="val",
                         args_write_remote_declear="GVariant *out_arg_ = g_variant_new_byte(val);",
                         args_read_remote_declear="*<arg_name> = g_variant_get_byte(_out_val);",
                         args_in_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                          "guint8 <arg_name> = g_variant_get_byte(in_arg_);",
                                          "g_variant_unref(in_arg_);"],
                         args_out_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                           "*<arg_name> = g_variant_get_byte(in_arg_);",
                                           "g_variant_unref(in_arg_);"],
                         args_in_free=[],
                         args_out_free=[],
                         args_out_pack=["g_variant_builder_add_value(&builder, g_variant_new_byte(<arg_name>));"]),
        "n": PropertyMap(write_func="int16", args_type="gint16 ", args_proto="gint16 val", args_next="val",
                         args_write_remote_declear="GVariant *out_arg_ = g_variant_new_int16(val);",
                         args_read_remote_declear="*<arg_name> = g_variant_get_int16(_out_val);",
                         args_in_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                          "gint16 <arg_name> = g_variant_get_int16(in_arg_);",
                                          "g_variant_unref(in_arg_);"],
                         args_out_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                           "*<arg_name> = g_variant_get_int16(in_arg_);",
                                           "g_variant_unref(in_arg_);"],
                         args_in_free=[],
                         args_out_free=[],
                         args_out_pack=["g_variant_builder_add_value(&builder, g_variant_new_int16(<arg_name>));"]),
        "q": PropertyMap(write_func="uint16", args_type="guint16 ", args_proto="guint16 val", args_next="val",
                         args_write_remote_declear="GVariant *out_arg_ = g_variant_new_uint16(val);",
                         args_read_remote_declear="*<arg_name> = g_variant_get_uint16(_out_val);",
                         args_in_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                          "guint16 <arg_name> = g_variant_get_uint16(in_arg_);",
                                          "g_variant_unref(in_arg_);"],
                         args_out_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                           "*<arg_name> = g_variant_get_uint16(in_arg_);",
                                           "g_variant_unref(in_arg_);"],
                         args_in_free=[],
                         args_out_free=[],
                         args_out_pack=["g_variant_builder_add_value(&builder, g_variant_new_uint16(<arg_name>));"]),
        "i": PropertyMap(write_func="int32", args_type="gint32 ", args_proto="gint32 val", args_next="val",
                         args_write_remote_declear="GVariant *out_arg_ = g_variant_new_int32(val);",
                         args_read_remote_declear="*<arg_name> = g_variant_get_int32(_out_val);",
                         args_in_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                          "gint32 <arg_name> = g_variant_get_int32(in_arg_);",
                                          "g_variant_unref(in_arg_);"],
                         args_out_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                           "*<arg_name> = g_variant_get_int32(in_arg_);",
                                           "g_variant_unref(in_arg_);"],
                         args_in_free=[],
                         args_out_free=[],
                         args_out_pack=["g_variant_builder_add_value(&builder, g_variant_new_int32(<arg_name>));"]),
        "u": PropertyMap(write_func="uint32", args_type="guint32 ", args_proto="guint32 val", args_next="val",
                         args_write_remote_declear="GVariant *out_arg_ = g_variant_new_uint32(val);",
                         args_read_remote_declear="*<arg_name> = g_variant_get_uint32(_out_val);",
                         args_in_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                          "guint32 <arg_name> = g_variant_get_uint32(in_arg_);",
                                          "g_variant_unref(in_arg_);"],
                         args_out_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                           "*<arg_name> = g_variant_get_uint32(in_arg_);",
                                           "g_variant_unref(in_arg_);"],
                         args_in_free=[],
                         args_out_free=[],
                         args_out_pack=["g_variant_builder_add_value(&builder, g_variant_new_uint32(<arg_name>));"]),
        "x": PropertyMap(write_func="int64", args_type="gint64 ", args_proto="gint64 val", args_next="val",
                         args_write_remote_declear="GVariant *out_arg_ = g_variant_new_int64(val);",
                         args_read_remote_declear="*<arg_name> = g_variant_get_int64(_out_val);",
                         args_in_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                          "gint64 <arg_name> = g_variant_get_int64(in_arg_);",
                                          "g_variant_unref(in_arg_);"],
                         args_out_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                           "*<arg_name> = g_variant_get_int64(in_arg_);",
                                           "g_variant_unref(in_arg_);"],
                         args_in_free=[],
                         args_out_free=[],
                         args_out_pack=["g_variant_builder_add_value(&builder, g_variant_new_int64(<arg_name>));"]),
        "t": PropertyMap(write_func="uint64", args_type="guint64 ", args_proto="guint64 val", args_next="val",
                         args_write_remote_declear="GVariant *out_arg_ = g_variant_new_uint64(val);",
                         args_read_remote_declear="*<arg_name> = g_variant_get_uint64(_out_val);",
                         args_in_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                          "guint64 <arg_name> = g_variant_get_uint64(in_arg_);",
                                          "g_variant_unref(in_arg_);"],
                         args_out_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                           "*<arg_name> = g_variant_get_uint64(in_arg_);",
                                           "g_variant_unref(in_arg_);"],
                         args_in_free=[],
                         args_out_free=[],
                         args_out_pack=["g_variant_builder_add_value(&builder, g_variant_new_uint64(<arg_name>));"]),
        "d": PropertyMap(write_func="double", args_type="gdouble ", args_proto="gdouble val", args_next="val",
                         args_write_remote_declear="GVariant *out_arg_ = g_variant_new_double(val);",
                         args_read_remote_declear="*<arg_name> = g_variant_get_double(_out_val);",
                         args_in_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                          "gdouble <arg_name> = g_variant_get_double(in_arg_);",
                                          "g_variant_unref(in_arg_);"],
                         args_out_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                           "*<arg_name> = g_variant_get_double(in_arg_);",
                                           "g_variant_unref(in_arg_);"],
                         args_in_free=[],
                         args_out_free=[],
                         args_out_pack=["g_variant_builder_add_value(&builder, g_variant_new_double(<arg_name>));"]),
        "h": PropertyMap(write_func="handle", args_type="gint32 ", args_proto="gint32 val", args_next="val",
                         args_write_remote_declear="GVariant *out_arg_ = g_variant_new_handle(val);",
                         args_read_remote_declear="*<arg_name> = g_variant_get_handle(_out_val);",
                         args_in_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                          "gint32 <arg_name> = g_variant_get_handle(in_arg_);",
                                          "g_variant_unref(in_arg_);"],
                         args_out_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                           "*<arg_name> = g_variant_get_handle(in_arg_);",
                                           "g_variant_unref(in_arg_);"],
                         args_in_free=[],
                         args_out_free=[],
                         args_out_pack=["g_variant_builder_add_value(&builder, g_variant_new_handle(<arg_name>));"]),
        "s": PropertyMap(write_func="string", args_type="gchar *", args_proto="const gchar *val", args_next="val",
                         args_write_remote_declear="GVariant *out_arg_ = g_variant_new_string(val);",
                         args_read_remote_declear="*<arg_name> = g_strdup(g_variant_get_string(_out_val, NULL));\n",
                         args_in_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                          "gchar *<arg_name> = g_strdup(g_variant_get_string(in_arg_, NULL));",
                                          "g_variant_unref(in_arg_);"],
                         args_out_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                           "*<arg_name> = g_strdup(g_variant_get_string(in_arg_, NULL));",
                                           "g_variant_unref(in_arg_);"],
                         args_in_free=["g_free(<arg_name>);"],
                         args_out_free=["g_free(<arg_name>);"],
                         args_out_pack=["g_variant_builder_add_value(&builder, g_variant_new_string(<arg_name> " +
                                        "? <arg_name> : \"\"));"]),
        "o": PropertyMap(write_func="object_path", args_type="gchar *", args_proto="const gchar *val", args_next="val",
                         args_write_remote_declear="GVariant *out_arg_ = g_variant_new_object_path(val);",
                         args_read_remote_declear="*<arg_name> = g_strdup(g_variant_get_string(_out_val, NULL));\n",
                         args_in_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                          "gchar *<arg_name> = g_strdup(g_variant_get_string(in_arg_, NULL));",
                                          "g_variant_unref(in_arg_);"],
                         args_out_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                           "*<arg_name> = g_strdup(g_variant_get_string(in_arg_, NULL));",
                                           "g_variant_unref(in_arg_);"],
                         args_in_free=["g_free(<arg_name>);"],
                         args_out_free=["g_free(<arg_name>);"],
                         args_out_pack=["g_variant_builder_add_value(&builder, g_variant_new_object_path(<arg_name> " +
                                        "? <arg_name> : \"\"));"]),
        "g": PropertyMap(write_func="signature", args_type="gchar *", args_proto="const gchar *val", args_next="val",
                         args_write_remote_declear="GVariant *out_arg_ = g_variant_new_signature(val);",
                         args_read_remote_declear="*<arg_name> = g_strdup(g_variant_get_string(_out_val, NULL));\n",
                         args_in_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                          "gchar *<arg_name> = g_strdup(g_variant_get_string(in_arg_, NULL));",
                                          "g_variant_unref(in_arg_);"],
                         args_out_declear=["in_arg_ = g_variant_get_child_value(parameters, arg_id++);",
                                           "*<arg_name> = g_strdup(g_variant_get_string(in_arg_, NULL));",
                                           "g_variant_unref(in_arg_);"],
                         args_in_free=["g_free(<arg_name>);"],
                         args_out_free=["g_free(<arg_name>);"],
                         args_out_pack=["g_variant_builder_add_value(&builder, g_variant_new_signature(<arg_name> " +
                                        "? <arg_name> : \"\"));"]),
        "ab": PropertyMap(write_func="array_boolean", args_type="gboolean *", args_proto="gint n, gboolean *val",
                          args_next="n, val",
                          args_write_remote_declear="GVariant *out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"b\", n, val);",
                          args_read_remote_declear="GET_BASIC_TYPE_ARRAY" +
                            "(_out_val, *n_<arg_name>, *<arg_name>, gboolean, \"b\");",
                          args_in_declear=["gsize n_<arg_name> = 0;",
                                           "gboolean *<arg_name> = NULL;",
                                           "ITER_BASIC_TYPE_ARRAY" +
                                           "(parameters, arg_id++, n_<arg_name>, <arg_name>, gboolean, \"b\");"],
                          args_out_declear=["*n_<arg_name> = 0;",
                                            "*<arg_name> = NULL;",
                                            "ITER_BASIC_TYPE_ARRAY" +
                                            "(parameters, arg_id++, *n_<arg_name>, *<arg_name>, gboolean, \"b\");"],
                          args_in_free=["g_free(<arg_name>);"],
                          args_out_free=["g_free(<arg_name>);"],
                          args_out_pack=["out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"b\", n_<arg_name>, <arg_name>);" +
                                         "g_variant_builder_add_value(&builder, out_arg_);"]),
        "ay": PropertyMap(write_func="array_uint8", args_type="guint8 *", args_proto="gint n, guint8 *val",
                          args_next="n, val",
                          args_write_remote_declear="GVariant *out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"y\", n, val);",
                          args_read_remote_declear="GET_BASIC_TYPE_ARRAY" +
                            "(_out_val, *n_<arg_name>, *<arg_name>, guint8, \"y\");",
                          args_in_declear=["gsize n_<arg_name> = 0;",
                                           "guint8 *<arg_name> = NULL;",
                                           "ITER_BASIC_TYPE_ARRAY" +
                                           "(parameters, arg_id++, n_<arg_name>, <arg_name>, guint8, \"y\");"],
                          args_out_declear=["*n_<arg_name> = 0;",
                                            "*<arg_name> = NULL;",
                                            "ITER_BASIC_TYPE_ARRAY" +
                                            "(parameters, arg_id++, *n_<arg_name>, *<arg_name>, guint8, \"y\");"],
                          args_in_free=["g_free(<arg_name>);"],
                          args_out_free=["g_free(<arg_name>);"],
                          args_out_pack=["out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"y\", n_<arg_name>, <arg_name>);" +
                                         "g_variant_builder_add_value(&builder, out_arg_);"]),
        "an": PropertyMap(write_func="array_int16", args_type="gint16 *", args_proto="gint n, gint16 *val",
                          args_next="n, val",
                          args_write_remote_declear="GVariant *out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"n\", n, val);",
                          args_read_remote_declear="GET_BASIC_TYPE_ARRAY" +
                            "(_out_val, *n_<arg_name>, *<arg_name>, gint16, \"n\");",
                          args_in_declear=["gsize n_<arg_name> = 0;",
                                           "gint16 *<arg_name> = NULL;",
                                           "ITER_BASIC_TYPE_ARRAY" +
                                           "(parameters, arg_id++, n_<arg_name>, <arg_name>, gint16, \"n\");"],
                          args_out_declear=["*n_<arg_name> = 0;",
                                            "*<arg_name> = NULL;",
                                            "ITER_BASIC_TYPE_ARRAY" +
                                            "(parameters, arg_id++, *n_<arg_name>, *<arg_name>, gint16, \"n\");"],
                          args_in_free=["g_free(<arg_name>);"],
                          args_out_free=["g_free(<arg_name>);"],
                          args_out_pack=["out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"n\", n_<arg_name>, <arg_name>);" +
                                         "g_variant_builder_add_value(&builder, out_arg_);"]),
        "aq": PropertyMap(write_func="array_uint16", args_type="guint16 *", args_proto="gint n, guint16 *val",
                          args_next="n, val",
                          args_write_remote_declear="GVariant *out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"q\", n, val);",
                          args_read_remote_declear="GET_BASIC_TYPE_ARRAY" +
                            "(_out_val, *n_<arg_name>, *<arg_name>, guint16, \"q\");",
                          args_in_declear=["gsize n_<arg_name> = 0;",
                                           "guint16 *<arg_name> = NULL;",
                                           "ITER_BASIC_TYPE_ARRAY" +
                                           "(parameters, arg_id++, n_<arg_name>, <arg_name>, guint16, \"q\");"],
                          args_out_declear=["*n_<arg_name> = 0;",
                                            "*<arg_name> = NULL;",
                                            "ITER_BASIC_TYPE_ARRAY" +
                                            "(parameters, arg_id++, *n_<arg_name>, *<arg_name>, guint16, \"q\");"],
                          args_in_free=["g_free(<arg_name>);"],
                          args_out_free=["g_free(<arg_name>);"],
                          args_out_pack=["out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"q\", n_<arg_name>, <arg_name>);" +
                            "g_variant_builder_add_value(&builder, out_arg_);"]),
        "ai": PropertyMap(write_func="array_int32", args_type="gint32 *", args_proto="gint n, gint32 *val",
                          args_next="n, val",
                          args_write_remote_declear="GVariant *out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"i\", n, val);",
                          args_read_remote_declear="GET_BASIC_TYPE_ARRAY" +
                            "(_out_val, *n_<arg_name>, *<arg_name>, gint32, \"i\");",
                          args_in_declear=["gsize n_<arg_name> = 0;",
                                           "gint32 *<arg_name> = NULL;",
                                           "ITER_BASIC_TYPE_ARRAY" +
                                           "(parameters, arg_id++, n_<arg_name>, <arg_name>, gint32, \"i\");"],
                          args_out_declear=["*n_<arg_name> = 0;",
                                            "*<arg_name> = NULL;",
                                            "ITER_BASIC_TYPE_ARRAY" +
                                            "(parameters, arg_id++, *n_<arg_name>, *<arg_name>, gint32, \"i\");"],
                          args_in_free=["g_free(<arg_name>);"],
                          args_out_free=["g_free(<arg_name>);"],
                          args_out_pack=["out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"i\", n_<arg_name>, <arg_name>);" +
                            "g_variant_builder_add_value(&builder, out_arg_);"]),
        "au": PropertyMap(write_func="array_uint32", args_type="guint32 *", args_proto="gint n, guint32 *val",
                          args_next="n, val",
                          args_write_remote_declear="GVariant *out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"u\", n, val);",
                          args_read_remote_declear="GET_BASIC_TYPE_ARRAY" +
                            "(_out_val, *n_<arg_name>, *<arg_name>, guint32, \"u\");",
                          args_in_declear=["gsize n_<arg_name> = 0;",
                                           "guint32 *<arg_name> = NULL;",
                                           "ITER_BASIC_TYPE_ARRAY" +
                                           "(parameters, arg_id++, n_<arg_name>, <arg_name>, guint32, \"u\");"],
                          args_out_declear=["*n_<arg_name> = 0;",
                                            "*<arg_name> = NULL;",
                                            "ITER_BASIC_TYPE_ARRAY" +
                                            "(parameters, arg_id++, *n_<arg_name>, *<arg_name>, guint32, \"u\");"],
                          args_in_free=["g_free(<arg_name>);"],
                          args_out_free=["g_free(<arg_name>);"],
                          args_out_pack=["out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"u\", n_<arg_name>, <arg_name>);" +
                            "g_variant_builder_add_value(&builder, out_arg_);"]),
        "ax": PropertyMap(write_func="array_int64", args_type="gint64 *", args_proto="gint n, gint64 *val",
                          args_next="n, val",
                          args_write_remote_declear="GVariant *out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"x\", n, val);",
                          args_read_remote_declear="GET_BASIC_TYPE_ARRAY" +
                            "(_out_val, *n_<arg_name>, *<arg_name>, gint64, \"x\");",
                          args_in_declear=["gsize n_<arg_name> = 0;",
                                           "gint64 *<arg_name> = NULL;",
                                           "ITER_BASIC_TYPE_ARRAY" +
                                           "(parameters, arg_id++, n_<arg_name>, <arg_name>, gint64, \"x\");"],
                          args_out_declear=["*n_<arg_name> = 0;",
                                            "*<arg_name> = NULL;",
                                            "ITER_BASIC_TYPE_ARRAY" +
                                            "(parameters, arg_id++, *n_<arg_name>, *<arg_name>, gint64, \"x\");"],
                          args_in_free=["g_free(<arg_name>);"],
                          args_out_free=["g_free(<arg_name>);"],
                          args_out_pack=["out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"x\", n_<arg_name>, <arg_name>);" +
                            "g_variant_builder_add_value(&builder, out_arg_);"]),
        "at": PropertyMap(write_func="array_uint64", args_type="guint64 *", args_proto="gint n, guint64 *val",
                          args_next="n, val",
                          args_write_remote_declear="GVariant *out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"t\", n, val);",
                          args_read_remote_declear="GET_BASIC_TYPE_ARRAY" +
                            "(_out_val, *n_<arg_name>, *<arg_name>, guint64, \"t\");",
                          args_in_declear=["gsize n_<arg_name> = 0;",
                                           "guint64 *<arg_name> = NULL;",
                                           "ITER_BASIC_TYPE_ARRAY" +
                                           "(parameters, arg_id++, n_<arg_name>, <arg_name>, guint64, \"t\");"],
                          args_out_declear=["*n_<arg_name> = 0;",
                                            "*<arg_name> = NULL;",
                                            "ITER_BASIC_TYPE_ARRAY" +
                                            "(parameters, arg_id++, *n_<arg_name>, *<arg_name>, guint64, \"t\");"],
                          args_in_free=["g_free(<arg_name>);"],
                          args_out_free=["g_free(<arg_name>);"],
                          args_out_pack=["out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"t\", n_<arg_name>, <arg_name>);" +
                            "g_variant_builder_add_value(&builder, out_arg_);"]),
        "ad": PropertyMap(write_func="array_double", args_type="gdouble *", args_proto="gint n, gdouble *val",
                          args_next="n, val",
                          args_write_remote_declear="GVariant *out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"d\", n, val);",
                          args_read_remote_declear="GET_BASIC_TYPE_ARRAY" +
                            "(_out_val, *n_<arg_name>, *<arg_name>, gdouble, \"d\");",
                          args_in_declear=["gsize n_<arg_name> = 0;",
                                           "gdouble *<arg_name> = NULL;",
                                           "ITER_BASIC_TYPE_ARRAY" +
                                           "(parameters, arg_id++, n_<arg_name>, <arg_name>, gdouble, \"d\");"],
                          args_out_declear=["*n_<arg_name> = 0;",
                                            "*<arg_name> = NULL;",
                                            "ITER_BASIC_TYPE_ARRAY" +
                                            "(parameters, arg_id++, *n_<arg_name>, *<arg_name>, gdouble, \"d\");"],
                          args_in_free=["g_free(<arg_name>);"],
                          args_out_free=["g_free(<arg_name>);"],
                          args_out_pack=["out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"d\", n_<arg_name>, <arg_name>);" +
                            "g_variant_builder_add_value(&builder, out_arg_);"]),
        "ah": PropertyMap(write_func="array_handle", args_type="gint32 *", args_proto="gint n, gint32 *val",
                          args_next="n, val",
                          args_write_remote_declear="GVariant *out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"h\", n, val);",
                          args_read_remote_declear="GET_BASIC_TYPE_ARRAY" +
                            "(_out_val, *n_<arg_name>, *<arg_name>, gint32, \"h\");",
                          args_in_declear=["gsize n_<arg_name> = 0;",
                                           "gint32 *<arg_name> = NULL;",
                                           "ITER_BASIC_TYPE_ARRAY" +
                                           "(parameters, arg_id++, n_<arg_name>, <arg_name>, gint32, \"h\");"],
                          args_out_declear=["*n_<arg_name> = 0;",
                                            "*<arg_name> = NULL;",
                                            "ITER_BASIC_TYPE_ARRAY" +
                                            "(parameters, arg_id++, *n_<arg_name>, *<arg_name>, gint32, \"h\");"],
                          args_in_free=["g_free(<arg_name>);"],
                          args_out_free=["g_free(<arg_name>);"],
                          args_out_pack=["out_arg_ = BUILD_BASIC_TYPE_ARRAY(\"h\", n_<arg_name>, <arg_name>);" +
                            "g_variant_builder_add_value(&builder, out_arg_);"]),
        "as": PropertyMap(write_func="array_string", args_type="gchar **", args_proto="gchar **val", args_next="val",
                          args_write_remote_declear="GVariant *out_arg_ = BUILD_STRING_TYPE_ARRAY(\"s\", val);",
                          args_read_remote_declear="GET_STRING_TYPE_ARRAY(_out_val, *<arg_name>, gchar *, \"s\");",
                          args_in_declear=["gchar **<arg_name> = NULL;",
                                           "ITER_STRING_TYPE_ARRAY(parameters, arg_id++, <arg_name>, gchar *, \"s\");"],
                          args_out_declear=["*<arg_name> = NULL;",
                                            "ITER_STRING_TYPE_ARRAY" +
                                            "(parameters, arg_id++, *<arg_name>, gchar *, \"s\");"],
                          args_in_free=["g_strfreev(<arg_name>);"],
                          args_out_free=["g_strfreev(<arg_name>);"],
                          args_out_pack=["out_arg_ = BUILD_STRING_TYPE_ARRAY(\"s\", <arg_name>);" +
                            "g_variant_builder_add_value(&builder, out_arg_);"]),
        "ao": PropertyMap(write_func="array_object_path", args_type="gchar **", args_proto="gchar **val",
                          args_next="val",
                          args_write_remote_declear="GVariant *out_arg_ = BUILD_STRING_TYPE_ARRAY(\"o\", val);",
                          args_read_remote_declear="GET_STRING_TYPE_ARRAY(_out_val, *<arg_name>, gchar *, \"o\");",
                          args_in_declear=["gchar **<arg_name> = NULL;",
                                           "ITER_STRING_TYPE_ARRAY(parameters, arg_id++, <arg_name>, gchar *, \"o\");"],
                          args_out_declear=["*<arg_name> = NULL;",
                                            "ITER_STRING_TYPE_ARRAY" +
                                            "(parameters, arg_id++, *<arg_name>, gchar *, \"o\");"],
                          args_in_free=["g_strfreev(<arg_name>);"],
                          args_out_free=["g_strfreev(<arg_name>);"],
                          args_out_pack=["out_arg_ = BUILD_STRING_TYPE_ARRAY(\"o\", <arg_name>);" +
                            "g_variant_builder_add_value(&builder, out_arg_);"]),
        "ag": PropertyMap(write_func="array_signature", args_type="gchar **", args_proto="gchar **val", args_next="val",
                          args_write_remote_declear="GVariant *out_arg_ = BUILD_STRING_TYPE_ARRAY(\"g\", val);",
                          args_read_remote_declear="GET_STRING_TYPE_ARRAY(_out_val, *<arg_name>, gchar *, \"g\");",
                          args_in_declear=["gchar **<arg_name> = NULL;",
                                           "ITER_STRING_TYPE_ARRAY(parameters, arg_id++, <arg_name>, gchar *, \"g\");"],
                          args_out_declear=["*<arg_name> = NULL;",
                                            "ITER_STRING_TYPE_ARRAY" +
                                            "(parameters, arg_id++, *<arg_name>, gchar *, \"g\");"],
                          args_in_free=["g_strfreev(<arg_name>);"],
                          args_out_free=["g_strfreev(<arg_name>);"],
                          args_out_pack=["out_arg_ = BUILD_STRING_TYPE_ARRAY(\"g\", <arg_name>);" +
                            "g_variant_builder_add_value(&builder, out_arg_);"]),
        "*": PropertyMap(write_func="variant", args_type="GVariant *", args_proto="GVariant *val", args_next="val",
                         args_write_remote_declear="GVariant *out_arg_ = g_variant_ref(val);",
                         args_read_remote_declear="*<arg_name> = g_variant_ref(_out_val);",
                         args_in_declear=["GVariant *<arg_name> = g_variant_get_child_value(parameters, arg_id++);"],
                         args_out_declear=["*<arg_name> = g_variant_get_child_value(parameters, arg_id++);"],
                         args_in_free=["g_variant_unref(<arg_name>);"],
                         args_out_free=["g_variant_unref(<arg_name>);"],
                         args_out_pack=["g_variant_builder_add_value(&builder, <arg_name>);"]),
    }

    def __init__(self, prop: ET.Element, index, prefix: str = "") -> None:
        prefix = prefix + "    "
        self.name = prop.get("name")
        self.type = prop.get("type")
        self.access = prop.get("access")
        self.annotations: list[Annotation] = []
        self.id = 0
        self.emit_changed_signal = "true"
        self.deprecated = False
        self.read_privilege = "0"
        self.write_privilege = "0"
        log.debug("{}Property, name: {:32} type: {:4} access: {:10}".format(
            prefix, self.name + ",", self.type + ",", self.access + ","))
        if self.access not in ("", "read", "write", "readwrite"):
            log.error(f"Unsupport property access type: {self.access}, exit")
            sys.exit(-1)
        for ele in prop.iter("annotation"):
            self.annotations.append(Annotation(ele, prefix))
        # 检查ID属性是否设置，必须设置，否则退出
        for annotation in self.annotations:
            if annotation.is_emit_changed_signal():
                self.emit_changed_signal = annotation.value
            if annotation.is_deprecated():
                self.deprecated = True
            pri = annotation.get_privilege("bmc.kepler.Security.Privileges.Read")
            if pri:
                self.read_privilege = pri
            pri = annotation.get_privilege("bmc.kepler.Security.Privileges.Write")
            if pri:
                self.write_privilege = pri
        self.id = index
        # ID必须大于0，否则退出
        if self.id <= 0:
            log.error(f"接口属性{self.name}的ID值{self.id}错误，请正确设置属性ID，注：属性ID必须大于0。退出执行!")
            sys.exit(-1)

    @staticmethod
    def check_type_startwith_a(arg_type):
        if arg_type.startswith("a") and arg_type not in ("ao", "as", "ag"):
            return True
        return False

    def is_private_prop(self):
        for an in self.annotations:
            if an.is_private_prop():
                return True
        return False

    def format_struct(self):
        lines = []
        if self.type in self.type_map:
            if self.check_type_startwith_a(self.type):
                lines.append("size_t n_{}".format(self.name))
            lines.append("{}{}".format(
                self.type_map[self.type].type, self.name))
        else:
            lines.append("{}{}".format(self.type_map["*"].type, self.name))
        return lines

    def format_property_info(self, interface: str, src_fd: FileIO):
        if self.access == "readwrite":
            flags = "G_DBUS_PROPERTY_INFO_FLAGS_WRITABLE | G_DBUS_PROPERTY_INFO_FLAGS_READABLE"
        elif self.access == "write":
            flags = "G_DBUS_PROPERTY_INFO_FLAGS_WRITABLE"
        elif self.access == "read":
            flags = "G_DBUS_PROPERTY_INFO_FLAGS_READABLE"
        else:
            flags = "G_DBUS_PROPERTY_INFO_FLAGS_NONE"
        annotation_name = format_annotations(
            self.annotations, interface, "prop_" + self.name, src_fd)
        lines = []
        lines.append("{",)
        lines.append("    .ref_count = -1,",)
        lines.append(f"    .name = \"{self.name}\",",)
        lines.append(f"    .signature = \"{self.type}\",",)
        lines.append(f"    .flags = {flags},",)
        lines.append(f"    .annotations = {annotation_name},")
        lines.append("},")
        return lines

    def format_field_descriptor(self, interface: str, index: int, prop_stru: str):
        if self.emit_changed_signal == "const":
            flags = "MC4C_FLAGS_PROPERTY_EMIT_CONST"
        elif self.emit_changed_signal == "true":
            flags = "MC4C_FLAGS_PROPERTY_EMIT_TRUE"
        elif self.emit_changed_signal == "false":
            flags = "MC4C_FLAGS_PROPERTY_EMIT_FALSE"
        elif self.emit_changed_signal == "invalidates":
            flags = "MC4C_FLAGS_PROPERTY_EMIT_INVALIDATES"
        else:
            flags = "0"
        if self.is_private_prop():
            flags = flags + " | MC4C_FLAGS_PROPERTY_PRIVATE"
        if self.deprecated:
            flags = flags + " | MC4C_FLAGS_PROPERTY_DEPRECATED"
        if self.type == "*":
            tm = self.type_map["*"]
            flags = flags + " | MC4C_FLAGS_PROPERTY_ANY"
        elif self.type in self.type_map:
            tm = self.type_map[self.type]
        else:
            tm = self.type_map["*"]
            flags = flags + " | MC4C_FLAGS_PROPERTY_VARIANT"
        lines = []
        lines.append("{",)
        lines.append(f"    .info = &{prop_stru}_i[{index}], /* property id: {index} */",)
        lines.append(f"    .offset = offsetof({interface}, {self.name}),",)
        lines.append(f"    .flags = {flags},",)
        lines.append(
            f"    .set = (mc4c_set_variant)mc4c_set_val_{tm.write_func}_variant,",)
        lines.append(
            f"    .get = (mc4c_get_variant)mc4c_get_val_{tm.write_func}_variant,",)
        lines.append(f"    .id = {self.id},  /* property id: {self.id} */",)
        if self.read_privilege != "0":
            lines.append(f"    .read_privilege = {self.read_privilege},",)
        if self.write_privilege != "0":
            lines.append(f"    .write_privilege = {self.write_privilege},",)
        lines.append("},")
        return lines

    def format_write_function(self, interface: str, index: int, prop_stru: str):
        if self.type in self.type_map:
            tm = self.type_map[self.type]
        else:
            tm = self.type_map["*"]
        lines = []
        lines.append(
            f"void {interface}_set_{self.name}(const {interface} *handler, {tm.args_proto})")
        lines.append("{")
        lines.append(f"    /* set property, id: {index} */")
        lines.append(
            f"    mc4c_set_val_{tm.write_func}((PmHandler)handler, &{prop_stru}[{index}], {tm.args_next});")
        lines.append("}")
        return lines

    def format_read_remote_function(self, interface: str, index: int, prop_stru: str):
        args_proto = ""
        is_array = False
        if self.type in self.type_map:
            tm = self.type_map[self.type]
            if Property.check_type_startwith_a(self.type):
                args_proto = "gint *n_out_{}, {}* out_{}".format(self.name, tm.type, self.name)
                is_array = True
            else:
                args_proto = "{}* out_{}".format(tm.type, self.name)
        else:
            tm = self.type_map["*"]
            args_proto = "{}* out_{}".format(tm.type, self.name)
        lines = []
        lines.append(
            f"gint {interface}_get_{self.name}(const {interface} *handler, {args_proto}, GError **error)")
        lines.append("{")
        lines.append("    GVariant *_out_val = NULL;")
        lines.append("    if (!out_{}) return MC4C_ERROR_PARAMETER_ERROR;".format(self.name))
        if is_array:
            lines.append("    if (!n_out_{}) return MC4C_ERROR_PARAMETER_ERROR;".format(self.name))
        lines.append(
            f"    gint ret = mc4c_get_prop_val((PmHandler)handler, &{prop_stru}[{index}], &_out_val, error);")
        lines.append("    if (ret != 0) return ret;")
        lines.append(tm.args_read_remote_declear.replace("<arg_name>", "out_" + self.name))
        lines.append("    g_variant_unref(_out_val);")
        lines.append("    return ret;")
        lines.append("}")
        return lines

    def format_write_remote_function(self, interface: str, index: int, prop_stru: str):
        if self.access != "write" and self.access != "readwrite":
            return []
        if self.type in self.type_map:
            tm = self.type_map[self.type]
        else:
            tm = self.type_map["*"]
        lines = []
        lines.append(
            f"gint {interface}_set_{self.name}(const {interface} *handler, {tm.args_proto}, GError **error)")
        lines.append("{")
        lines.append(tm.args_write_remote_declear)
        lines.append(f"/* property id: {index} */")
        lines.append(
            f"    gint ret = mc4c_set_prop_val((PmHandler)handler, &{prop_stru}[{index}], out_arg_, error);")
        lines.append("    g_variant_unref(out_arg_);")
        lines.append("    return ret;")
        lines.append("}")
        return lines


class Arg():
    def __init__(self, arg: ET.Element, direction: str, index, prefix: str = "") -> None:
        prefix = prefix + "    "
        self.name = arg.get("name", f"{index}")
        self.direction = direction
        self.name = self.direction + "_" + self.name
        self.type = arg.get("type")
        if self.direction != "in" and self.direction != "out":
            log.warning(f"The direction of argumemt {self.name} invalid, must be 'in' or 'out'," +
                        f" get '{self.direction}', set to 'in'")
            sys.exit(-1)
        log.debug("{}Arg, name: {:33} type: {:4} direction: {}".format(
            prefix, self.name + ",", self.type + ",", self.direction))
        self.annotations: list[Annotation] = []
        for ele in arg.iter("annotation"):
            self.annotations.append(Annotation(ele, prefix))
        pass

    def format_src(self, interface: str, method_name: str, src_fd: FileIO):
        annotation_name = format_annotations(
            self.annotations, interface, f"{method_name}_{self.name}", src_fd)
        lines = []
        lines.append("{")
        lines.append("    .ref_count = -1,")
        if self.direction == "in":
            lines.append(f"    .name = \"{self.name[3:]}\",")
        else:
            lines.append(f"    .name = \"{self.name[4:]}\",")
        lines.append(f"    .signature = \"{self.type}\",")
        lines.append(f"    .annotations = {annotation_name},")
        lines.append("},")
        return lines


class Method():
    def __init__(self, method: ET.Element, prefix: str = "") -> None:
        prefix = prefix + "    "
        self.name = method.get("name")
        log.debug(f"{prefix}Method, name: {self.name}")
        self.args: list[Arg] = []
        self.annotations: list[Annotation] = []
        self.privilege = "0"
        for ele in method.iter("annotation"):
            self.annotations.append(Annotation(ele, prefix))
        in_id = 0
        out_id = 0
        for arg in method.iter("arg"):
            direction = arg.get("direction", "in")
            if direction == "in":
                self.args.append(Arg(arg, direction, in_id, prefix))
                in_id = in_id + 1
            else:
                self.args.append(Arg(arg, direction, out_id, prefix))
                out_id = out_id + 1
        # 是否已被弃用
        self.deprecated = False
        for annotation in self.annotations:
            if annotation.is_deprecated():
                self.deprecated = True
            pri = annotation.get_privilege()
            if pri:
                self.privilege = pri

    @staticmethod
    def make_first_method_arg(first, prefix, arg_name):
        if first:
            return f"{prefix}n_{arg_name}"
        else:
            return ", " + f"{prefix}n_{arg_name}"

    @staticmethod
    def make_first_arg_array_str(first, arg_prefix, arg_name):
        if first:
            return f"gsize {arg_prefix}n_{arg_name}"
        else:
            return ", " + f"gsize {arg_prefix}n_{arg_name}"

    def format_method_info(self, interface: str, src_fd: FileIO):
        args_in = self._format_args(interface, src_fd, "in")
        args_out = self._format_args(interface, src_fd, "out")
        annotation_name = format_annotations(
            self.annotations, interface, "method_" + self.name, src_fd)
        lines = []
        lines.append("{")
        lines.append(f"    .ref_count = -1,")
        lines.append(f"    .name = \"{self.name}\",")
        lines.append(f"    .in_args = {args_in},")
        lines.append(f"    .out_args = {args_out},")
        lines.append(f"    .annotations = {annotation_name},")
        lines.append("},")
        return lines

    def get_method_proc_handler(self, interface: str):
        return f"{interface}_{self.name}_handler"

    # 生成方法入参列表
    def get_method_args_in_declare(self):
        lines = []
        for arg in self.args:
            if arg.direction == "out":
                continue
            if arg.type in Property.type_map:
                tm = Property.type_map[arg.type]
            else:
                tm = Property.type_map["*"]
            for line in tm.args_in_declear:
                lines.append(line.replace("<arg_name>", arg.name))
        return lines

    # 生成方法入参列表
    def get_method_args_out_declare(self):
        lines = []
        for arg in self.args:
            if arg.direction == "in":
                continue
            if arg.type in Property.type_map:
                if Property.check_type_startwith_a(arg.type):
                    lines.append(f"gsize n_{arg.name} = 0;")
                tm = Property.type_map[arg.type]
            else:
                tm = Property.type_map["*"]
            if tm.type.endswith("*"):
                lines.append(tm.type + " " + arg.name + " = NULL;")
            else:
                lines.append(tm.type + " " + arg.name + " = 0;")
        return lines

    # 客户端获取到响应后将响应值分配到调用者的出参
    def get_method_args_out_assign(self):
        lines = []
        for arg in self.args:
            if arg.direction == "in":
                continue
            if arg.type in Property.type_map:
                tm = Property.type_map[arg.type]
            else:
                tm = Property.type_map["*"]
            lines.append(f"if ({arg.name}) {{")
            for line in tm.args_out_declear:
                lines.append(line.replace("<arg_name>", arg.name))
            lines.append("}")
        return lines

    def get_method_args_out_pack(self):
        lines = []
        for arg in self.args:
            if arg.direction == "in":
                continue
            if arg.type in Property.type_map:
                tm = Property.type_map[arg.type]
            else:
                tm = Property.type_map["*"]
            for line in tm.args_out_pack:
                lines.append(line.replace("<arg_name>", arg.name))
        return lines

    # 请求方法是参数打包
    def get_method_args_in_pack(self):
        lines = []
        for arg in self.args:
            if arg.direction == "out":
                continue
            if arg.type in Property.type_map:
                tm = Property.type_map[arg.type]
            else:
                tm = Property.type_map["*"]
            for line in tm.args_out_pack:
                lines.append(line.replace("<arg_name>", arg.name))
        return lines

    # method_call回调函数申明
    def get_method_call(self, interface: str):
        func = f"ret = callback(handler"
        args_in = self._format_method_call_args("in")
        args_out = self._format_method_call_args("out")
        if args_in:
            func += ", " + args_in
        if args_out:
            func += ", " + args_out
        func += ", error);"
        return func

    def get_method_args_free(self):
        lines = []
        for arg in self.args:
            if arg.type in Property.type_map:
                tm = Property.type_map[arg.type]
            else:
                tm = Property.type_map["*"]
            if arg.direction == "in":
                for line in tm.args_in_free:
                    lines.append(line.replace("<arg_name>", arg.name))
            elif arg.type in Property.type_map and arg.type != "*":
                for line in tm.args_out_free:
                    lines.append(line.replace("<arg_name>", arg.name))
        return lines

    def format_method_descriptor(self, interface: str, index: int, mtd_stru: str):
        lines = []
        lines.append("{")
        lines.append(f"    .info = &{mtd_stru}_i[{index}], /* method id: {index} */")
        lines.append("    .handler = {},  /* callback handler */".format(
            self.get_method_proc_handler(interface)))
        if self.privilege != "0":
            lines.append("    .privilege = {}  /* callback handler */".format(self.privilege))
        lines.append("},")
        return lines

    def get_method_handler(self, interface: str):
        return f"{interface}_Method_{self.name}"

    # method_call回调函数申明
    def format_method_handler(self, interface: str):
        handler = self.get_method_handler(interface)
        func = f"typedef int (*{handler})(PmHandler handler"
        args_in = self._format_method_args("in")
        args_out = self._format_method_args("out")
        if args_in:
            func += ", " + args_in
        if args_out:
            func += ", " + args_out
        func += ", GError **error);"
        return func

    # method_call函数申明
    def format_method_handler_cli(self, interface: str):
        handler = f"{interface}_Call_{self.name}"
        func = f"int {handler}(PmHandler handler, gint timeout_msec"
        args_in = self._format_method_args("in")
        args_out = self._format_method_args("out")
        if args_in:
            func += ", " + args_in
        if args_out:
            func += ", " + args_out
        func += ", GError **error)"
        return func

    def format_method_out_signature(self):
        out = ""
        for arg in self.args:
            if arg.direction == "in":
                continue
            out = out + arg.type
        if out != "":
            out = "(" + out + ")"
        return out

    def get_method_args_free_cli(self):
        lines = []
        for arg in self.args:
            if arg.direction == "in":
                continue
            if arg.type in Property.type_map:
                tm = Property.type_map[arg.type]
            else:
                tm = Property.type_map["*"]
            for line in tm.args_out_free:
                lines.append(line.replace("<arg_name>", arg.name))
        return lines

    def _format_args(self, interface: str, src_fd: FileIO, direction: str):
        liness = []
        for arg in self.args:
            if arg.direction == direction:
                liness.append(arg.format_src(interface, self.name, src_fd))
        args_str = "NULL"
        if liness:
            args_str = f"{interface}_{self.name}_{direction}args"
            src_fd.write(f"static GDBusArgInfo {args_str}_i[] = {{\n")
            for lines in liness:
                for line in lines:
                    src_fd.write(f"    {line}\n")
            src_fd.write("};\n\n")
            src_fd.write(f"static GDBusArgInfo *{args_str}[] = {{\n")
            index = 0
            for _ in liness:
                src_fd.write(f"    &{args_str}_i[{index}], /* argument id: {index} */\n")
                index = index + 1
            src_fd.write("    NULL,\n};\n\n")
        return args_str

    def _format_method_args(self, direction: str):
        out = ""
        first = True
        arg_prefix = "*" if direction == "out" else ""
        for arg in self.args:
            if arg.direction != direction:
                continue
            if arg.type in Property.type_map:
                if Property.check_type_startwith_a(arg.type):
                    out += self.make_first_arg_array_str(first, arg_prefix, arg.name)
                    first = False
                tm = Property.type_map[arg.type]
            else:
                tm = Property.type_map["*"]
            if direction == "in":
                if tm.type.endswith("**"):
                    arg_str = "const " + \
                        tm.type[:-2] + " *const *" + arg_prefix + arg.name
                elif tm.type.endswith("*") and not tm.type.startswith("GVariant"):
                    arg_str = "const " + tm.type + arg_prefix + arg.name
                else:
                    arg_str = tm.type + arg_prefix + arg.name
            else:
                arg_str = tm.type + arg_prefix + arg.name
            if first:
                out += arg_str
            else:
                out += ", " + arg_str
            first = False
        return out

    def _format_method_call_args(self, direction: str):
        out = ""
        first = True
        if direction == "out":
            prefix = "&"
        else:
            prefix = ""
        for arg in self.args:
            if arg.direction != direction:
                continue
            if arg.type in Property.type_map:
                if Property.check_type_startwith_a(arg.type):
                    out += self.make_first_method_arg(first, prefix, arg.name)
                    first = False
                tm = Property.type_map[arg.type]
            else:
                tm = Property.type_map["*"]
            if tm.type == "gchar **" and direction == "in":
                arg_str = prefix + "(const gchar *const *)" + arg.name
            else:
                arg_str = prefix + arg.name
            if first:
                out += arg_str
            else:
                out += ", " + arg_str
            first = False
        return out


class Signal():
    def __init__(self, signal: ET.Element, prefix: str = "") -> None:
        prefix = prefix + "    "
        self.name = signal.get("name")
        log.debug(f"{prefix}Signal, name: {self.name}")
        self.args: list[Arg] = []
        self.annotations: list[Annotation] = []
        for ele in signal.iter("annotation"):
            self.annotations.append(Annotation(ele, prefix))
        index = 0
        for arg in signal.iter("arg"):
            self.args.append(Arg(arg, "out", index, prefix))
            index = index + 1
        # 是否已被弃用
        self.deprecated = False
        for annotation in self.annotations:
            if annotation.is_deprecated():
                self.deprecated = True

    @staticmethod
    def make_first_arg_array_str(first, arg_name):
        if first:
            return f"gsize n_{arg_name}"
        else:
            return ", " + f"gsize n_{arg_name}"

    def format_signal_info(self, interface: str, src_fd: FileIO):
        args = self._format_args(interface, src_fd)
        annotation_name = format_annotations(
            self.annotations, interface, "signal_" + self.name, src_fd)
        lines = []
        lines.append("{")
        lines.append(f"    .ref_count = -1,")
        lines.append(f"    .name = \"{self.name}\",")
        lines.append(f"    .args = {args},")
        lines.append(f"    .annotations = {annotation_name},")
        lines.append("},")
        return lines

    def get_signal_handler(self, interface: str):
        return f"{interface}_Signal_{self.name}"

    def format_signal_handler(self, interface: str):
        handler = self.get_signal_handler(interface)
        lines = []
        func = f"gboolean {handler}(PmHandler handler, const gchar *destination"
        args = self._format_signal_args()
        if args:
            func += ", " + args
        func += ", GError **error)"
        lines.append(func)
        return lines

    def get_signal_handler_cli(self, interface: str):
        return f"{interface}_Listen_{self.name}"

    def format_signal_handler_cli(self, interface: str):
        handler = self.get_signal_handler_cli(interface)
        func = f"typedef void (*{handler})(PmHandler handler, const gchar *sender_name"
        args = self._format_signal_args()
        if args != "":
            func += ", " + args
        func += ", gpointer user_data)"
        return func

    def format_signal_signature(self):
        signature = "("
        for arg in self.args:
            signature = signature + arg.type
        signature = signature + ")"
        return signature

    def get_signal_args_out_pack(self):
        lines = []
        for arg in self.args:
            if arg.type in Property.type_map:
                tm = Property.type_map[arg.type]
            else:
                tm = Property.type_map["*"]
            for line in tm.args_out_pack:
                lines.append(line.replace("<arg_name>", arg.name))
        return lines

    # 客户端获取到响应后将响应值分配到调用者的出参
    def get_signal_args_assign_cli(self):
        lines = []
        for arg in self.args:
            if arg.type in Property.type_map:
                tm = Property.type_map[arg.type]
            else:
                tm = Property.type_map["*"]
            for line in tm.args_in_declear:
                lines.append(line.replace("<arg_name>", arg.name))
        return lines

    def get_signal_args_free_cli(self):
        lines = []
        for arg in self.args:
            if arg.type in Property.type_map:
                tm = Property.type_map[arg.type]
            else:
                tm = Property.type_map["*"]
            for line in tm.args_out_free:
                lines.append(line.replace("<arg_name>", arg.name))
        return lines

    def format_signal_args_without_type(self):
        out = ""
        first = True
        for arg in self.args:
            if (arg.type in Property.type_map and Property.check_type_startwith_a(arg.type)):
                if first:
                    out += f"n_{arg.name}"
                else:
                    out += ", " + f"n_{arg.name}"
                first = False
            arg_str = arg.name
            if first:
                out += arg_str
            else:
                out += ", " + arg_str
            first = False
        return out

    def _format_signal_args(self):
        out = ""
        first = True
        for arg in self.args:
            if arg.type in Property.type_map:
                pm = Property.type_map[arg.type]
                if Property.check_type(arg.type):
                    out += self.make_first_arg_array_str(first, arg.name)
                    first = False
            else:
                pm = Property.type_map["*"]
            new_type = pm.type.replace(" ", "")
            arg_str = pm.type + arg.name
            if new_type == "gchar*":
                arg_str = "const " + arg_str
            if first:
                out += arg_str
            else:
                out += ", " + arg_str
            first = False
        return out

    def _format_args(self, interface: str, src_fd: FileIO):
        liness = []
        for arg in self.args:
            liness.append(arg.format_src(interface, self.name, src_fd))
        arg_stru = "NULL"
        if liness:
            arg_stru = f"{interface}_{self.name}_args"
            src_fd.write(f"static GDBusArgInfo {arg_stru}_i[] = {{\n")
            for lines in liness:
                for line in lines:
                    src_fd.write(f"    {line}\n")
            src_fd.write("};\n\n")
            src_fd.write(f"static GDBusArgInfo *{arg_stru}[] = {{\n")
            index = 0
            for _ in liness:
                src_fd.write(f"    &{arg_stru}_i[{index}], /* argument id: {index} */\n")
                index = index + 1
            src_fd.write("    NULL,\n};\n\n")
        return arg_stru


class Interface():
    def __init__(self, intf: ET.Element, src_fd: FileIO, inc_fd: FileIO):
        self.intf = intf
        self.src_fd = src_fd
        self.inc_fd = inc_fd

        self.props: list[Property] = []
        self.methods: list[Method] = []
        self.signals: list[Signal] = []
        self.annotations: list[Annotation] = []
        self.interface = self.intf.get("name")
        self.privilege = "0"
        self.struct = self.interface.replace(".", "_")

    def gen_src(self):
        interface_stru = self.struct + "_interface"
        prop_stru, property_desc_stru = self.gen_property_info()
        mtd_stru = self.gen_methods_info(prop_stru, interface_stru)
        mtd_desc_stru = self.gen_method_process(mtd_stru)
        self.gen_method_callback()
        self.gen_signals(property_desc_stru, mtd_desc_stru, interface_stru)

    def gen_property_info(self):
        """ 生成PmPropertyDescriptor """
        prop_stru = "NULL"
        property_desc_stru = "NULL"
        if self.props:
            prop_stru = f"{self.struct}_property_info"
            liness: list[str] = []
            for prop in self.props:
                liness.append(prop.format_property_info(
                    self.struct, self.src_fd))
            self.src_fd.write(f"static GDBusPropertyInfo {prop_stru}_i[] = {{\n")
            for lines in liness:
                for line in lines:
                    self.src_fd.write(f"    {line}\n")
            self.src_fd.write("};\n\n")

            self.src_fd.write(f"static GDBusPropertyInfo *{prop_stru}[] = {{\n")
            index = 0
            for _ in liness:
                if not self.props[index].is_private_prop():
                    self.src_fd.write(f"&{prop_stru}_i[{index}],  /* property id: {index} */ \n")
                index = index + 1
            self.src_fd.write("    NULL,\n};\n\n")
            # 检查ID值，不能重复
            ids = []
            for prop in self.props:
                if prop.id in ids:
                    raise errors.XmlErrorException(f"接口属性{prop.name}的ID值{prop.id}重复，退出执行")
                ids.append(prop.id)
            # 生成PmPropertyDescriptor
            property_desc_stru = f"{self.struct}_property_descriptor"
            liness: list[str] = []
            index = 0
            for prop in self.props:
                liness.append(prop.format_field_descriptor(self.struct, index, prop_stru))
                index = index + 1
            self.src_fd.write(f"static PmPropertyDescriptor {property_desc_stru}[] = {{\n")
            for lines in liness:
                for line in lines:
                    self.src_fd.write(f"    {line}\n")
            self.src_fd.write("    {NULL},\n};\n\n")

            # 生成生函数
            index = 0
            for prop in self.props:
                lines = prop.format_write_function(self.struct, index, property_desc_stru)
                if prop.deprecated:
                    self.inc_fd.write("__attribute__((__deprecated__))\n")
                self.inc_fd.write(lines[0] + ";\n")
                for line in lines:
                    self.src_fd.write(f"{line}\n")
                self.src_fd.write("\n")
                index = index + 1
            self.inc_fd.write("\n")
        return prop_stru, property_desc_stru

    def gen_methods_info(self, prop_stru, interface_stru):
        mtd_stru = "NULL"
        if self.methods:
            # 生成GDBusMethodInfo信息
            mtd_stru = f"{self.struct}_method_info"
            liness: list[str] = []
            for method in self.methods:
                liness.append(method.format_method_info(
                    self.struct, self.src_fd))
            self.src_fd.write(f"static GDBusMethodInfo {mtd_stru}_i[] = {{\n")
            for lines in liness:
                for line in lines:
                    self.src_fd.write(f"    {line}\n")
            self.src_fd.write("};\n\n")
            self.src_fd.write(f"static GDBusMethodInfo *{mtd_stru}[] = {{\n")
            index = 0
            for _ in liness:
                self.src_fd.write(f"    &{mtd_stru}_i[{index}], /* method id: {index} */\n")
                index = index + 1
            self.src_fd.write("    NULL,\n};\n\n")
        sig_stru = "NULL"
        if self.signals:
            sig_stru = f"{self.struct}_signal_info"
            liness: list[str] = []
            for signal in self.signals:
                liness.append(signal.format_signal_info(
                    self.struct, self.src_fd))
            self.src_fd.write(f"static GDBusSignalInfo {sig_stru}_i[] = {{\n")
            for lines in liness:
                for line in lines:
                    self.src_fd.write(f"    {line}\n")
            self.src_fd.write("};\n\n")
            index = 0
            self.src_fd.write(f"static GDBusSignalInfo *{sig_stru}[] = {{\n")
            for _ in liness:
                self.src_fd.write(f"    &{sig_stru}_i[{index}], /* signal id: {index} */\n")
                index = index + 1
            self.src_fd.write("    NULL,\n};\n\n")
        annotation_name = format_annotations(
            self.annotations, self.struct, "interface", self.src_fd)
        self.src_fd.write(f"static GDBusInterfaceInfo {interface_stru} = {{\n")
        self.src_fd.write(f"    .ref_count = -1,\n")
        self.src_fd.write(f"    .name = \"{self.interface}\",\n")
        self.src_fd.write(f"    .methods = {mtd_stru},\n")
        self.src_fd.write(f"    .signals = {sig_stru},\n")
        self.src_fd.write(f"    .properties = {prop_stru},\n")
        self.src_fd.write(f"    .annotations = {annotation_name},\n")
        self.src_fd.write("};\n\n")
        return mtd_stru

    def gen_method_process(self, mtd_stru):
        # 生成接口消息处理函数（含函数回调和发送信号函数）
        lines = []
        self.src_fd.write(f"typedef struct {{\n")
        for method in self.methods:
            lines.append("    {} {}".format(
                method.get_method_handler(self.struct), method.name))
        for line in lines:
            self.src_fd.write(f"    {line};\n")
        self.src_fd.write(f"}} {self.struct}_process_stru;\n\n")

        # 生成消息回调和信号发送函数句柄
        if self.methods or self.signals:
            self.src_fd.write(
                f"static {self.struct}_process_stru {self.struct}_process = {{NULL}};\n")
        for method in self.methods:
            prototype = f"void {self.struct}_SetMethod_{method.name}({method.get_method_handler(self.struct)} handler)"
            if method.deprecated:
                self.inc_fd.write("__attribute__((__deprecated__))\n")
            self.inc_fd.write(prototype + ";\n")
            self.src_fd.write(prototype + "\n")
            self.src_fd.write("{\n")
            self.src_fd.write(
                f"    {self.struct}_process.{method.name} = handler;\n")
            self.src_fd.write(f"}}\n")
        self.src_fd.write("\n")

        for method in self.methods:
            self.src_fd.write(
                f"static int {method.get_method_proc_handler(self.struct)}" +
                "(PmHandler handler, GVariant *parameters, GVariant **replay, gpointer userdata, GError **error);\n")
        # 生成PmMethodDescriptor信息
        mtd_desc_stru = "NULL"
        if self.methods:
            mtd_desc_stru = f"{self.struct}_method_descriptor"
            liness = []
            index = 0
            for method in self.methods:
                liness.append(method.format_method_descriptor(
                    self.struct, index, mtd_stru))
                index = index + 1
            self.src_fd.write(
                f"static PmMethodDescriptor {mtd_desc_stru}[] = {{\n")
            for lines in liness:
                for line in lines:
                    self.src_fd.write(f"    {line}\n")
            self.src_fd.write("    {NULL},\n};\n\n")
        return mtd_desc_stru

    def gen_method_callback(self):
        n = -1
        for method in self.methods:
            with_context = False
            if method.args and method.args[0].name.lower() == "in_context" and method.args[0].type == 'a{ss}':
                with_context = True
            n += 1
            self.src_fd.write(f"static int {method.get_method_proc_handler(self.struct)}" +
                "(PmHandler handler, GVariant *parameters, GVariant **replay, gpointer userdata, GError **error)\n{\n")
            self.src_fd.write(f"{self.struct}_Method_{method.name} callback = {self.struct}_process.{method.name};\n")
            self.src_fd.write(f"if (!callback) {{\n")
            self.src_fd.write("    return REG_METHOD_NOT_AVALIBALE;\n}\n    int arg_id __attribute__((unused)) = 0;")

            self.src_fd.write("    int ret = -1;\n    GVariant *in_arg_ __attribute__((unused));\n")
            self.src_fd.write("    GVariant *out_arg_ __attribute__((unused));\n")
            self.src_fd.write("    GVariantBuilder builder __attribute__((unused));\n")
            lines = method.get_method_args_in_declare()
            for line in lines:
                self.src_fd.write(f"    {line}\n")
            lines = method.get_method_args_out_declare()
            for line in lines:
                self.src_fd.write(f"    {line}\n")
            # 如果第一个入参类型名字为context且类型为"a{ss}"则认为是上下文信息
            if with_context:
                self.src_fd.write("\n     /* Check method privilege */\n")
                self.src_fd.write(f"     guint32 method_privilege = {self.struct}_method_descriptor[{n}].privilege;")
                self.src_fd.write("     CallerContext ctx = {NULL};")
                self.src_fd.write("     caller_context_parse(&ctx, {});".format(method.args[0].name))
                self.src_fd.write("     const PmInterfaceDescriptor *intf = mc4c_object_interface_desc(handler);")
                self.src_fd.write("     guint32 error_privilege = " +
                    f"caller_context_privilege_check(intf->privilege, method_privilege, &ctx);\n")
                self.src_fd.write("     if (error_privilege != 0) {\n*error = mc4c_error_insufficient_privilege();\n")
                self.src_fd.write("     } else {\n")

            self.src_fd.write(f"log_debug(\"/* ********************* " +
                f"call class method {method.name} start  *********************** */\");\n")
            self.src_fd.write(method.get_method_call(self.struct) + "\n")
            self.src_fd.write(f"log_debug(\"/* ********************* " +
                f"call class method {method.name} finish *********************** */\");\n")
            self.src_fd.write(f"if (ret != 0) {{\n")
            self.src_fd.write(f"    log_debug(\"Call class method {method.name} failed, return: %d\", ret);\n")
            self.src_fd.write(f"}} else {{\ng_variant_builder_init(&builder, G_VARIANT_TYPE_TUPLE);\n")
            lines = method.get_method_args_out_pack()
            for line in lines:
                self.src_fd.write(f"    {line}\n")
            self.src_fd.write(f"*replay = g_variant_builder_end(&builder);\n}}\n")

            if with_context:
                self.src_fd.write("    }\n")

            lines = method.get_method_args_free()
            for line in lines:
                self.src_fd.write(f"    {line}\n")
            self.src_fd.write(f"    return ret;\n}}\n\n")

    def gen_signals(self, property_desc_stru, mtd_desc_stru, interface_stru):
        for signal in self.signals:
            self.src_fd.write(signal.format_signal_handler(
                self.struct)[0] + "\n{\n")
            self.src_fd.write("    GVariantBuilder builder;")
            self.src_fd.write("    GVariant *out_arg_ __attribute__((unused));")
            self.src_fd.write(
                "    g_variant_builder_init(&builder, G_VARIANT_TYPE_TUPLE);\n")
            lines = signal.get_signal_args_out_pack()
            for line in lines:
                self.src_fd.write(f"    {line}\n")
            self.src_fd.write(
                f"GVariant *message = g_variant_builder_end(&builder);\n")
            self.src_fd.write(
                f"return mc4c_emit_signal(handler, destination, \"{signal.name}\", message, error);")
            self.src_fd.write("}\n\n")

        self.src_fd.write(
            f"PmInterfaceDescriptor {self.struct}_descriptor = {{\n")
        self.src_fd.write(f"    .sizeof_object = sizeof({self.struct}),\n")
        self.src_fd.write(f"    .is_remote = 0,\n")
        self.src_fd.write(f"    .properties = {property_desc_stru},\n")
        self.src_fd.write(f"    .methods = {mtd_desc_stru},\n")
        self.src_fd.write(f"    .interface = &{interface_stru},\n")
        if self.privilege != "0":
            self.src_fd.write(f"    .privilege = {self.privilege},\n")
        self.src_fd.write("};\n\n")

        self.src_fd.write(
            f"static void __attribute__((constructor(150))) {self.struct}_register(void)\n{{\n")
        self.src_fd.write(
            f"mc4c_register_interface(&{self.struct}_descriptor);\n}}\n\n")

        self.src_fd.write(
            f"const PmInterfaceDescriptor *{self.struct}_descriptor_get(void) " +
            f"{{\n    return &{self.struct}_descriptor;}}\n")
        self.inc_fd.write(
            f"const PmInterfaceDescriptor *{self.struct}_descriptor_get(void);\n")
        self.inc_fd.write("#define INTERFACE_{} {}_descriptor_get()\n\n".format(
            upper_name(self.struct), self.struct))

    def gen_struct(self):
        # 生成方法回调类型
        if self.methods:
            for method in self.methods:
                self.inc_fd.write(
                    method.format_method_handler(self.struct) + "\n")
        # 生成信号发送类型
        if self.signals:
            for signal in self.signals:
                if signal.deprecated:
                    self.inc_fd.write("__attribute__((__deprecated__))\n")
                self.inc_fd.write(
                    signal.format_signal_handler(self.struct)[0] + ";\n")
            self.inc_fd.write("\n")

        # 生成结构体
        lines: list[str] = []
        if self.props:
            for prop in self.props:
                for line in prop.format_struct():
                    lines.append(line)
        self.inc_fd.write(f"typedef struct {{\n")
        for line in lines:
            self.inc_fd.write(f"    {line};\n")
        self.inc_fd.write(f"}} {self.struct};\n\n")

        self.inc_fd.write("#define INTERFACE_{}_NAME \"{}\"\n".format(upper_name(self.struct), self.interface))
        for prop in self.props:
            self.inc_fd.write("#define {}_{}_ID {}\n".format(
                self.struct, upper_name(prop.name), prop.id))
            self.inc_fd.write("#define {}_{}_NAME \"{}\"\n".format(
                self.struct, upper_name(prop.name), prop.name))
        self.inc_fd.write("\n")
        for signal in self.signals:
            self.inc_fd.write("#define {}_SIGNAL_{} \"{}\"\n".format(
                self.struct, upper_name(signal.name), signal.name))
        self.inc_fd.write("\n")
        for method in self.methods:
            self.inc_fd.write("#define {}_METHOD_{} \"{}\"\n".format(
                self.struct, upper_name(method.name), method.name))
        self.inc_fd.write("\n")
        pass

    def gen_struct_ops(self):
        pass

    def gen(self):
        log.info(f"Interface: {self.interface}")
        index = 1
        for ele in self.intf:
            if ele.tag == "property":
                self.props.append(Property(ele, index))
                index = index + 1
            elif ele.tag == "method":
                self.methods.append(Method(ele))
            elif ele.tag == "signal":
                self.signals.append(Signal(ele))
            elif ele.tag == "annotation":
                self.annotations.append(Annotation(ele))
        for i in self.annotations:
            if i.name == "bmc.kepler.Interface.Alias":
                self.struct = i.value
            pri = i.get_privilege()
            if pri:
                self.privilege = pri
        # 生成头文件
        self.gen_struct()
        # 生成源码
        self.gen_src()


class InterfaceCli():
    def __init__(self, intf: ET.Element, src_fd: FileIO, inc_fd: FileIO) -> None:
        self.intf = intf
        self.src_fd = src_fd
        self.inc_fd = inc_fd

        self.props: list[Property] = []
        self.methods: list[Method] = []
        self.signals: list[Signal] = []
        self.annotations: list[Annotation] = []
        self.interface = self.intf.get("name")
        self.struct = self.interface.replace(".", "_") + "_Cli"

    def gen_struct(self):
        self.src_fd.write("G_LOCK_DEFINE_STATIC(lock);\n\n")
        # 生成方法回调类型
        if self.methods:
            for method in self.methods:
                if method.deprecated:
                    self.inc_fd.write("__attribute__((__deprecated__))\n")
                self.inc_fd.write(
                    method.format_method_handler_cli(self.struct) + ";\n")
        self.inc_fd.write("\n")
        if self.signals:
            for sig in self.signals:
                self.inc_fd.write(
                    sig.format_signal_handler_cli(self.struct) + ";\n")
        self.inc_fd.write("\n")

    def gen_src(self):
        interface_stru = self.struct + "_interface"
        # 生成结构体
        lines: list[str] = []
        if self.props:
            for prop in self.props:
                if prop.is_private_prop():
                    continue
                for line in prop.format_struct():
                    lines.append(line)
        self.inc_fd.write(f"typedef struct {{\n")
        for line in lines:
            self.inc_fd.write(f"    {line};\n")
        self.inc_fd.write(f"}} {self.struct};\n\n")
        self.inc_fd.write("\n")
        self.inc_fd.write("#define INTERFACE_{}_NAME \"{}\"\n".format(upper_name(self.struct), self.interface))

        for signal in self.signals:
            self.inc_fd.write("#define {}_SIGNAL_{} \"{}\"\n".format(
                self.struct, upper_name(signal.name), signal.name))
        self.inc_fd.write("\n")
        for method in self.methods:
            self.inc_fd.write("#define {}_METHOD_{} \"{}\"\n".format(
                self.struct, upper_name(method.name), method.name))
        self.inc_fd.write("\n")

        prop_stru, property_desc_stru = self.gen_property_info()
        mtd_stru = self.gen_methods_info()
        self.gen_signals_info(interface_stru, prop_stru, property_desc_stru, mtd_stru)
        self.gen_signals_callback()
        self.gen_methods()

    def gen_property_info(self):
        prop_stru = "NULL"
        property_desc_stru = "NULL"
        if self.props:
            prop_stru = f"{self.struct}_property_info"
            liness: list[str] = []
            for prop in self.props:
                if prop.is_private_prop():
                    continue
                liness.append(prop.format_property_info(
                    self.struct, self.src_fd))
            self.src_fd.write(f"static GDBusPropertyInfo {prop_stru}_i[] = {{\n")
            for lines in liness:
                for line in lines:
                    self.src_fd.write(f"    {line}\n")
            self.src_fd.write("};\n\n")

            self.src_fd.write(f"static GDBusPropertyInfo *{prop_stru}[] = {{\n")
            index = 0
            for _ in liness:
                self.src_fd.write(f"&{prop_stru}_i[{index}],\n")
                index = index + 1
            self.src_fd.write("    NULL,\n};\n\n")
            # 检查ID值，不能重复
            ids = []
            for prop in self.props:
                if prop.id in ids:
                    raise errors.XmlErrorException(f"接口属性{prop.name}的ID值{prop.id}重复，退出执行")
                ids.append(prop.id)
            # 生成PmPropertyDescriptor
            property_desc_stru = f"{self.struct}_property_descriptor"
            liness: list[str] = []
            index = 0
            for prop in self.props:
                if prop.is_private_prop():
                    continue
                liness.append(prop.format_field_descriptor(
                    self.struct, index, prop_stru))
                index = index + 1
            self.src_fd.write(f"static PmPropertyDescriptor {property_desc_stru}[] = {{\n")
            for lines in liness:
                for line in lines:
                    self.src_fd.write(f"    {line}\n")
            self.src_fd.write("    {NULL},\n};\n\n")
            self.gen_property_flags(property_desc_stru)

        return prop_stru, property_desc_stru

    def gen_property_flags(self, property_desc_stru):
        """ 生成读取远端属性的操作函数 """
        index = 0
        for prop in self.props:
            if prop.is_private_prop():
                continue
            if prop.emit_changed_signal != "const":
                lines = prop.format_write_remote_function(
                    self.struct, index, property_desc_stru)
                if not lines:
                    index = index + 1
                    continue
                if prop.deprecated:
                    self.inc_fd.write("__attribute__((__deprecated__))\n")
                self.inc_fd.write(lines[0] + ";\n")
                for line in lines:
                    self.src_fd.write(f"{line}\n")
                self.src_fd.write("\n")
            index = index + 1
        self.inc_fd.write("\n")
        # 生成读取远端属性的操作函数
        index = 0
        for prop in self.props:
            if prop.is_private_prop():
                continue
            is_access_valid = prop.access in ("read", "readwrite")
            is_emit_changed_signal_valid = prop.emit_changed_signal in ("invalidates", "false")
            if (is_access_valid and is_emit_changed_signal_valid):
                lines = prop.format_read_remote_function(self.struct, index, property_desc_stru)
                if prop.deprecated:
                    self.inc_fd.write("__attribute__((__deprecated__))\n")
                self.inc_fd.write(lines[0] + ";\n")
                for line in lines:
                    self.src_fd.write(f"{line}\n")
                self.src_fd.write("\n")
            index = index + 1
        self.inc_fd.write("\n")

    def gen_methods_info(self):
        mtd_stru = "NULL"
        if self.methods:
            # 生成GDBusMethodInfo信息
            mtd_stru = f"{self.struct}_method_info"
            liness: list[str] = []
            for method in self.methods:
                liness.append(method.format_method_info(
                    self.struct, self.src_fd))
            self.src_fd.write(f"static GDBusMethodInfo {mtd_stru}_i[] = {{\n")
            for lines in liness:
                for line in lines:
                    self.src_fd.write(f"    {line}\n")
            self.src_fd.write("};\n\n")
            self.src_fd.write(f"static GDBusMethodInfo *{mtd_stru}[] = {{\n")
            index = 0
            for _ in liness:
                self.src_fd.write(f"    &{mtd_stru}_i[{index}], /* method id: {index} */\n")
                index = index + 1
            self.src_fd.write("    NULL,\n};\n\n")
        return mtd_stru

    def gen_signals_info(self, interface_stru, prop_stru, property_desc_stru, mtd_stru):
        sig_stru = "NULL"
        if self.signals:
            sig_stru = f"{self.struct}_signal_info"
            liness: list[str] = []
            for signal in self.signals:
                liness.append(signal.format_signal_info(
                    self.struct, self.src_fd))
            self.src_fd.write(f"static GDBusSignalInfo {sig_stru}_i[] = {{\n")
            for lines in liness:
                for line in lines:
                    self.src_fd.write(f"    {line}\n")
            self.src_fd.write("};\n\n")
            index = 0
            self.src_fd.write(f"static GDBusSignalInfo *{sig_stru}[] = {{\n")
            for _ in liness:
                self.src_fd.write(f"    &{sig_stru}_i[{index}], /* signal id: {index} */\n")
                index = index + 1
            self.src_fd.write("    NULL,\n};\n\n")
        annotation_name = format_annotations(
            self.annotations, self.struct, "interface", self.src_fd)
        self.src_fd.write(f"static GDBusInterfaceInfo {interface_stru} = {{\n")
        self.src_fd.write(f"    .ref_count = -1,\n")
        self.src_fd.write(f"    .name = \"{self.interface}\",\n")
        self.src_fd.write(f"    .methods = {mtd_stru},\n")
        self.src_fd.write(f"    .signals = {sig_stru},\n")
        self.src_fd.write(f"    .properties = {prop_stru},\n")
        self.src_fd.write(f"    .annotations = {annotation_name},\n")
        self.src_fd.write("};\n\n")

        self.src_fd.write(
            f"PmInterfaceDescriptor {self.struct}_descriptor_cli = {{\n")
        self.src_fd.write(f"    .sizeof_object = sizeof({self.struct}),\n")
        self.src_fd.write(f"    .is_remote = 1,\n")
        self.src_fd.write(f"    .properties = {property_desc_stru},\n")
        self.src_fd.write(f"    .methods = NULL,\n")
        self.src_fd.write(f"    .interface = &{interface_stru},\n")
        self.src_fd.write("};\n\n")

        self.src_fd.write(
            f"static void __attribute__((constructor(150))) {self.struct}_register(void)\n{{\n")
        self.src_fd.write(
            f"mc4c_register_interface(&{self.struct}_descriptor_cli);\n}}\n\n")

        self.src_fd.write(
            f"const PmInterfaceDescriptor *{self.struct}_descriptor_get(void) " +
            f"{{\n    return &{self.struct}_descriptor_cli;}}\n")
        self.inc_fd.write(
            f"const PmInterfaceDescriptor *{self.struct}_descriptor_get(void);\n")
        self.inc_fd.write("#define INTERFACE_{} {}_descriptor_get()\n\n".format(
            upper_name(self.struct), self.struct))

    def gen_signals_callback(self):
        # 生成接口消息处理函数（含函数回调和发送信号函数）
        lines = []
        for signal in self.signals:
            handler = signal.get_signal_handler_cli(self.struct)
            stru = f"{self.struct}_{signal.name}_stru"
            prototype = f"PmSignalSubscribe * {self.struct}_Subscribe_{signal.name}({handler} "
            prototype += "handler, const gchar *sender, const gchar *object_path, gpointer user_data)"
            if signal.deprecated:
                self.inc_fd.write("__attribute__((__deprecated__))\n")
            self.inc_fd.write(prototype + ";\n")
            self.src_fd.write(
                f"typedef struct {{gpointer user_data; const gchar *signature; PmSignalSubscribe *sub;" +
                f" {handler} handler;}} {stru};\n\n")
            self.src_fd.write(
                f"static void {handler}_cb(PmHandler handler, const gchar *sender_name, const gchar *signal_name, " +
                f"GVariant *parameters, gpointer user_data) {{\n")
            self.src_fd.write(f"{stru} stru = {{NULL}};")
            self.src_fd.write("int arg_id __attribute__((unused)) = 0;")
            self.src_fd.write("GVariant *in_arg_ __attribute__((unused));")
            self.src_fd.write("GVariant *out_arg_ __attribute__((unused));")
            self.src_fd.write("G_LOCK(lock);\n(void)memcpy_s(&stru, sizeof(stru), user_data, sizeof(stru));")
            self.src_fd.write("G_UNLOCK(lock);\nif (!stru.handler) {\n    return;\n}\n")
            self.src_fd.write("const gchar *type_string = g_variant_get_type_string(parameters);\n")
            self.src_fd.write("if (g_strcmp0(stru.signature, type_string) != 0)\n { \n")
            self.src_fd.write(f"log_warn(\"Signature error, signal:%s, need:%s, get:%s\", " +
                "signal_name, stru.signature, type_string);\n")
            self.src_fd.write("return;}\n")
            lines = signal.get_signal_args_assign_cli()
            for line in lines:
                self.src_fd.write(line + "\n")
            args = signal.format_signal_args_without_type()
            if args != "":
                args = "," + args
            self.src_fd.write(f"stru.handler(handler, sender_name {args}, stru.user_data);\n")
            lines = signal.get_signal_args_free_cli()
            for line in lines:
                self.src_fd.write(line + "\n")
            self.src_fd.write("}\n\n")
            self.src_fd.write(prototype + " {\n")
            self.src_fd.write("if (!handler) {return NULL;}\n")
            self.src_fd.write(f"{stru} *stru = g_new0({stru}, 1);\n")
            self.src_fd.write("stru->user_data = user_data;\n")
            self.src_fd.write("stru->handler = handler;\n")
            signature = signal.format_signal_signature()
            self.src_fd.write(f"stru->signature = \"{signature}\";\n")
            self.src_fd.write(f'stru->sub = mc4c_subscribe_signal(&{self.struct}_descriptor_cli, sender, ' +
                f'"{signal.name}", object_path, {handler}_cb, (gpointer)stru, g_free);\n')
            self.src_fd.write("return stru->sub;\n")
            self.src_fd.write("}\n")

    def gen_methods(self):
        # 生成DBUS回调函数
        for method in self.methods:
            self.src_fd.write(
                method.format_method_handler_cli(self.struct) + "\n")
            self.src_fd.write("{\n")
            self.src_fd.write("int arg_id __attribute__((unused)) = 0;")
            self.src_fd.write(
                "    GVariant *request __attribute__((unused)) = NULL;")
            self.src_fd.write("GVariant *in_arg_ __attribute__((unused));")
            self.src_fd.write("GVariant *out_arg_ __attribute__((unused));")
            lines = method.get_method_args_in_pack()
            if lines:
                self.src_fd.write(
                    "    GVariantBuilder builder;")
                self.src_fd.write(
                    f"g_variant_builder_init(&builder, G_VARIANT_TYPE_TUPLE);\n")
                for line in lines:
                    self.src_fd.write(f"    {line}\n")
                self.src_fd.write(
                    f"request = g_variant_builder_end(&builder);\n")
            reply_type = method.format_method_out_signature()
            self.src_fd.write(
                f"log_debug(\"/* ********************* call class method " +
                f"{method.name} start  *********************** */\");\n")
            if reply_type == "":
                self.src_fd.write(
                    f"GVariant *parameters = mc4c_object_call_method(handler, \"" +
                    f"{method.name}\", request, NULL, G_DBUS_CALL_FLAGS_NONE, timeout_msec, NULL, error);")
            else:
                self.src_fd.write(
                    f"GVariant *parameters = mc4c_object_call_method(handler, \"" +
                    f"{method.name}\", request, (const GVariantType *)\"{reply_type}\", " +
                    "G_DBUS_CALL_FLAGS_NONE, timeout_msec, NULL, error);")
            self.src_fd.write(
                f"log_debug(\"/* ********************* call class method " +
                f"{method.name} finish: *********************** */\");\n")
            self.src_fd.write("if(!parameters) {return -1;\n}")
            lines = method.get_method_args_out_assign()
            for line in lines:
                self.src_fd.write(f"    {line}\n")
            self.src_fd.write(f"    g_variant_unref(parameters);\n")
            self.src_fd.write(f"    return 0;\n")
            self.src_fd.write(f"}}\n\n")

    def gen(self):
        log.info(f"Interface: {self.interface}")
        index = 1
        for ele in self.intf:
            if ele.tag == "property":
                self.props.append(Property(ele, index))
                index = index + 1
            elif ele.tag == "method":
                self.methods.append(Method(ele))
            elif ele.tag == "signal":
                self.signals.append(Signal(ele))
            elif ele.tag == "annotation":
                self.annotations.append(Annotation(ele))
        for i in self.annotations:
            if i.name == "bmc.kepler.Interface.Alias":
                self.struct = i.value + "_Cli"
        # 生成头文件
        self.gen_struct()
        # # 生成源码
        self.gen_src()


class CodeGenerate():
    def __init__(self) -> None:
        pass

    @staticmethod
    def _open_file(filename) -> TextIOWrapper:
        fd = os.fdopen(os.open(filename, os.O_RDWR | os.O_CREAT | os.O_APPEND,
                               stat.S_IWUSR | stat.S_IRUSR), 'a+')
        fd.seek(0)
        find_start = False
        while True:
            line = fd.readline()
            if not line:
                fd.seek(0)
                break
            line = line.strip()
            if line == "":
                continue
            # 找到结束注释时退出
            if line.endswith("*/"):
                break
            if not find_start and line.startswith("/*"):
                find_start = True
                continue
            # 未找到起始注释符，清理内容并退出
            if not find_start:
                fd.seek(0)
                break
            if line.startswith("*"):
                continue

        fd.truncate(fd.tell())
        pos = fd.tell()
        if pos == 0:
            fd.write("/*\n")
            fd.write(" *  Copyright (c) Huawei Technologies Co., Ltd. 2023-{}. All rights reserved.\n"
                     .format(time.strftime("%Y", time.localtime())))
            fd.write(" *\n")
            fd.write(" *  this file licensed under the Mulan PSL v2.\n")
            fd.write(" *  You can use this software according to the terms and conditions of the Mulan PSL v2.\n")
            fd.write(" *  You may obtain a copy of Mulan PSL v2 at: http: //license.coscl.org.cn/MulanPSL2\n")
            fd.write(" *\n")
            fd.write(" *  THIS SOFTWARE IS PROVIDED ON AN \"AS IS\" BASIS, WITHOUT ")
            fd.write("WARRANTIES OF ANY KIND, EITHER EXPRESS OR\n")
            fd.write(" *  IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, ")
            fd.write("MERCHANTABILITY OR FIT FOR A PARTICULAR\n")
            fd.write(" *  PURPOSE.\n")
            fd.write(" *  See the Mulan PSL v2 for more details.\n")
            fd.write(" *\n")
            fd.write(" *  Author: codegenerate\n")
            fd.write(" *  Create: {}\n".format(time.strftime("%Y-%m-%d", time.localtime())))
            fd.write(" */\n\n")
        else:
            fd.write("\n")
        return fd

    def auto_gen(self, service_yml: str, mds_json: str = None):
        with open(service_yml, "r", encoding="utf-8") as fp:
            yaml_cfg = yaml.safe_load(fp)
            mds_cfg = None
            if mds_json is not None:
                with open(mds_json, "r") as fp:
                    mds_cfg = json.load(fp)
            self._gen_bus_info(yaml_cfg, mds_cfg)

            service = yaml_cfg.get("interfaces", None)
            requires = yaml_cfg.get("requires", None)
            if service is None and requires is None:
                return
            # 克隆interface源码
            repo = yaml_cfg.get("interfaces_repo", None)
            if repo is None:
                log.warning("Missing repo in " + service_yml)
                return
            repo_url = repo.get("url", None)
            repo_branch = repo.get("branch", "master")
            if repo_url is None:
                log.warning("Missing repo.url in " + service_yml)
                return
            shutil.rmtree(".interfaces", ignore_errors=True)
            tools.run_command(f"git clone --depth=1 -b {repo_branch} {repo_url} .interfaces")
            # 处理源码
            self.__gen_service(service, True)
            self.__gen_service(requires, False)

    def gen(self, xml_file: str, is_server=True):
        src_file_name = xml_file.split("/")[-1][:-4]
        src_file = src_file_name.lower() + ".c"
        inc_file = src_file_name.lower() + ".h"
        if not is_server:
            os.makedirs(misc.CLI, exist_ok=True)
            src_file = os.path.join(misc.CLI, src_file).lower()
            inc_file = os.path.join(misc.CLI, inc_file).lower()
        src_fd = self._open_file(src_file)
        inc_fd = self._open_file(inc_file)
        src_fd.write("#include \"mc4c/public.h\"\n")
        if not is_server:
            src_fd.write("#include \"{}\"\n".format(inc_file))
            header_macro = "CLI_{}_H".format(
                src_file_name.replace(".", "_").upper())
        else:
            src_fd.write(f"#include \"{inc_file}\"\n")
            header_macro = "{}_H".format(src_file_name.replace(".", "_").upper())
        src_fd.write("\n")
        inc_fd.write("#ifndef {}\n".format(header_macro))
        inc_fd.write("#define {}\n".format(header_macro))
        inc_fd.write("\n")

        et = ET.parse(xml_file)
        root = et.getroot()
        for node in root.findall("interface"):
            if is_server:
                intf = Interface(node, src_fd, inc_fd)
                intf.gen()
            else:
                intf = InterfaceCli(node, src_fd, inc_fd)
                intf.gen()

        inc_fd.write("#endif /* {} */\n\n".format(header_macro))
        inc_fd.close()
        src_fd.close()
        try:
            clang_format = shutil.which("clang-format")
            subprocess.run([clang_format, "--version"],
                           stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
        except Exception:
            log.error("Command clang-format not found , skip format service files")
            return
        subprocess.run(
            [clang_format, f"--style=file", "-i", inc_file, src_file])

    def __gen_service(self, interfaces, is_remote):
        if interfaces is None:
            return
        for intf in interfaces:
            xml_file = intf + ".xml"
            if not os.path.isfile(xml_file):
                xml_file = os.path.join(
                    ".interfaces", intf + ".xml")
                if not os.path.isfile(xml_file):
                    log.error(f"service file {xml_file} not exist")
                    continue
            self.gen(xml_file, is_remote)
    # 打包文件句柄，无有效注释时生成注释，有注释时跳过注册

    def _gen_bus_info(self, yaml_cfg, mds_cfg=None):
        app_name = None
        bus_name = ""
        if mds_cfg is not None:
            app_name = mds_cfg.get("name", None)
        if app_name is not None:
            bus_name = "bmc.kepler." + app_name
        else:
            bus_name = yaml_cfg.get("bus_name", None)
            if bus_name is None:
                log.info("Get bus_name failed")
                return
            chunks = bus_name.split(".", -1)
            app_name = chunks[len(chunks) - 1]

        inc_fd = self._open_file("mc4c_service.h")
        inc_fd.write("#ifndef MC4C_SERVICE_H\n#define MC4C_SERVICE_H\n\n")
        inc_fd.write("#define MC4C_BUS_NAME \"{}\"\n\n".format(bus_name))
        inc_fd.write("#define MC4C_APP_NAME \"{}\"\n\n".format(app_name))
        inc_fd.write("#endif /* MC4C_SERVICE_H */\n\n")
        inc_fd.close()

        src_fd = self._open_file("mc4c_service.c")
        src_fd.write("#include \"mc4c/public.h\"\n#include \"mc4c_service.h\"\n\n")

        if mds_cfg is not None:
            src_fd.write("#include \"mc4c/bmc.kepler.microcomponent.h\"\n\n")
            obj_name = "/bmc/kepler/{}/MicroComponent".format(app_name)
            src_fd.write("\nstatic void micro_component_start(void)\n{\n")
            src_fd.write(
                "    const MicroComponent *component = mc4c_object_new(INTERFACE_MICRO_COMPONENT, mc4c_bus_name(),\n")
            src_fd.write("        \"{}\", NULL);\n".format(obj_name))
            src_fd.write("    if (component == NULL) {\n        log_error(\"Create object failed, interface: %s,\"\n")
            src_fd.write("            \"object: {}\",\n".format(obj_name))
            src_fd.write("            INTERFACE_MICRO_COMPONENT_NAME);\n    } else {\n")
            src_fd.write("        mc4c_object_present_set((PmHandler)component, TRUE);\n")
            author = mds_cfg.get("author", "")
            src_fd.write("        MicroComponent_set_Author(component, \"{}\");\n".format(author))
            description = mds_cfg.get("description", "")
            src_fd.write("        MicroComponent_set_Description(component, \"{}\");\n".format(description))
            src_fd.write("        MicroComponent_set_Pid(component, (gint32)getpid());\n")
            version = mds_cfg.get("version", "")
            src_fd.write("        MicroComponent_set_Version(component, \"{}\");\n".format(version))
            mds_license = mds_cfg.get("license", "")
            src_fd.write("        MicroComponent_set_License(component, \"{}\");\n".format(mds_license))
            src_fd.write("        MicroComponent_set_Name(component, \"{}\");\n".format(app_name))
            src_fd.write("        MicroComponent_set_Status(component, \"Starting\");\n".format(app_name))
            src_fd.write("    }\n}\n\n")
            src_fd.write("static void __attribute__((constructor(150))) micro_component_init(void)\n{\n")
            src_fd.write("    mc4c_register_module(micro_component_start, \"micro_component\", 8);\n}\n")

        src_fd.write(f"static void __attribute__((constructor(101))) service_register(void)\n{{\n")
        src_fd.write("    mc4c_bus_name_set(MC4C_BUS_NAME);\n}\n")
        src_fd.close()
