#!/usr/bin/python
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2023-2025. All rights reserved.

import os
import xml.etree.ElementTree as ET
from bmcgo_pro.utils.tools import Tools

tools = Tools("package_sign")
log = tools.log


class Sign:
    """ 定制化修改签名 xml 文件的配置
    """
    def __init__(self, sign_xml_name: str):
        """ 初始化

        Args:
            sign_xml_name (str): 要修改的 xml 文件名字
        """
        self.name = sign_xml_name
        # 解析属性树
        self.tree = ET.parse(self.name)
        # 获取根节点数据
        self.root = self.tree.getroot()

    def modify_attribute(self, path: str, attribute: str, new_content: str):
        """ 修改元素的属性值

        Args:
            path (str): 元素路径, 此接口根路径为signtask, 比如 sign_vercfg_pss.xml 中 fileset 这里参数直接传入 fileset
            attribute (str): 元素的属性名, 比如 fileset 的 path 属性, 这里直接写 path
            new_content (str): 要设置的属性值, 如果要设置为 aa, 那么直接填入 aa

        Raises:
            AttributeError: 如果元素路径没有找到, 返回属性错误
        """
        path = f"signtask/{path}"
        element = self.root.find(path)
        if element is None:
            raise AttributeError(f"在 {self.name} 文件中没有 {path} 属性")
        element.set(attribute, new_content)

    def get_text(self, path: str, default_value=""):
        """ 查询元素的文本

        Args:
            path (str): 元素路径, 此接口根路径为signtask, 比如 sign_vercfg_pss.xml 中 fileset 这里参数直接传入 fileset

        Raises:
            AttributeError: 如果元素路径没有找到, 返回属性错误
        """
        path = f"signtask/{path}"
        element = self.root.find(path)
        if element is None:
            if default_value is not None:
                return default_value
            raise AttributeError(f"在 {self.name} 文件中没有 {path} 属性")
        return element.text

    def modify_text(self, path: str, new_content: str):
        """ 修改元素的文本

        Args:
            path (str): 元素路径, 此接口根路径为signtask, 比如 sign_vercfg_pss.xml 中 fileset 这里参数直接传入 fileset
            new_content (str): 要设置的属性值, 如果要设置为 aa, 那么直接填入 aa

        Raises:
            AttributeError: 如果元素路径没有找到, 返回属性错误
        """
        path = f"signtask/{path}"
        element = self.root.find(path)
        if element is None:
            raise AttributeError(f"在 {self.name} 文件中没有 {path} 属性")
        element.text = new_content

    def save(self):
        """ 只保存到传入的文件名中
        """
        self.tree.write(self.name)

    def sign(self):
        """ 签名
        """
        self.tree.write(self.name)
        log.info("正在执行签名目录: %s", os.getcwd())
        log.info("正在执行签名文件: %s", self.name)
        sys_root = os.path.abspath('/')
        # 在哪个目录下执行, 则直接在哪个目录下签名
        tools.run_command(f"java -jar {sys_root}usr/local/signature-jenkins-slave/signature.jar {self.name}")
        os.remove(self.name)

if __name__ == "__main__":
    sg = Sign("sign_vercfg_pss.xml")
    sg.modify_attribute("fileset", "path", "aa/bb/cc")
    sg.modify_text("fileset/include", "aa.list")
    sg.modify_text("crlfile", "dd/ee/ff/xx.txt")
    sg.sign()
