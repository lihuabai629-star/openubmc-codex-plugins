#!/usr/bin/env python3
# coding: utf-8
# Copyright © Huawei Technologies Co., Ltd. 2025. All rights reserved.
from dataclasses import dataclass


@dataclass
class StripConfig:
    exclude_roles: list
    include_roles: list
    no_strip_file_output: str
    strip_cmd: str
    strip_dir: str
    strip_comment: bool = False
