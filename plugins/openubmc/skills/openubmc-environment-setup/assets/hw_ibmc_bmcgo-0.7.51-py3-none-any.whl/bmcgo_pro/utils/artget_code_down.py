#!/usr/bin/env python
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.

"""
文件名：artget_code_down.py
功能：解析 artget源码清单 并下载源码
版权信息：华为技术有限公司，版本所有(C) 2019-2020
"""

import xml.sax
import os
import time
from multiprocessing import Process

from bmcgo import errors

from bmcgo import misc
from bmcgo_pro.utils.tools import Tools

tools = Tools()
log = tools.log


class Repo:
    "初始化一个仓库，存储仓的基本信息"
    def __init__(self, repo_base, local_path, revision, branch):
        self.repo_url = repo_base
        self.local_path = local_path
        self.revision = revision
        self.branch = branch
        # 默认不分group
        self.group = "all"

    def get_remote_url(self):
        "获取仓的url信息"
        return self.repo_url

    def get_local_path(self):
        "获取仓本地路径"
        return self.local_path

    def get_revision(self):
        "获取仓版本号"
        return self.revision

    def get_branch(self):
        "获取仓分支名"
        return self.branch


class FileHandler(xml.sax.ContentHandler):
    """xml自定义解析接口，继承自xml.sax.ContentHandler"""
    def __init__(self, repodict: dict):
        """存储处理过的信息变量定义

        Args:
            repodict (dict): 用于存储多个仓的信息
        """
        super(FileHandler, self).__init__()
        self.current_data = ""
        self.repodict = repodict
        self.id = 1

    # 元素开始事件处理
    def startElement(self, name: str, attrs: dict):
        """处理传入的数据，形成类字典
        Args:
            name (str): 符合要求的name才会被处理
            attrs (dict): 属性字典
        """
        self.current_data = name
        if name == "fileidentify":
            log.debug("创建句柄库 ...")
        # 不满足要求的tag直接返回
        else:
            return
        # 仓库的四个属性值
        newrepo = Repo(attrs[misc.REPO_BASE], attrs["localpath"], attrs["revision"], attrs["branch"])
        if (self.repodict and self.repodict.get(misc.REPO_BASE)):
            log.info("复制仓库 ! {}".format(attrs[misc.REPO_BASE]))
            return
        # 下载目标路径为空不放入字典
        if newrepo.get_local_path() == "":
            return
        # 以id做为key值，多个仓，保存多个属性
        self.repodict[self.id] = newrepo
        self.id += 1


class ArtgetDownload():
    def __init__(self):
        pass
    """
    这个对象在使用的时候会被实例化，而且被循环调用
    今后编码尽量避免，阅读非常困难
    """
    @staticmethod
    def git_clone(clone_cmd: str, reset_cmd: str):
        """下载指定分支并切换到指定节点

        Args:
            clone_cmd (str): 克隆命令
            reset_cmd (str): 切换到指定节点或恢复修改命令
        """
        # 延时1s等任务创建结束，防止偶现文件被锁住导致的git下载失败
        time.sleep(1)
        tools.run_command(clone_cmd)
        if reset_cmd is not None:
            tools.run_command(reset_cmd)

    @staticmethod
    def after_download(repodict: dict):
        """并行下载到不同目录，最终归档到一起，这里面的key是1,2,3,4
        Args:
            repodict (dict): 已经获取到的仓库配置信息
        """
        for key in repodict.keys():
            local_path = repodict[key].get_local_path()
            if os.path.exists(str(key)):
                tools.run_command(f"mkdir -p {local_path}")
                tools.run_command(f"cp -rf {key}/. {local_path}")
                tools.run_command(f"rm -rf {key}")
            else:
                log.info(f"{local_path} 没有下载")

    @staticmethod
    def __parse_src_list(srclistpath: str, repodict: dict):
        """解析xml
        Args:
            srclistpath (str): xml的配置路径
            repodict (dict): 用于接收xml配置信息的字典
        """
        if not os.path.exists(srclistpath):
            raise errors.BmcGoException(f"{srclistpath} 未找到")
        # 创建一个 XMLReader
        parser = xml.sax.make_parser()
        handler = FileHandler(repodict)
        parser.setContentHandler(handler)
        parser.parse(srclistpath)

    def download(self, src_xml_path: str, dest_path: str, listcon: list, key_value="-osRUh8ERTgFWJd_aLg4"):
        """下载操作
        Args:
            src_xml_path (str): 下载的xml的配置路径
            dest_path (str): 下载文件的目标路径
            listcon (list): 不需要下载的仓库列表
            key_value (str, optional): 个人token值，默认被设置为 "-osRUh8ERTgFWJd_aLg4".
        """
        repodict = {}
        self.__parse_src_list(src_xml_path, repodict)
        self.__download(dest_path, listcon, key_value, repodict)
        self.after_download(repodict)

    def get_repodict(self, src_xml_path: str):
        """仅获取xml配置
        Args:
            src_xml_path (str): 下载的xml的配置路径
        Returns:
            dict : 仓库的配置信息字典
        """
        repodict = {}
        self.__parse_src_list(src_xml_path, repodict)
        return repodict

    # 下载源码到dest_path
    def __download(self, dest_path: str, listcon: list, key_value: str, repodict: dict):
        """依据配置信息进行下载
        Args:
            dest_path (str): 目标下载路径
            listcon (list): 不下载的模块的列表
            key_value (str): 下载使用的token字符串
            repodict (dict): 已经获取到的仓库配置信息
        """
        if listcon == "":
            listcon_list = []
        else:
            listcon_list = listcon.split(' ')
        log.info(f"不需要下载的模块列表: {listcon_list}")

        # 目标目录清理与新建
        tools.remove_path(dest_path)
        tools.check_path(dest_path)

        req_process_list = []
        for key in repodict.keys():
            flag = False
            # 如果在不下载的列表里面，则不进行下载
            for module in listcon_list:
                if module in repodict[key].get_remote_url():
                    flag = True
                    break
            if flag:
                continue

            # 将ssh配置修改为https配置
            remote_url = repodict[key].get_remote_url().replace("ssh://git@", "https://")
            remote_url = remote_url.replace(":2222", "")

            # 开源的仓，只有部分人拥有权限，使用私人token，也就是key_value
            if "open.codehub.huawei.com" not in repodict[key].get_remote_url() and key_value != "":
                remote_url = remote_url.replace("//", f"//{key_value}:{key_value}@")

            branch = repodict[key].get_branch().replace(misc.REF_TAGS, "")
            os.chdir(dest_path)
            if repodict[key].get_local_path() != "." or repodict[key].get_local_path() != "./":
                tools.remove_path(repodict[key].get_local_path())

            if repodict[key].get_branch().find(misc.REF_TAGS) != -1:
                clone_cmd = f"git clone {remote_url} -b {branch} --depth=1 {key}"
                reset_cmd = None
            else:
                clone_cmd = f"git clone {remote_url} -b {branch} {key}"
                reset_cmd = "cd {} && git reset --hard {}".format(key, repodict[key].get_revision())
            req_process = Process(target=self.git_clone, args=(clone_cmd, reset_cmd))
            req_process.start()
            req_process_list.append(req_process)

        # 等待线程结束
        for req_process in req_process_list:
            req_process.join()