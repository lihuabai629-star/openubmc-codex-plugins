#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
"""
功 能：打包过程中压缩文件等预处理
版权信息：华为技术有限公司，版本所有(C) 2019-2023
"""

import os
import tempfile

from bmcgo import errors

from bmcgo_pro.tasks.task import Task
from bmcgo_pro.logger import Logger

log = Logger("file_preprocess")


class FilePreProcess(Task):
    def __init__(self, config, work_name="", preprocess_files=None, build_path=""):
        super(FilePreProcess, self).__init__(config, work_name=work_name)
        self.preprocess_files = preprocess_files
        self.build_path = build_path

    def run(self):
        if not os.path.isdir(self.build_path):
            log.info("不合法的 build_path")
            return
        if self.preprocess_files is None:
            log.info("在配置中没有进程文件")
            return
        for preprocess_file in self.preprocess_files:
            dst = preprocess_file.get("output")
            dst_fp = os.path.basename(dst)

            temp_dir = tempfile.TemporaryDirectory(prefix="fild_process_", dir=self.build_path)
            self.chdir(temp_dir.name)
            self.copy_manifest_files(preprocess_file.get("files"))
            # 执行预处理命令
            cmd = preprocess_file.get("cmd")
            if cmd.find("*") >= 0:
                raise errors.ConfigException(f"文件处理进程禁止使用 '*', 无法执行命令: {cmd}")
            if cmd.startswith("tar"):
                self.run_command(cmd, ignore_error=True)
            else:
                self.run_command(cmd)
            if not os.path.isfile(dst):
                raise OSError(f"文件处理进程失败, 未找到输出文件: {dst}")
            # 处理完成后切回build目录
            self.chdir(self.build_path)
            # 如果output存在路径，移动到目标目录
            if "/" in dst:
                dirname = os.path.dirname(dst)
                os.makedirs(dirname, exist_ok=True)
            src = os.path.join(temp_dir.name, dst_fp)
            self.run_command(f"cp {src} {dst}")
