#!/usr/bin/python3
# coding: utf-8
# 执行bmcgo以及bmc studio安装的一些列流程
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
import os
import configparser
import tempfile
import re
import shutil

from bmcgo_pro.utils.tools import Tools
from bmcgo_pro import __version__

tools = Tools("install")
log = tools.log


class InstallPackage(object):
    def __init__(self, app_name, version, pip_pkg_name, deb_pkg_name):
        self.app_name = app_name
        self.version = version
        self.pip_pkg_name = pip_pkg_name
        self.deb_pkg_name = deb_pkg_name
        self.pip_cmd_args = ""
        if app_name == "bmc-studio":
            self.command_prefix = "env DEBIAN_FRONTEND=noninteractive AUTO_ACCEPT_LICENSE=true"
        else:
            self.command_prefix = ""
        with open("/etc/issue", "r") as fp:
            issue = fp.readline()
            if issue.startswith("Ubuntu 24.04"):
                self.pip_cmd_args = "--break-system-packages"

    def get_current_version(self, pip_name):
        # 通过pip命令查看当前安装的软件版本
        cmd = shutil.which(self.app_name)
        if cmd and cmd.startswith("/home"):
            package_info = tools.run_command(
                f"pip3 show {pip_name}", ignore_error=True, command_echo=False, capture_output=True
            )
        else:
            package_info = tools.run_command(
                f"pip3 show {pip_name}", ignore_error=True, command_echo=False, capture_output=True
            )
        if not package_info:
            return ""
        package_info = package_info.stdout.replace("\n", " ")
        match = re.match(r".*([0-9]+\.[0-9]+\.[0-9]+)", package_info)
        if not match:
            return ""

        return match.group(1)

    def uninstall_bmcgo(self, sudo):
        bmcgo_pkg_list = ["openubmc-bingo", "hw-ibmc-bmcgo"]
        ret = tools.pipe_command(["dpkg -l", "grep -E 'bingo|bmcgo'"], capture_output=True, ignore_error=True)[0]
        for pkg in bmcgo_pkg_list:
            tools.run_command(f"pip3 uninstall {pkg} {self.pip_cmd_args} -y", sudo=sudo, show_log=True)
            if pkg in str(ret):
                tools.run_command(f"dpkg -P {pkg}", sudo=sudo, show_log=True)

    def install(self):
        pip_pkg_name = self.pip_pkg_name
        install_version = self.version
        if self.version != "=latest":
            ran_version = self.version.split(' ')
            for _, v in enumerate(ran_version):
                match = re.search(f"^(<=|>=|<|>|==)", v)
                if match:
                    pip_pkg_name = pip_pkg_name + v + ","
                elif "=" in v:
                    pip_pkg_name = pip_pkg_name + "=" + v + ","
                    install_version = v[1:]
                else:
                    pip_pkg_name = pip_pkg_name + "==" + v + ","
                    install_version = v
            pip_pkg_name = pip_pkg_name[:-1]
        # 获取bmcgo版本
        version = self.get_current_version(self.pip_pkg_name)
        if version and version == install_version:
            log.warning(f"{self.app_name}已经安装{version}版本，请勿重复安装")
            return
        log.info(f"开始下载并安装{pip_pkg_name}")
        # 先更新
        sudo = False if os.getuid() == 0 else True
        if "bmcgo" in self.pip_pkg_name:
            self.uninstall_bmcgo(sudo)
        else:
            tools.run_command(f"pip3 uninstall '{self.pip_pkg_name}' {self.pip_cmd_args} -y", sudo=sudo, show_log=True)
        tools.run_command(f"pip3 install --upgrade '{pip_pkg_name}' {self.pip_cmd_args}", sudo=sudo, show_log=True)
        log.info(f"开始下载并安装{self.deb_pkg_name}.deb")
        version = self.get_current_version(self.pip_pkg_name)
        if not version:
            return
        if self.app_name == "bmc-studio":
            self.deb_pkg_name = f"{self.deb_pkg_name}-{version}.deb"
        else:
            self.deb_pkg_name = f"{self.deb_pkg_name}_x86_64.deb"
        self.install_deb_from_cmc(self.app_name, version, self.deb_pkg_name, self.command_prefix)
        if self.app_name == "bmcgo":
            self._down_and_install_bingo("openubmc-bingo", "openubmc-bingo", "openubmc_bingo_amd64.deb")

    def install_deb_from_cmc(self, app_name, version, deb_pkg_name, prefix=""):
        tmpdir = tempfile.TemporaryDirectory()
        deb_file = os.path.join(tmpdir.name, deb_pkg_name)
        url = "https://cmc.centralrepo.rnd.huawei.com/artifactory/product_generic/"
        url += f"hw-ibmc-generic/{app_name}/{version}/{deb_pkg_name}"
        tools.run_command(f"wget --no-check-certificate {url} -O {deb_file}")
        tools.run_command("apt update", sudo=True)
        ret = tools.run_command(f"{prefix} dpkg -i {deb_file}", sudo=True, ignore_error=True)
        tools.run_command("apt install -y -f", sudo=True)
        if not ret or (ret and ret.returncode != 0):
            tools.run_command(f"dpkg -i {deb_file}", sudo=True, ignore_error=True)

    def _down_and_install_bingo(self, app_name, pip_name, deb_name):
        version = self.get_current_version(pip_name)
        self.install_deb_from_cmc(app_name, version, deb_name)


class InstallBmcgo(InstallPackage):
    def __init__(self, version=""):
        super(InstallBmcgo, self).__init__("bmcgo", version, "hw-ibmc-bmcgo", "hw-ibmc-bmcgo")
        self.current_version = __version__


class InstallStudio(InstallPackage):
    def __init__(self, version=""):
        super(InstallStudio, self).__init__("bmc-studio", version, "hw-ibmc-bmc-studio", "bmc-studio")
        self.current_version = self.get_current_version(self.pip_pkg_name) or "1.1.2"

    def install(self):
        tools.run_command(f"dpkg -P bmc-studio", sudo=True, ignore_error=True)
        self.install_deb_from_cmc("cangjie-runtime", "1.0.0", "cangjie-runtime-1.0.0_amd64.deb")
        super().install()
