#!/usr/bin/env python
# coding: utf-8
# Copyright © Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.

import os
import subprocess
import shutil
import stat
import threading
import re
import json
from bmcgo import misc
from bmcgo.utils.tools import Tools as BmcgoTools
from bmcgo_pro.utils.data_classes import StripConfig

lock = threading.Lock()


class Tools(BmcgoTools):
    """
    功能描述：公共类定义全局变量,公共函数
    接口：无
    """


    @staticmethod
    def create_pid_file(pid_dir, pid=0):
        """
        创建PID文件
        """
        if pid == 0:
            pid = os.getpid()
        pid_str = str(pid)
        pid_file = os.path.join(pid_dir, pid_str + ".pid")
        lock.acquire()
        with os.fdopen(os.open(pid_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                                stat.S_IWUSR | stat.S_IRUSR), 'w') as file_handler:
            file_handler.write(pid_str + "\n")
            file_handler.close()
        lock.release()

    @staticmethod
    def get_hi171x_module_symver_option(module_symvers_path: str):
        sha256 = Tools.sha256sum(module_symvers_path)
        return ("module_symvers", sha256)

    @staticmethod
    def make_strip_cmd(exclude_roles, include_roles, strip_dir, no_strip_file_output):
        cmd = ["sudo find {} -type f ".format(strip_dir)]
        for role in exclude_roles:
            cmd.append(f'grep -v "{role}"')
        for role in include_roles:
            cmd.append(f'grep "{role}"')
        cmd.append("sudo xargs -P 0 -I {{}} file {{}}".format(no_strip_file_output))
        cmd.append("grep 'not stripped'")
        cmd.append("awk -F: '{{print $1}}'")
        return cmd

    def install_platform_v1(self, platform_package, stage, remote):
        self.fix_platform(platform_package, stage)
        rtos_version = platform_package.get("options", {}).get(
            "rtos_version", "rtos_v2"
        )
        enable_haf = platform_package.get("options", {}).get(
            "enable_haf", True
        )
        conan_cmd = f"{platform_package[misc.CONAN]} -o rtos_version={rtos_version}"
        if not enable_haf:
            conan_cmd += f" -o enable_haf={enable_haf}"
        if remote:
            conan_cmd += f" -r {remote}"
        self.run_command(f"conan install {conan_cmd} --build=missing")
        version_split = re.split(r"[/, @]", platform_package[misc.CONAN])
        package_conan_dir = os.path.join(
            os.path.expanduser("~"), ".conan/data/", *version_split
        )
        cmd = f"conan info {conan_cmd} -j"
        cmd_info = self.run_command(
            cmd,
            capture_output=True,
        )
        info = json.loads(cmd_info.stdout)
        for i in info:
            package_conan_dir = os.path.join(
                package_conan_dir, "package", i["id"], rtos_version
            )
        return package_conan_dir

    def install_platform(self, platform_package, stage, remote, update_conan_cache=False):
        if misc.conan_v1():
            return self.install_platform_v1(platform_package, stage, remote)
        else:
            return self.install_platform_v2(platform_package, remote, update_conan_cache)

    def strip(self, strip_config: StripConfig):
        cmd = self.make_strip_cmd(
            strip_config.exclude_roles,
            strip_config.include_roles,
            strip_config.strip_dir,
            strip_config.no_strip_file_output,
        )
        self.pipe_command(cmd, strip_config.no_strip_file_output, ignore_error=True)
        with open(strip_config.no_strip_file_output, "r") as fp:
            files = fp.readlines()
        for file in files:
            file = file.strip()
            cmd = "sudo {} -d {}".format(strip_config.strip_cmd, file)
            self.run_command(cmd)
            if strip_config.strip_comment:
                cmd = "sudo {} -d {} -R .comment".format(strip_config.strip_cmd, file)
                self.run_command(cmd)

    def remove_path_and_create(self, path, force=False):
        """
        创建目录，如果目录存在先删除后创建
        """
        if force:
            self.run_command(f"rm -rf {path}", echo_command=False, sudo=True)
        elif os.path.isdir(path):
            shutil.rmtree(path)
        os.makedirs(path)

    def copy_file_with_prefix(self, path: str, dst_dir: str):
        """
        创建目录，如果目录存在先删除后创建
        """
        src_dir = os.path.dirname(path)
        for file in os.listdir(src_dir):
            file = os.path.join(src_dir, file)
            if file.startswith(path):
                self.run_command(f"cp -rP {file} {dst_dir}")

    def get_codehub_token(self):
        codehub_token = os.getenv("codehub_token")
        try:
            if codehub_token is None:
                ret, git_token_conf = subprocess.getstatusoutput(
                    "git config --get-all credential.helper"
                )
                git_token_file = git_token_conf.split(" ")[-1] if ret == 0 else ""
                token_set = set()
                with open(git_token_file, mode="r") as tokenf:
                    lines = tokenf.readlines()
                for line in lines:
                    token_set.add(line.strip("\n").split(":")[-1].split("@")[0])
                codehub_token = token_set
        except Exception:
            self.log.error(
                "codehub token 获取失败, 请检查 .git-credentials 配置或 codehub_token 环境变量"
            )
        return codehub_token

    def get_conan2_recipe_path(self, pkg_name):
        cmd = f"conan cache path {pkg_name}"
        result = self.run_command(cmd, capture_output=True, ignore_error=True)
        ret_code = result.returncode
        path = result.stdout.strip()
        if ret_code != 0 or not os.path.isdir(path):
            self.log.info(f"{pkg_name}包未获取到recipe目录")
            return None
        else:
            return path
