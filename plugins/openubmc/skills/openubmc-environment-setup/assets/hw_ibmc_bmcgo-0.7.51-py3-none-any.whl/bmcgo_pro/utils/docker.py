#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2020. All rights reserved.
import shutil
import subprocess
import os
import time

from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.tasks.task_build_docker import DOCKER_LOGINUSER

tool = Tools("docker_build")
log = tool.log


class Docker:
    def __init__(self, name: str, container_tag: str, cmd: str, port="9300", \
                 network="", env="", volumns="", work_path="", log_name=""):
        self.name = name
        self._network = network
        self._env = env
        self._volumns = volumns
        self._work_path = work_path
        # 端口可以自定义, 默认为 9300
        self.port = port
        self.container_tag = container_tag
        self.log_name = log_name
        self.cmd = cmd
        self.docker_exists = self._check_docker()

    @property
    def user_home(self):
        if DOCKER_LOGINUSER == "root":
            return "/root"
        return f"/home/{DOCKER_LOGINUSER}"

    @property
    def network(self):
        if self._network == '':
            return ''
        else:
            return f"--network {self._network}"

    @network.setter
    def network(self, network):
        self._network = network

    @property
    def env(self):
        if self._env == '':
            return ''
        else:
            env_str = f"-e {' -e '.join(self._env.split(','))}"
        return env_str

    @env.setter
    def env(self, env):
        self._env = env

    @property
    def work_path(self):
        if self._work_path == '':
            return ''
        else:
            return f"-w {self._work_path}"

    @work_path.setter
    def work_path(self, work_path):
        self._work_path = work_path

    @property
    def volumns(self):
        if self._volumns == '':
            return ''
        else:
            volumns_str = f"-v {' -v '.join(self._volumns.split(','))}"
        return volumns_str

    @volumns.setter
    def volumns(self, volumns):
        self._volumnts = volumns

    @staticmethod
    def run_command(cmd, ignore_error=False):
        result = tool.run_command(cmd, capture_output=True, ignore_error=True)
        log.info(f"docker.py: {cmd}")
        exitcode = result.returncode
        error = result.stderr
        if exitcode != 0 and ignore_error is False:
            log.error("docker 命令执行错误: %s\nErrorCode: %s\nErrorMsg: %s", cmd, exitcode, error)
            raise Exception("请检查命令")

    @staticmethod
    def _check_docker():
        if shutil.which("docker") is None:
            return False
        else:
            return True

    def clear(self):
        # 停止清理正常构建结束的容器
        self.run_command(f"sudo docker stop {self.name}", ignore_error=True)
        self.run_command(f"sudo docker rm {self.name}")

    def docker_start(self):
        if shutil.which("docker") is None:
            log.info("本地没有安装 docker, docker 启动失败")
            return False
        # 如果是服务器, 先创建网络, 由于外面已经编译好所有组件, server 里面不用再构建所有组件
        try:
            log.info(f"当前docker名字: {self.name}")
            self.run_command(f"sudo docker stop {self.name}", ignore_error=True)
            self.run_command(f"sudo docker rm {self.name}", ignore_error=True)
            # 创建 conan_server
            self.run_command(f'sudo docker run {self.env} {self.network} -id --privileged=true {self.volumns}\
                --name {self.name} {self.work_path} -p 0.0.0.0:{self.port}:{self.port} {self.container_tag} {self.cmd}')
            # conan_server 启动需要一定时间, 延迟 3 秒
            time.sleep(3)
            # 检查 conan_server 是否启动
            self.run_command(f"sudo docker exec -i {self.name} bash -c 'ps -e | grep conan_server'")

        except Exception as error:
            self.clear()
            raise error

        return True

    def exec(self, cmd):
        # 用于额外的在 docker 内部执行一些命令
        self.run_command(f"sudo docker exec {self.env} {self.work_path} -i {self.name} {cmd}")

    def export(self, export_path="."):
        tar_name = f"{self.container_tag.split(':')[1]}.tar"
        work_path = os.getcwd()
        os.chdir(export_path)
        self.run_command(f"sudo docker export -o {tar_name} {self.name}")
        self.run_command(f"sudo tar -cvzf {tar_name}.gz {tar_name}")
        os.chdir(work_path)

    def push(self, remote_url, imagepath, tag):
        self.run_command(f'sudo docker import v3_partner.tar {remote_url}/{imagepath}:{tag}')
        self.run_command(f'sudo docker push {remote_url}/{imagepath}:{tag}')