#!/usr/bin/python
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2023-2025. All rights reserved.

import os
import stat
import hashlib
import shutil
import xml.etree.ElementTree as ET
from xml.dom import minidom

from bmcgo_pro.utils.sign import Sign
from bmcgo_pro.logger import Logger

log = Logger("swbom_sign")


class Sha256sumCalc:
    """ sha256sum 计算

    Args:
        Process (_type_): 继承多进程
    """
    def __init__(self, file_name):
        self.name = file_name

    def get_sha256sum(self):
        """ 计算 sha256sum 值
        """
        with open(self.name, "rb") as fp:
            sha256sum = hashlib.sha256(fp.read()).hexdigest()
        return sha256sum


class SignFilelist:
    def __init__(self, board_name: str, work_path: str, sign_xml_file: str):
        """ 初始化签名类

        Args:
            board_name (str): 要签名的单板
            work_path (str): 签名目录
            sign_xml_file (str): 使用的签名文件
        """
        self.board_name = board_name
        self.work_path = work_path
        self.xml_name = f"{self.work_path}/../{self.board_name}_vercfg.xml"
        self.sign_xml_file = sign_xml_file

    @staticmethod
    def filelist_write(root: ET.Element, target_file: str):
        xml_str = minidom.parseString(ET.tostring(root)).toprettyxml(indent="    ")
        with os.fdopen(os.open(target_file, os.O_WRONLY | os.O_CREAT,
                               stat.S_IWUSR | stat.S_IRUSR), 'w') as fp:
            fp.write(xml_str)

    def create_filelist(self):
        """ 创建签名文件列表 xml 文件

        Raises:
            Exception: 如果计算错误，则抛出异常
        """
        os.chdir(self.work_path)
        if os.path.exists(self.xml_name):
            os.remove(self.xml_name)
        # 创建文件, 这里做权限配置, 防止规范误报
        with os.fdopen(os.open(self.xml_name, flags=os.O_RDWR | os.O_CREAT, \
            mode=stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH), "r+") as xml_fd:
            xml_fd.close()
        # 添加 Product 根节点
        root = ET.Element("Product")
        # 添加 Type 字段
        e_type = ET.Element("Type")
        e_type.text = "IVS"
        root.append(e_type)
        # 添加 Version 字段
        e_version = ET.Element("Version")
        e_version.text = "1.0"
        root.append(e_version)

        log.info("启动计算 sha256sum 值……")
        sha_dict = {}
        for root_path, _, files in os.walk("."):
            for file_name in files:
                file_path = os.path.join(root_path, file_name)
                log.info("正在计算 %s sha256sum", file_path)
                tmp_sha_cal = Sha256sumCalc(file_path)
                sha_dict.update({file_path: tmp_sha_cal.get_sha256sum()})
        log.info("所有 sha256sum 计算结束")

        # 由于多进程计算, 以及 os.walk 的差异, 做一次排序
        log.info("重新排序文件列表并写入 %s", self.xml_name)
        sorted_sha_list = sorted(list(sha_dict.items()), key=lambda x: x[0])
        for file_path, file_sha in sorted_sha_list:
            log.info("文件名: %s\tsha256sum值: %s", file_path.lstrip('./'), file_sha)
            # 添加 File 字段
            e_file = ET.Element("File")

            # 添加 FilePath 字段
            e_filepath = ET.Element("FilePath")
            e_filepath.text = file_path
            e_file.append(e_filepath)

            # 添加 SHAValue 字段
            e_shaval = ET.Element("SHAValue")
            e_shaval.text = file_sha
            e_file.append(e_shaval)

            root.append(e_file)
        self.filelist_write(root, self.xml_name)

    def sign(self):
        """ 签名

        Args:
            pss_crl_file (_type_, optional): 默认值为 None, 这个值分为两种情况, 如果会自动生成 crl 文件, 这个值无效, \
                如果不会生成 crl 文件, 则这个值配置的文件作为 crl 文件

        Raises:
            Exception: 如果没有签名成功, 抛出签名失败异常
        """
        os.chdir(self.work_path)
        os.rename(self.xml_name, os.path.basename(self.xml_name))
        sign_xml_name = os.path.basename(self.sign_xml_file)
        shutil.copy(self.sign_xml_file, sign_xml_name)
        # 会在当前目录下生成一个 .cms 文件, 和一个 .crl 文件
        xml_cml_file = f"{self.board_name}_vercfg.xml.crl"
        sign = Sign(sign_xml_name)
        cwd = os.getcwd()

        log.info("开始给xml文件签名")
        sign.modify_text("crlfile", xml_cml_file)
        sign.modify_attribute("fileset", "path", cwd)
        sign.sign()
        log.info("结束给xml文件签名")

        if not os.path.exists(xml_cml_file):
            raise Exception("单板 %s 目录 %s 生成签名失败", self.board_name, cwd)
        log.info("单板 %s 目录 %s 生成签名成功!", self.board_name, cwd)
