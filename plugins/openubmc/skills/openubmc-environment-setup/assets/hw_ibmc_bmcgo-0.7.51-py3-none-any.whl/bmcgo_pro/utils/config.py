#!/usr/bin/env python
# coding: utf-8
# Copyright © Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.

import json
import os
import stat
import shutil

from bmcgo import errors, misc
from bmcgo.logger import Logger
from bmcgo.bmcgo_config import BmcgoConfig
from bmcgo.utils.config import Config as BmcgoOriConfig
from bmcgo_pro.utils.tools import Tools

tools = Tools("config")
log = Logger("config")
VERSION = "Version"
BUILD_NUMBER = "BuildNum"
VERSION_LEN = 5


class Config(BmcgoOriConfig):
    def __init__(self, bconfig: BmcgoConfig, board_name=misc.boardname_default(), target="target_personal"):
        self.linx_build_dir = None
        self.cross_prefix = "aarch64-target-linux-gnu"
        self.cross_compile_install_path = "/opt/hcc_arm64le"
        # rtos裁剪目录
        self.oct_rtos = None
        self.pid_dir = None
        self.set_default_options()
        self.sdk_debug_dir = ""
        super().__init__(bconfig, board_name, target)


    @staticmethod
    def argparser(code_path, partner_mode=False):
        parser = BmcgoOriConfig.argparser(code_path, partner_mode)
        parser.add_argument("--signature_type",
                            help="固件签名类型", choices=["rsa4096", "sm2"])
        parser.add_argument("--encrypt_type",
                            help="固件加密类型", choices=["aes", "sm4"])

        parser.add_argument("--sdk_debug_dir", help="联调sdk目录", default="")
        parser.add_argument("--with_strip", help="是否strip", action=misc.STORE_TRUE)
        return parser

    # 设置默认值
    def set_default_options(self):
        # 存储0502编码
        self.manufacture_code = None
        # 存储tosupporte编码
        self.tosupporte_code = None
        self.build_type = "debug"
        self.stage = "dev"
        self.signature_type = None
        self.encrypt_type = None
        self.with_strip = False
        self.platform_package = ""

    # 模板化，manifest.yml替换时使用
    def get_template(self) -> dict:
        template = super().get_template()
        template["linx_build_dir"] = self.linx_build_dir
        return template

    def init_path(self):
        super().init_path()
        self.pid_dir = os.path.join(self.temp_path, "pids")
        if not os.path.isdir(self.pid_dir):
            os.makedirs(self.pid_dir)

    def update_path(self):
        super().update_path()
        self.linx_build_dir = f"{self.build_path}/linx_build_dir"
        os.makedirs(self.linx_build_dir, 0o755, exist_ok=True)
        manifest_xml = os.path.join(self.temp_path, "manifest_xml")
        if os.path.isdir(manifest_xml):
            shutil.rmtree(manifest_xml)
        os.makedirs(manifest_xml)

    def set_signature_type(self, signature_type):
        '''
        设置签名类型，默认rsa4096
        '''
        if signature_type:
            self.signature_type = signature_type
        elif self.manufacture_code:
            self.signature_type = self.get_manufacture_config(f"manufacture/{self.manufacture_code}/signature_type")
        else:
            self.signature_type = self.get_manufacture_config(f"tosupporte/{self.tosupporte_code}/signature_type")

        if not self.signature_type:
            self.signature_type = "rsa4096"

    def set_encrypt_type(self, encrypt_type):
        '''
        设置加密类型，默认不加密
        '''
        if encrypt_type:
            self.encrypt_type = encrypt_type
        elif self.manufacture_code:
            self.encrypt_type = self.get_manufacture_config(f"manufacture/{self.manufacture_code}/encrypt_type")
        else:
            self.encrypt_type = self.get_manufacture_config(f"tosupporte/{self.tosupporte_code}/encrypt_type")

    def print_config(self):
        header = 30
        super().print_config()
        log.info("signature type:".ljust(header) + str(self.signature_type))
        log.info("encrypt type:".ljust(header) + str(self.encrypt_type))

    def set_common_params(self):
        super().set_common_params()

    def update_chip_info(self, platform_package):
        rtos_version = platform_package.get("options", {}).get("rtos_version", "rtos_v2")
        if rtos_version == "rtos_v2_1712":
            self.chip = "1712"

    # 合并platform manifest.yml
    def merge_platform_manifest(self, mani):
        platform_package = self.get_manufacture_config("platform", {})
        if platform_package:
            self.update_chip_info(platform_package)
            platform_mani = self.load_platform_manifest(platform_package)
            tools.check_product_dependencies(mani, platform_mani)
            if self.manufacture_code:
                tools.check_product_dependencies(mani["manufacture"][self.manufacture_code], platform_mani)
            elif self.tosupporte_code:
                tools.check_product_dependencies(mani["tosupporte"][self.tosupporte_code], platform_mani)
            self.merge_manifest_yml(mani, platform_mani, "")
        else:
            shutil.rmtree(self.temp_platform_build_dir, ignore_errors=True)
        self.oct_rtos = os.path.join(self.temp_path, f'oct_rtos_{self.chip}')

    def parse_args(self, args=None):
        super().parse_args(args)

        is_rsa4096_sm4 = self.signature_type == "rsa4096" and self.encrypt_type == "sm4"
        is_sm2_aes = self.signature_type == "sm2" and self.encrypt_type == "aes"
        if is_rsa4096_sm4 or is_sm2_aes:
            raise errors.ConfigException(f"签名加密类型错误，{self.signature_type}签名类型不能使用{self.encrypt_type}加密")

        parser = self.argparser(self.code_path)
        args, _ = parser.parse_known_args(args)

        self.set_signature_type(args.signature_type)
        self.set_encrypt_type(args.encrypt_type)

        self.sdk_debug_dir = args.sdk_debug_dir
        self.with_strip = args.with_strip
