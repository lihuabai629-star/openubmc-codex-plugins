#!/usr/bin/env python
# coding: utf-8
# Copyright © Huawei Technologies Co., Ltd. 2023-2024. All rights reserved

import fcntl
import os
import stat
import yaml


class SWBom():
    def __init__(self, filename) -> None:
        self.filename = filename
        file_path = os.path.dirname(filename)
        if not os.path.exists(file_path):
            os.makedirs(file_path)

    def write(self, msg: dict):
        # 读写模式，不存在时自动创建
        with os.fdopen(os.open(self.filename, os.O_RDWR | os.O_CREAT | os.O_APPEND,
                               stat.S_IWUSR | stat.S_IRUSR), 'a+') as fp:
            # 加锁
            fcntl.flock(fp.fileno(), fcntl.LOCK_EX)
            # 由于打开模式的问题，将文件流定位到文件起始位置
            fp.seek(0)
            yaml_info = yaml.safe_load(fp)
            # 文件不存在时，yaml_info为空，直接设置为msg
            if yaml_info is not None:
                yaml_info.update(msg)
            else:
                yaml_info = msg
            self._dict_sort(yaml_info)
            # 文件需要重写，这之间不能释放文件描述符，清空内容
            fp.seek(0)
            fp.truncate()
            # 写入
            yaml.safe_dump(yaml_info, fp)
            fp.close()

    def _dict_sort(self, sort_dict: dict):
        for _, value in sort_dict.items():
            if isinstance(value, list):
                value.sort()
            elif isinstance(value, dict):
                self._dict_sort(value)


if __name__ == "__main__":
    swbom = SWBom()
    # 测试代码
    swbom.write("test.txt", {"ww": "test"})
    swbom.write("test.txt", {"nn": "test"})
    swbom.write("test.txt", {"bb": "test"})
