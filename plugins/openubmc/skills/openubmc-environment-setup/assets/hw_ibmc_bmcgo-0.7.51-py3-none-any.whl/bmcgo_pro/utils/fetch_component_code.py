#!/usr/bin/env python3
# encoding=utf-8
# 描述：根据conan包拉取组件代码
# Copyright (c) Huawei Technologies Co., Ltd. 2024. All rights reserved.
import os
import stat
import re
import shutil
import subprocess
from urllib.parse import urlparse
from typing import Dict
from multiprocessing import Pool

import patch_ng
import yaml
from git import Repo
from bmcgo import errors

from bmcgo import misc
from bmcgo_pro.utils.tools import Tools

tools = Tools("fetch_component_code")
log = tools.log


def process_err_cb(err):
    log.error("!!!!!!!!!!!!!!!!!!!!!!!!!!! 拉取代码失败, 错误: %s", err)


class XmlProject():
    def __init__(self, platform, remote_name, repo_name, branch, version, url):
        self.platform = platform
        self.remote_name = remote_name
        self.repo_name = repo_name
        self.branch = branch
        self.version = version
        self.url = url

    def gen(self):
        line = f'<project remote="{self.remote_name}" name="{self.repo_name}"'
        if re.search("^[0-9a-f]{40}$", self.branch) and re.search("^[0-9]+\\.[0-9]+\\.[0-9]+$", self.version):
            branch = self.version
        else:
            branch = self.branch
        line += f' path="{self.platform}/{self.repo_name}" revision="refs/tags/{branch}"'
        line += f' groups="{self.platform}"/>'
        return line


class XmlManifest():
    def __init__(self, target_dir, platform):
        self.platform = platform
        self.dir_path = os.path.join(target_dir, platform)
        if os.path.isdir(self.dir_path):
            shutil.rmtree(self.dir_path)
        self.xml_code_path = os.path.join(self.dir_path, "code.xml")
        self.xml_opensource_repos = os.path.join(self.dir_path, "opensource.xml")
        self.xml_vender_repos = os.path.join(self.dir_path, "vendor.xml")
        self.xml_dependency_repos = os.path.join(self.dir_path, "dependency.xml")
        self.projects: list[XmlProject] = []

    @staticmethod
    def __write_xml_manifest_data(filename, data):
        with os.fdopen(os.open(filename, os.O_WRONLY | os.O_CREAT | os.O_APPEND,
                               stat.S_IWUSR | stat.S_IRUSR), 'w') as file_handler:
            file_handler.write(data)

    def add_project(self, remote_name, repo_name, branch, version, url):
        project = XmlProject(self.platform, remote_name, repo_name, branch, version, url)
        self.projects.append(project)

    def prepare_manifest_xml(self):
        xml_header = '<?xml version="1.0" encoding="utf-8"?>\n<manifest>\n'
        self.__write_xml_manifest_data(self.xml_code_path, xml_header)
        self.__write_xml_manifest_data(self.xml_opensource_repos, xml_header)
        self.__write_xml_manifest_data(self.xml_vender_repos, xml_header)

    def close_manifest_xml(self):
        xml_footer = '</manifest>\n'
        self.__write_xml_manifest_data(self.xml_code_path, xml_footer)
        self.__write_xml_manifest_data(self.xml_opensource_repos, xml_footer)
        self.__write_xml_manifest_data(self.xml_vender_repos, xml_footer)

    def gen_depencency_xml(self, repos: Dict[str, str]):
        with os.fdopen(os.open(self.xml_dependency_repos, os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                               stat.S_IWUSR | stat.S_IRUSR), 'w') as file_handler:
            file_handler.write('<?xml version="1.0" encoding="utf-8"?>\n<manifest>\n')
            for fetch, name in repos.items():
                file_handler.write(f'    <remote name="{name}" fetch="{fetch}"/>\n')
            file_handler.write(f'    <include name="{self.platform}/code.xml"/>\n')
            file_handler.write(f'    <include name="{self.platform}/opensource.xml"/>\n')
            file_handler.write(f'    <include name="{self.platform}/vendor.xml"/>\n')
            file_handler.write('</manifest>\n')

    def gen(self, repos: Dict[str, str]):
        if not self.projects:
            return
        os.makedirs(self.dir_path, exist_ok=True)
        self.gen_depencency_xml(repos)
        self.prepare_manifest_xml()
        # 当前swbom的逻辑是如果conan只有一个源码，就能准确识别成份
        # 因此，当prj数量少于等于1时不生成manifest xml
        for proj in self.projects:
            line = proj.gen()
            if "OpenSourceCenter" in proj.url:
                xml_path = self.xml_opensource_repos
            elif "ChipSoftwareCenter" in proj.url:
                xml_path = self.xml_vender_repos
            else:
                xml_path = self.xml_code_path
            self.__write_xml_manifest_data(xml_path, f"    {line}\n")
        self.close_manifest_xml()


class FetchComponentCode:
    def __init__(self, packages, target_dir, conan_remote, include_open_source=True,
                 xml_manifest_gen=False, conflict_strategy="overwrite"):
        self.conan = shutil.which(misc.CONAN)
        if self.conan is None:
            raise RuntimeError("找不到 conan 工具")
        self.packages = packages
        self.target_dir = target_dir
        self.remote = conan_remote
        self.include_open_source = include_open_source
        self.xml_manifest_gen = xml_manifest_gen
        self.xml_manifest_repos = {}
        self.xml_manifest_platforms: Dict[str, XmlManifest] = {}
        self.conflict_strategy = conflict_strategy

    @staticmethod
    def patch(patch_file=None):
        patchset = patch_ng.fromfile(patch_file)
        if not patchset:
            raise errors.BmcGoException("Failed to parse patch: %s" % (patch_file))
        if not patchset.apply(strip=0, root="./", fuzz=False):
            raise errors.BmcGoException("Failed to apply patch: %s" % patch_file)

    @staticmethod
    def _get_patch_changed_files(patch_file):
        files = {}
        for line in open(patch_file):
            if not line.startswith("diff --git"):
                continue
            line = line.strip()
            chunk = line.split()
            a_file = chunk[-2][2:]
            b_file = chunk[-1][2:]
            files[a_file] = b_file
        return files

    @staticmethod
    def _apply_patches_direct(real_patch, patch_file, changed_files):
        FetchComponentCode.patch(patch_file=real_patch)
        for a_file, b_file in changed_files.items():
            if a_file != b_file:
                if a_file != "/dev/null" and b_file != "/dev/null":
                    os.rename(a_file, b_file)
                    cmd = f"git rm -f {a_file}"
                    tools.run_command(cmd)
                elif a_file != "/dev/null":
                    cmd = f"git rm -f {a_file}"
                    tools.run_command(cmd)
                    continue
            cmd = f"git add {b_file}"
            tools.run_command(cmd)
        cmd = f"git commit -m \"{patch_file}\""
        tools.run_command(cmd)

    @staticmethod
    def __apply_patches(conandata_file, patches, code_dir):
        if "CONAN_SHARE_PATH" in os.environ:
            return
        cwd = os.getcwd()
        if misc.conan_v1():
            recipe_folder = os.path.join(os.path.dirname(conandata_file), "..", "export_source")
        else:
            recipe_folder = os.path.join(os.path.dirname(conandata_file), "..", "es")
        recipe_folder = os.path.realpath(recipe_folder)
        os.chdir(os.path.join(cwd, code_dir))
        for patch in patches:
            patch_file = patch.get("patch_file")
            if not patch_file:
                log.warning(f"{code_dir} 组件的conandata.yml文件缺少patch_file，跳过git apply操作")
            real_patch = os.path.join(recipe_folder, patch_file)
            if not os.path.isfile(real_patch):
                log.error(f"{code_dir} 组件申明的补丁文件{real_patch}不存在，可能产生错误，请人工处理")
                continue
            changed_files = FetchComponentCode._get_patch_changed_files(real_patch)
            log.info(f"{code_dir} 开始应用源码补丁{patch_file}")
            try:
                FetchComponentCode._apply_patches_direct(real_patch, patch_file, changed_files)
            except errors.BmcGoException:
                # 尝试还原文件修改
                for a_file, b_file in changed_files.items():
                    cmd = f"git checkout -- {a_file}"
                    tools.run_command(cmd, ignore_error=True)
                    cmd = f"git checkout -- {b_file}"
                    tools.run_command(cmd, ignore_error=True)
                cmd = "git am " + real_patch
                tools.run_command(cmd)
            log.info(f"{code_dir} 应用源码补丁{patch_file}")
        os.chdir(cwd)

    @staticmethod
    def __update_share_cache(url):
        work_path = os.getcwd()
        # 删除url中的域名和末尾的.git作为放在共享内存中的路径
        code_path = urlparse(url).path.replace(".git", "")
        conan_share_path = os.environ['CONAN_SHARE_PATH']
        share_path = f"{conan_share_path}{code_path}"
        if not os.path.exists(share_path):
            cmd = f"git init --bare {share_path}"
            tools.run_command(cmd)
            os.chdir(share_path)
            cmd = f"git remote add origin {url}"
            tools.run_command(cmd)
            cmd = "git fetch origin --tags '+refs/heads/*:refs/heads/*' '+refs/tags/*:refs/tags/*' --prune"
            tools.run_command(cmd)
            os.chdir(work_path)
        else:
            os.chdir(share_path)
            cmd = "git fetch origin --tags '+refs/heads/*:refs/heads/*' '+refs/tags/*:refs/tags/*' --prune"
            tools.run_command(cmd)
            os.chdir(work_path)

    @staticmethod
    def __getinfo_from_conanfile(conanfile):
        with open(conanfile, "r") as file:
            lines = file.readlines()
            for idx, line in enumerate(lines):
                if line.find('scm = {"revision":') > 0:
                    revision = re.split(r'["]', line)[-2]
                    url = re.split(r'["]', lines[idx + 2])[-2]
                    break
            else:
                raise RuntimeError("无法找到版本(revision)和地址(url)字段")

            return revision, url

    def resolve_version_range(self, component_name, version_range):
        cmd = f"conan info '{version_range}' --package-filter={component_name}/* --only None"
        if misc.conan_v2():
            cmd = f"conan graph info --requires=\"{version_range}\" --filter {component_name}"
        if self.remote:
            cmd += f" -r {self.remote}"
        result = tools.run_command(cmd, capture_output=True, ignore_error=True)
        ret = result.returncode
        output = result.stdout.strip()
        if ret != 0 or not output:
            return None
        return output.split("\n")[-1]

    def update_component_code(self, component_name, conan_version):
        """
        update component code by conan version
        """
        try:
            os.chdir(self.target_dir)
            log.info("更新 %s 组件代码到 %s 开始", component_name, conan_version)
            if misc.conan_v1():
                version_split = re.split(r'[/, @]', conan_version)
                conan_dir = os.path.join(os.path.expanduser('~'), '.conan/data/', *version_split, 'export')
                conandata = os.path.join(conan_dir, 'conandata.yml')
                if not os.path.exists(conan_dir):
                    conan_remote_list = tools.get_conan_remote_list(self.remote)
                    tools.download_conan_recipes(conan_version, conan_remote_list)
                if os.path.exists(conandata):
                    self.__update_component_code_by_conandata(version_split[0], version_split[1], conandata)
                    return

                conanfile = os.path.join(conan_dir, 'conanfile.py')
                if os.path.exists(conanfile):
                    revision, url = FetchComponentCode.__getinfo_from_conanfile(conanfile)
                    self.__update_code_by_commit_id(version_split[0], version_split[1], component_name, url, revision)
                    return
            else:
                conan_remote_list = tools.get_conan_remote_list(self.remote)
                tools.download_conan_recipes(conan_version, conan_remote_list)
                path_cmd = f"conan cache path {conan_version}"
                path_cmd_info = Tools().run_command(path_cmd, capture_output=True)

                version_split = re.split(r'[/, @]', conan_version)
                conan_dir = path_cmd_info.stdout.strip()
                conandata = os.path.join(conan_dir, 'conandata.yml')
                if os.path.exists(conandata):
                    self.__update_component_code_by_conandata(version_split[0], version_split[1], conandata)
                    return

                log.error("conandata(%s) 没有找到", conandata)
            log.info("更新组件 %s 代码到 %s 失败, 无法获取到 conan 信息", component_name,
                     conan_version)
        except Exception as exp:
            log.error("工作状态错误: %s", exp)
            log.error("更新组件代码到 %s 失败", conan_version)

    def run(self):
        cwd = os.getcwd()
        packages_to_fetch = dict()
        for component_name, package in self.packages.items():
            version_str = re.split("/|@", package)[1]
            if "[" not in version_str:
                if self.include_open_source or re.fullmatch("\d+\.\d+\.\d+", version_str) is not None:
                    packages_to_fetch[component_name] = package
                continue
            resolved_package = self.resolve_version_range(component_name, package)
            if resolved_package is None:
                log.warning("查找不到与 %s 范围匹配的版本", package)
            else:
                packages_to_fetch[component_name] = resolved_package
                log.info("查找到与 %s 范围匹配的版本 %s", package, resolved_package)

        if self.xml_manifest_gen:
            for component_name, conan_version in packages_to_fetch.items():
                self.update_component_code(component_name, conan_version)
        else:
            process_count = min(len(packages_to_fetch), os.cpu_count())
            log.info("创建 %u 个进程拉取代码", process_count)
            pool = Pool(processes=process_count)
            for component_name, conan_version in packages_to_fetch.items():
                pool.apply_async(func=self.update_component_code, args=(component_name, conan_version),
                                error_callback=process_err_cb)
            pool.close()
            pool.join()
        for _, manifest in self.xml_manifest_platforms.items():
            manifest.gen(self.xml_manifest_repos)
        os.chdir(cwd)

    def __write_xml_manifest(self, platform, version, url, branch):
        matches = re.search("^https://[a-z0-9A-Z-.]+/", url)
        if not matches:
            raise errors.BmcGoException(f"Can't get remote https url, origin ori is: {url}")
        if "/iBMC_V3/" in url:
            return
        remote = matches.group(0)[:-1]
        remote_name = remote[len("https://"):].replace(".", "-")
        if not self.xml_manifest_repos.get(remote):
            self.xml_manifest_repos[remote] = remote_name
        xml_manifest = self.xml_manifest_platforms.get(platform)
        if not xml_manifest:
            xml_manifest = XmlManifest(self.target_dir, platform)
            self.xml_manifest_platforms[platform] = xml_manifest

        repo_name = url[len(remote) + 1:]
        xml_manifest.add_project(remote_name, repo_name, branch, version, url)

    def __update_code_by_commit_id(self, name, version, code_dir, url, commit_id):
        if "CONAN_SHARE_PATH" in os.environ:
            self.__update_share_cache(url)
            log.info(f"更新共享缓存{code_dir}")
            return
        if self.xml_manifest_gen:
            self.__write_xml_manifest(name, version, url, commit_id)
            return
        if os.path.exists(code_dir):
            repo = Repo(code_dir)
            repo.git.fetch('origin')
        else:
            Repo.clone_from(url, to_path=code_dir)
            repo = Repo(code_dir)
        if self.conflict_strategy == "abort":
            try:
                repo.git.merge(commit_id)
            except Exception as e:
                log.error("%s", e)
                try:
                    repo.git.merge("--abort")
                    log.error("存在冲突，更新代码失败！(组件: %s, 地址: %s, 提交节点: %s)", code_dir, url, commit_id)
                except Exception as ex:
                    log.error("%s", ex)
                    log.error("存在冲突，更新代码失败！(组件: %s, 地址: %s, 提交节点: %s)", code_dir, url, commit_id)
            else:
                repo.git.reset('--mixed', commit_id)
                log.info("更新代码(组件: %s, 地址: %s, 提交节点: %s)", code_dir, url, commit_id)
        else:
            repo.index.reset(commit=commit_id, head=True, working_tree=True)
            repo.git.clean('-dfx')
            log.info("更新代码(组件: %s, 地址: %s, 提交节点: %s)", code_dir, url, commit_id)

    def __update_code_by_branch(self, name, version, code_dir, deps):
        url = deps['url']
        branch = deps.get('branch', "").split('/')[-1] or deps.get("commit", "")

        if "CONAN_SHARE_PATH" in os.environ:
            self.__update_share_cache(url)
            log.info(f"更新共享缓存{code_dir}")
            return

        if self.xml_manifest_gen:
            self.__write_xml_manifest(name, version, url, branch)
            return
        if os.path.exists(code_dir):
            repo = Repo(code_dir)
            repo.git.fetch('origin', branch)
        else:
            Repo.clone_from(url, to_path=code_dir)
            repo = Repo(code_dir)
        if re.match(r"^[0-9a-f]{40}$", branch):
            repo.head.reset(branch, working_tree=True)
        elif branch.startswith("refs/tags/"):
            repo.head.reset(branch[len("refs/tags/"):], working_tree=True)
        else:
            repo.git.checkout(branch)
        log.info("更新代码(组件: %s, 地址: %s, 节点: %s)", code_dir, url, branch)

    def __update_component_code_by_conandata(self, name, version, conandata_file):
        with open(conandata_file, 'r') as f_:
            conandata = yaml.safe_load(f_)
            deps = conandata.get("sources", {}).get(version, {})
            if 'url' in deps:
                self.__update_code_by_branch(name, version, name, deps)
            else:
                cwd = os.getcwd()
                os.makedirs(name, exist_ok=True)
                os.chdir(name)
                for comp, deps in deps.items():
                    self.__update_code_by_branch(name, version, comp, deps)
                os.chdir(cwd)
            if not self.xml_manifest_gen:
                patches = conandata.get("patches", {}).get(version)
                if patches:
                    self.__apply_patches(conandata_file, patches, name)
