#!/usr/bin/env python
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.

"""
文件名：work_build_conan.py
功能：编译产品依赖包
版权信息：华为技术有限公司，版本所有(C) 2023-2025
"""

import os
import re

import yaml

from bmcgo_pro.tasks.task import Task
from bmcgo_pro.utils.config import Config
from bmcgo_pro.logger import Logger

log = Logger("codebase_check")
CONAN_PACKAGE_SEPARATOR = "/|@"


class CodebaseComponentVersionCheck(Task):
    def __init__(self, config: Config, work_name=""):
        super(CodebaseComponentVersionCheck, self).__init__(config, work_name)
        self.info_file = ""

    def component_check(self):
        # 如果本地有文件，优先使用本地文件来分析
        if os.path.exists(self.config.component_list_file):
            self.info_file = self.config.component_list_file
            with open(self.info_file, "r") as fp:
                component_info_codebase = [x.strip('\n') for x in fp.readlines()]
        else:
            self.info_file = f"{self.config.board_path}/hpm_info_{self.config.board_name}.yml"
            # 如果默认的文件不存在，那么就从manifest.yml中获取codebase字段并拼接版本
            codebase = self.get_manufacture_config("base/codebase")

            # 如果获取到的为空值，也就是None，那么打印告警日志，且作为非基线版本直接返回，不做分析
            if codebase is None:
                log.warning(
                    "基线提示(非基线忽略此提示)：在 manifest.yml 中没有基线版本号的配置，请阅读build/product/README.md"
                )
                return
            else:
                # 不为空则执行以下命令，默认成功，因为失败时会导致进程直接退出
                log.info(
                    f"从cmc {codebase} 下载 inner配置/{self.config.board_name}/hpm_info_{self.config.board_name}.yml"
                )
                codebase_version = f"{self.config.board_name.replace('_', '.')} {codebase}"
                self.run_command(
                    f"artget pull -o iBMC300 '{codebase_version}' -ap {self.config.board_path} -ru inner " +
                    f"-rp /{self.config.build_type}/hpm_info_{self.config.board_name}.yml")

                # 加载yaml文件，字段分析，确定是否有大版本号修改，只允许小版本号修改
                with open(self.info_file, "r") as fp:
                    component_info_codebase = yaml.safe_load(fp).get("package_info")
                if component_info_codebase is None or len(component_info_codebase) == 0:
                    log.error("组件没有配置，请检查基线版本号是否正确")
                    raise AttributeError

        # 生成 组件名:版本号 字典
        codebase_info_dict = {
            re.split(CONAN_PACKAGE_SEPARATOR, x)[0]: re.split(CONAN_PACKAGE_SEPARATOR, x)[1]
            for x in component_info_codebase
        }

        # 获取当前的构建的package_info配置，然后与上面读取的yaml做对比
        with open(f"{self.config.rootfs_path}/etc/package_info", "r") as fp:
            component_info_build = [x.strip('\n') for x in fp]
            if len(component_info_build) == 0:
                log.error("当前构建中package_info中没有组件，请检查manifest.yml是否为hpm包添加过需要的组件")
        # 生成 组件名:版本号 字典
        build_info_dict = {
            re.split(CONAN_PACKAGE_SEPARATOR, x)[0]: re.split(CONAN_PACKAGE_SEPARATOR, x)[1]
            for x in component_info_build
        }

        self._component_info_check(build_info_dict, codebase_info_dict)
        log.info("基线版本检查通过!!!")
        os.remove(self.info_file)

    def run(self):
        # 伙伴模式跳过检测
        if self.config.partner_mode:
            return
        self.component_check()

    def _component_info_check(self, build_info_dict, codebase_info_dict):
        for key, version in build_info_dict.items():
            # 如果名字在build_info当中，则对比，不在，则跳过
            if key in codebase_info_dict.keys():
                # 如果version以'.'拆开为三段，则进行下一对比
                if len(version.split('.')) != 3:
                    log.info(f"组件{key}不符合检查规则，跳过检查")
                    continue
                build_version_list = version.split('.')
                codebase = codebase_info_dict.get(key).split('.')
                # 如果前两段相同，则跳过，如果前两段出现差异，则报错
                if codebase[0] == build_version_list[0] and codebase[1] == build_version_list[1]:
                    continue
                else:
                    log.error(
                        f"当前{key}:{version}版本与基线版本{key}:{codebase_info_dict.get(key)}" +
                        "主版本号出现差异，请阅读build/product/README.md")
                    os.remove(self.info_file)
                    raise AttributeError
            else:
                log.warning(f"{key}属于新增组件，跳过检查")
