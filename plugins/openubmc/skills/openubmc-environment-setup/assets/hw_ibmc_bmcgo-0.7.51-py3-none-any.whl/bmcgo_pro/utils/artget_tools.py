#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2024. All rights reserved.
import os
import sys
import argparse
import xml.etree.ElementTree as ET

from bmcgo import errors

from bmcgo_pro.utils.tools import Tools

tools = Tools()


class ArtgetToolUtil:
    VERIFY_FILES_TAG = "verifyFiles"

    @staticmethod
    def remove_file_verify_element(dependency_xml: str):
        verify_tag = ArtgetToolUtil.VERIFY_FILES_TAG
        tools.log.info(f"移除{dependency_xml}中自定义的额外的{verify_tag}标签")
        tools.run_command(f'sed -i "/<{verify_tag}>/, /<\/{verify_tag}>/d" {dependency_xml}')

    @staticmethod
    def get_file_hash(file_path: str) -> str:
        if not os.path.isfile(file_path):
            raise errors.NotFoundException(f"文件{file_path}不存在。")
        file_hash = Tools.sha256sum(file_path)
        return file_hash


class ArtgetDownloadTool:
    def __init__(self, dependency_xml: str, agent_path: str, update_hashes=False):
        self.dependency_xml = dependency_xml
        self.agent_path = agent_path
        self.is_modify_hashes = update_hashes
    
    def get_file_hashes_from_xml(self) -> dict:
        file_hashes = {}
        tree = ET.parse(self.dependency_xml)
        for copy_element in tree.iter(tag="copy"):
            dest_element = copy_element.find("dest")
            if dest_element is None or not dest_element.text:
                continue
            dest_value = dest_element.text.strip()
            for verify_element in copy_element.iter(tag=ArtgetToolUtil.VERIFY_FILES_TAG):
                for file_element in verify_element.findall("file"):
                    name = file_element.find("name").text.strip()
                    file_path = os.path.join(dest_value, name)
                    hash_value = file_element.find("hash").text.strip()
                    file_hashes[file_path] = hash_value
        return file_hashes
    
    def update_file_hashes_from_xml(self, path_to_hashes: dict):
        if not path_to_hashes:
            tools.log.info(f"文件{self.dependency_xml}中不存在需更新的hash字段")
            return
        for file_path, (old_hash, new_hash) in path_to_hashes.items():
            cmd = f"sed -i s/{old_hash}/{new_hash}/g {self.dependency_xml}"
            tools.run_command(cmd)
            tools.log.info(f"文件{self.dependency_xml}中下载的文件{file_path}hash字段已更新")
        tools.log.info(f"文件{self.dependency_xml}中hash字段已全部更新为最新数据")

    def download(self):
        if not os.path.isfile(self.dependency_xml):
            raise errors.NotFoundException(f"文件{self.dependency_xml}不存在。")

        tools.log.info(f">>>>>{self.dependency_xml}依赖组件下载开始....")
        cmd = f"artget pull -d {self.dependency_xml} -ap {self.agent_path} -ds N"
        tools.run_command(cmd)
        tools.log.info(f">>>>>{self.dependency_xml}依赖组件下载完成")

        self.verify_files_hash()

    def verify_files_hash(self):
        base_xml = self.dependency_xml
        tools.log.info(f"开始{base_xml}依赖组件文件的hash校验....")
        base_file_hashes = self.get_file_hashes_from_xml()
        check_result_path_to_hashes = {}
        if not base_file_hashes:
            tools.log.warning(
                f"文件{base_xml}无下载文件的hash值定义, 请在<copy>标签下添加<{ArtgetToolUtil.VERIFY_FILES_TAG}>标签"
            )
            return
        
        for file_path, base_hash in base_file_hashes.items():
            abs_file_path = os.path.abspath(os.path.join(self.agent_path, file_path))
            real_hash = ArtgetToolUtil.get_file_hash(abs_file_path)
            check_result = self.check_file_hash(abs_file_path, base_hash, real_hash)
            if not check_result:
                check_result_path_to_hashes[abs_file_path] = [base_hash, real_hash]
                
        if check_result_path_to_hashes and not self.is_modify_hashes:
            raise errors.ConfigException(f"{base_xml}下载文件校验hash失败。")
        
        tools.log.info(f"{base_xml}下载的文件hash校验完成。")

        if self.is_modify_hashes:
            self.update_file_hashes_from_xml(check_result_path_to_hashes)

    def check_file_hash(self, file_path: str, base_hash: str, real_hash: str) -> bool:
        if real_hash != base_hash:
            diff_error_msg = (
                f"文件{self.dependency_xml}中下载的文件{file_path}的实际hash值{real_hash}与基准值{base_hash}不一致, "
                f"文件内容已变更, 请修改下载软件版本或{self.dependency_xml}中hash值。"
            )
            tools.log.error(diff_error_msg)
            return False
        return True


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Download dependencies", 
        formatter_class=argparse.RawTextHelpFormatter
    )
    parser.add_argument("--xml_path", help="xml路径", required=True)
    parser.add_argument("--download_dir", help="依赖组件下载路径", default=".")
    parser.add_argument("--update_hashes", help="是否自动修改下载文件的hash值", action="store_true")
    parsed_args, _ = parser.parse_known_args(sys.argv)
    artget_download = ArtgetDownloadTool(parsed_args.xml_path, parsed_args.download_dir, parsed_args.update_hashes)
    artget_download.download()
