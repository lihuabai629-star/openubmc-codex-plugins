#!/usr/bin/env python3
# encoding=utf-8
# 描述：BMCGO配置管理
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2025. All rights reserved.
import os
import configparser
import functools
from configparser import NoSectionError, NoOptionError

from semver import valid_range, satisfies
from bmcgo import errors
from bmcgo import misc
from bmcgo.bmcgo_config import BmcgoConfig as BmcgoOriConfig
from bmcgo.bmcgo_config import BmcgoManifest as BmcgoOriManifest
from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.utils.install_package import InstallBmcgo
from bmcgo_pro.utils.install_package import InstallStudio
from bmcgo_pro import __version__

tools = Tools("bingo_config")
log = tools.log

HPM_SIGN_ALGORITHM_KEY = "hpm_sign_algorithm"
HPM_SIGN_XML_PATH = "hpm_sign_xml_path"

# 配置文件分为以下3种，优先级递减：
# 1. 局部配置：指在任意路径下的.bmcgo文件夹中的config文件，越靠近目标文件优先级最高
# 2. 全局配置：指HOME目录下的 .bmcgo/config文件
# 3. 系统配置：指/etc/bmcgo.conf文件


class BmcgoHpmSignAlgorithm:
    def __init__(self, config: configparser.ConfigParser):
        self.config_path = config.get(HPM_SIGN_ALGORITHM_KEY, HPM_SIGN_XML_PATH)


class BmcgoConfig(BmcgoOriConfig):
    def __init__(self):
        """初始化"""
        self.hpm_sign_algorithm = None
        super().__init__()

    @functools.cached_property
    def partner_mode(self):
        """是否是伙伴模式"""
        return True
        if not os.path.isfile(misc.GLOBAL_CFG_FILE):
            return False
        conf = configparser.ConfigParser()
        conf.read(misc.GLOBAL_CFG_FILE)
        try:
            return conf.getboolean("partner", "enable")
        except (NoSectionError, NoOptionError):
            return False

    def set_installer(self, app_name, conf: configparser.ConfigParser):
        if app_name == "bmc-studio":
            installer = InstallStudio()
        else:
            installer = InstallBmcgo()
        try:
            version = conf.get(app_name, "version")
        except (NoSectionError, NoOptionError):
            log.debug(f"未在.bmcgo/config中找到bmcgo/version配置项，使用当前bmcgo({__version__})构建")
            return
        range_str = version.strip("[").rstrip("]")
        range_version = valid_range(range_str, loose=False)
        if range_version is None:
            raise errors.ConfigException(f"版本范围 {version} 在文件 .bmcgo/config 中格式配置错误")
        if satisfies(installer.current_version, range_version):
            return

        log.warning(
            f'申明的{app_name}版本号"{range_version}"与{app_name}当前版本号"{installer.current_version}"不匹配'
        )
        installer.version = range_version
        installer.install()
        raise errors.ExitOk("升级已完成，请在bmcgo退出后重新执行")

    def _version_check(self, conf: configparser.ConfigParser):
        # DT模式不检查bmcgo版本号
        if os.environ.get("BMCGO_DT_RUN"):
            return
        self.set_installer("bmcgo", conf)
        self.set_installer("bmc-studio", conf)

    def _bmcgo_config_init(self):
        super()._bmcgo_config_init()
        """配置初始化"""
        cwd = self.cwd
        if os.path.isfile("frame.py"):
            self.manifest = BmcgoOriManifest(os.path.realpath(os.path.join(cwd, "..")), None)
            return
        if os.path.isfile("build/frame.py"):
            self.manifest = BmcgoOriManifest(cwd, None)
            return
        while cwd != "/":
            config_file = os.path.join(cwd, ".bingo", "config")
            if not os.path.isfile(config_file):
                config_file = os.path.join(cwd, ".bmcgo", "config")

            if os.path.isfile(config_file):
                conf = configparser.ConfigParser()
                conf.read(config_file)
                try:
                    self.conan_blacklist = conf.get("bingo", "conan-blacklist", raw=True).splitlines()
                except (NoSectionError, NoOptionError):
                    log.debug(f"未在{config_file}中找到conan-blacklist配置项，拉取全部connan")

                # 检查是否需要升级
                self._version_check(conf)

            cwd = os.path.dirname(cwd)

    def _bmcgo_signature_config_load(self, conf: configparser.ConfigParser):
        """
        解析hpm与eeprom签名加密配置，优先级如下: \n
        local config > global config > system config
        """
        super()._bmcgo_signature_config_load(conf)
        # 新增签名算法配置
        try:
            if self.hpm_sign_algorithm is None:
                self.hpm_sign_algorithm = BmcgoHpmSignAlgorithm(conf)
        except (NoSectionError, NoOptionError):
            log.debug("未找到hpm签名算法配置")