#!/usr/bin/env python3
# coding: utf-8
# 版权所有 (c) 华为技术有限公司 2025
import os

from bmcgo.component.analysis.sr_validation import SrValidate as SrValidateBase

script_dir = os.path.split(os.path.realpath(__file__))[0]


class SrValidate(SrValidateBase):
    def __init__(self, sr_dir: str):
        super().__init__(sr_dir)
        self.whitelist_file = os.path.join(script_dir, "smc_dfx_whitelist.json")
