#!/usr/bin/python3
# coding: utf-8
# 版权所有 (c) 华为技术有限公司 2023-2023
import os
from bmcgo.functional.schema_valid import BmcgoCommand as SchemaValid
from bmcgo.bmcgo_config import BmcgoConfig
from bmcgo_pro.logger import Logger
from bmcgo_pro.utils.tools import Tools


log = Logger()
tool = Tools()

cwd_script = os.path.split(os.path.realpath(__file__))[0]


class BuildComp():
    def __init__(self, bconfig: BmcgoConfig):
        self.bconfig = bconfig

    def run(self):
        self.check_mds_validation()
        self.check_mdb_intf_validation()
        self.check_mdb_path_validation()
        self.check_csr_validation()

    def check_mds_validation(self):
        mds_path = os.path.join(os.getcwd(), "mds")
        if not os.path.exists(mds_path):
            return
        log.info("============== 组件 mds schema 校验开始 ==============")
        args = ["-t", mds_path]
        cmd = SchemaValid(self.bconfig, args)
        try:
            cmd.run()
        except Exception as e:
            log.info(f"mds schema 校验结果不通过")
            log.info(f"错误信息：{e}")
            return
        log.success("============== 组件 mds schema 校验成功 ==============")

    def check_mdb_intf_validation(self):
        mdb_path = os.path.join(os.getcwd(), "json/intf/mdb")
        if not os.path.exists(mdb_path):
            return
        log.info("============== mdb interface schema 校验开始 ==============")
        args = ["-t", mdb_path]
        cmd = SchemaValid(self.bconfig, args)
        try:
            cmd.run()
        except Exception as e:
            log.info(f"mdb interface schema 校验结果不通过")
            log.info(f"错误信息：{e}")
            return
        log.success("============== mdb interface schema 校验成功 ==============")

    def check_mdb_path_validation(self):
        mdb_path = os.path.join(os.getcwd(), "json/path/mdb")
        if not os.path.exists(mdb_path):
            return
        log.info("============== mdb path schema 校验开始 ==============")
        args = ["-t", mdb_path]
        cmd = SchemaValid(self.bconfig, args)
        try:
            cmd.run()
        except Exception as e:
            log.info(f"mdb path schema 校验结果不通过")
            log.info(f"错误信息：{e}")
            return
        log.success("============== mdb path schema 校验成功 ==============")

    def check_csr_validation(self):
        log.info("============== csr schema 校验开始 =============")
        args = ["-t", os.getcwd(), "-csr"]
        cmd = SchemaValid(self.bconfig, args)
        try:
            cmd.run()
        except Exception as e:
            log.info(f"csr schema 校验结果不通过")
            log.info(f"错误信息：{e}")
            return
        log.success("============== csr schema 校验成功 ==============")
