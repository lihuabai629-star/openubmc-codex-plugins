#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2023. All rights reserved.
import os


from bmcgo.component.analysis.intf_validation import InterfaceValidation as InterfaceValidationBase
from bmcgo.functional.schema_valid import BmcgoCommand as SchemaValid

from bmcgo_pro.logger import Logger

log = Logger()


class InterfaceValidation(InterfaceValidationBase):
    def __init__(self, remote):
        super().__init__(remote)
        self.mdb_interface_repo_url = "https://codehub-dg-y.huawei.com/iBMC_V3/bmc_core/mdb_interface.git"

    @staticmethod
    def _check_mds_schema_valid():
        validation_files = ("mds/service.json", "mds/types.json", "mds/ipmi.json",
                            "mds/model.json", "mds/debug/service.json", "mds/debug/model.json")
        for file in validation_files:
            file_path = os.path.join(os.getcwd(), file)
            if os.path.exists(file_path):
                if not SchemaValid.schema_valid(file_path, "json"):
                    log.warning(f"schema校验文件{file}失败")

    def run(self):
        self._check_mds_schema_valid()
        self._parse_mds_interfaces()
        self._parse_hardcoded_interfaces()
        self._pull_all_interfaces()
        intf_validation_passed = self._validate_mds_intf() and self._validate_hardcoded_intf() and \
                self._check_dbus_call()
        if intf_validation_passed:
            log.info("接口检验通过")
        else:
            log.error("接口校验未通过")
        return intf_validation_passed
