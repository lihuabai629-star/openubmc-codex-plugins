#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
import os

from bmcgo.component.analysis.analysis import AnalysisComp as Analysis

script_dir = os.path.split(os.path.realpath(__file__))[0]
RULE_FILE = os.path.join(os.path.split(os.path.realpath(__file__))[0], "dep-rules.json")


class AnalysisComp(Analysis):
    def __init__(self, board_name, artifact_dir, lock_file, custom_sr_dir, rule_file):
        super().__init__(board_name, artifact_dir, lock_file, custom_sr_dir, rule_file)
        self.rule_file = rule_file or RULE_FILE
