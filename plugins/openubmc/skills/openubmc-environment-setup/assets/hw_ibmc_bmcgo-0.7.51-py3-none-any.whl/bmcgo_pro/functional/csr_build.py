#!/usr/bin/env python3
# encoding=utf-8
# 描述：CSR构建出包
# Copyright © Huawei Technologies Co., Ltd. 2025. All rights reserved.

import os
import json
import re
import argparse
import shutil
import gzip
import io
import stat
import binascii
import hashlib
import tempfile
import subprocess
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone, timedelta
import configparser
from configparser import NoSectionError, NoOptionError

import json5
import ecdsa
import requests
from bmcgo import errors

from bmcgo import misc
from bmcgo.misc import CommandInfo
from bmcgo.functional.csr_build import HpmBuild as OriHpmBuild
from bmcgo.functional.csr_build import SignInfo, CsrHeader, SrMakeOptions, SignatureTypeEnum, \
                                        EepromHeader, get_timestamp, round_up_data_size
from bmcgo.functional.csr_build import BmcgoCommand as OriCsrBuildCommand
from bmcgo.functional.csr_build import EepromBuild as OriEepromBuild
from bmcgo.functional.csr_build import SignGenerator as OriHpmSignGenerator
from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.utils.merge import Merger
from bmcgo_pro.utils.buffer import Buffer
from bmcgo_pro.bmcgo_config import BmcgoConfig, BmcgoHpmSignAlgorithm

tool = Tools("csr_build")
log = tool.log
cwd = os.getcwd()

TIANCHI = "bmc.dev.Board.TianChi"
HPM_PACK_PATH = "/usr/share/bmcgo/csr_packet"
SIGNATURE_TOOL = "/usr/local/signature-jenkins-slave/signature.jar"
EEPROM_SIGN_PATH = "/usr/share/bmcgo/eeprom_sign"
SIGNATURE_VERIFY_SCRIPT = "/usr/share/bmcgo/eeprom_sign/signature_verify.py"
EEPROM_SIZE_LIMIT_CONFIG = "/usr/share/bmcgo/schema/eepromSizeLimit.json"
HPM_SIGN_CONFIG_DEFAULT = "/usr/share/bmcgo/signature/sign_lang.xml"
HPM_SIGN_FILENAME = "sign_hpm.xml"


def if_available(bconfig: BmcgoConfig):
    return (
        bconfig.ibmc_sdk is None and bconfig.component is None
        and bconfig.conan_index is None and bconfig.manifest is None
    )

command_info: CommandInfo = CommandInfo(
    group=misc.GRP_MISC,
    name="build",
    description=["CSR构建出包"],
    hidden=False
)


class BmcgoCommand(OriCsrBuildCommand):
    def __init__(self, bconfig: BmcgoConfig, *args):
        super().__init__(bconfig, *args)
        self.hpm_sign_algorithm = self.parsed_args.sign_alg_config

    @staticmethod
    def get_arg_parser():
        parser = OriCsrBuildCommand.get_arg_parser()
        parser.add_argument(
            "--sign_alg_config",
            help="参数配置文件",
            default=None
        )
        return parser

    def get_hpm_sign_strategy(self):
        if self.bconfig.hpm_server_sign:
            self.hpm_sign_strategy = SignatureTypeEnum.SERVER_SIGN
        elif self.bconfig.hpm_self_sign:
            self.hpm_sign_strategy = SignatureTypeEnum.SELF_SIGN
        else:
            self.hpm_sign_args = self.hpm_sign_algorithm
            self.hpm_sign_strategy = SignatureTypeEnum.DEFAULT
        log.info(f"hpm签名使用 {self.hpm_sign_strategy.value} 方法")

    def check_args(self):
        super().check_args()
        if self.hpm_sign_algorithm is None and self.bconfig.hpm_sign_algorithm:
            self.hpm_sign_algorithm = self.bconfig.hpm_sign_algorithm.config_path
        # 检查签名配置文件是否存在
        if self.hpm_sign_algorithm is not None:
            if not os.path.exists(self.hpm_sign_algorithm):
                raise FileNotFoundError(\
                    f"HPM签名配置文件不存在: '{self.hpm_sign_algorithm}'，请检查sign_alg_config参数或配置项hpm_sign_xml_path")
            # 检查签名配置文件是否为XML文件（简单检查扩展名）
            if not self.hpm_sign_algorithm.lower().endswith('.xml'):
                raise Exception(f"警告: 文件 '{self.hpm_sign_algorithm}' 可能不是XML文件")
            with open(self.hpm_sign_algorithm, 'r', encoding='utf-8') as file:
                content = file.read()
                required = "<include>*.filelist</include>"
                if required not in content:
                    raise Exception(f"文件'{self.hpm_sign_algorithm}'中缺少必要内容{required}")

    def _get_eeprom_builder(self, options: SrMakeOptions):
        return EepromBuild(self.bconfig, options, self.work_dir, self.eeprom_sign_strategy)

    def _get_hpm_builder(self, hpm_file: str):
        params = (self.bconfig, hpm_file, self.work_dir, self.hpm_sign_strategy, self.hpm_sign_algorithm)
        return HpmBuild(*params)


class EepromBuild(OriEepromBuild):
    def __init__(self, bconfig, options, work_dir, strategy):
        super().__init__(bconfig, options, work_dir, strategy)

    def _get_eeprom_default_sign(self, un_sign_data):
        sign_data = self._get_huawei_sign(un_sign_data)
        return self.build_sign(sign_data)

    def _get_huawei_sign(self, un_sign_data: bytearray):
        sign_process = SignGenerate(un_sign_data, self.work_dir)
        sign_data = sign_process.execute()
        return sign_data


class HpmBuild(OriHpmBuild):
    # Description: hpm打包初始化函数
    def __init__(self, bconfig, dest_file, work_dir, strategy, sign_alg):
        self.bconfig = bconfig
        self.strategy = strategy
        # hpm包文件名
        self.hpm_name = "devkit.hpm"
        # 打包后结果文件存放路径
        self.dest_path = dest_file
        # 打包目录
        self.hpm_temp_dir = os.path.join(work_dir, "hpm_temp")
        # 打包路径下配置文件，存放在目录csr_packet下
        self.package_list = [
            "afteraction.sh", "beforeaction.sh", "CfgFileList.conf",
            "hpm_devkit.config", "image.filelist", "packet.sh",
            "update.cfg"
        ]
        # 签名算法配置文件路径
        self.sign_alg = sign_alg
        if os.path.exists(HPM_PACK_PATH):
            shutil.copytree(HPM_PACK_PATH, self.hpm_temp_dir, dirs_exist_ok=True)
        # 打包后得到的hpm包
        self.hpm_file = os.path.join(self.hpm_temp_dir, self.hpm_name)

    # hpm包制作工具检查
    def check_hpm_tools(self):
        log.info("开始hpm包制作工具检查...")
        ret = tool.run_command("which hpmimage crypto_tool filesizecheck")
        if ret is None or ret.returncode != 0:
            raise errors.BmcGoException("hpm包制作工具缺失，请检查bmcgo是否正确安装")

    # 默认签名策略，覆写bingo逻辑
    def sign_hpm_default(self):
        log.info("开始对hpm包进行华为签名...")
        # 更新华为签名配置
        log.debug(f"使用的签名配置文件为：{self._get_sign_config()}")
        self.update_sign_algorithm_config(self._get_sign_config())
        sign_xml = os.path.join(self.hpm_temp_dir, "sign_hpm.xml")
        ret = tool.run_command(f"java -jar {SIGNATURE_TOOL} {sign_xml}", command_echo=False)
        if ret.returncode != 0:
            raise errors.BmcGoException(f"Failed to generate signature for hpm package: {ret.stderr}.")

    # 执行脚本构建hpm
    def packet_hpm(self):
        log.info("开始执行构建脚本生成hpm包...")
        packet_script = os.path.join(self.hpm_temp_dir, "packet.sh")
        os.chdir(self.hpm_temp_dir)
        ret = tool.run_command(f"bash {packet_script} package {self.hpm_temp_dir}", command_echo=False)
        if ret.returncode != 0:
            raise errors.BmcGoException(f"Failed to pack the hpm, error msg: {ret}")
        elif not os.path.exists(self.hpm_file):
            raise errors.BmcGoException("Failed to pack the hpm.")

    def get_generator(self):
        return PartnerSignGenerate(self.bconfig, self.strategy, "image.filelist")

    # 根据配置更新hpm签名算法XML文件
    def update_sign_algorithm_config(self, config_filepath):
        pattern_pairs = [
            (r'<fileset\s+path="[^>]*">', f'<fileset path="{self.hpm_temp_dir}">'),
            (r'<crlfile>[^<]+</crlfile>', f'<crlfile>{os.path.join(self.hpm_temp_dir, "crldata.crl")}</crlfile>')
        ]
        target_path = os.path.join(self.hpm_temp_dir, HPM_SIGN_FILENAME)
        self.regex_replace_text(config_filepath, pattern_pairs, target_path)

    def regex_replace_text(self, file_path, pattern_replacement_pairs, target_path):
        """
        对XML文件内容进行基于正则匹配的替换

        参数:
            file_path (str): XML文件的路径
            pattern_replacement_pairs (list): 正则表达式模式和替换内容的列表，每个元素为(pattern, replacement)元组

        返回:
            bool: 替换操作是否成功

        异常:
            FileNotFoundError: 当指定的XML文件不存在时
            IOError: 当文件读写出现问题时
        """

        # 读取XML文件内容
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()
        except IOError as e:
            log.error(f"读取文件失败: {e}")
            return False

        # 记录原始内容长度（用于验证）
        original_length = len(content)
        replacements_count = 0

        # 应用所有正则替换规则
        try:
            for pattern, replacement in pattern_replacement_pairs:
                # 编译正则表达式
                regex = re.compile(pattern)
                # 执行替换并计数
                new_content, count = regex.subn(replacement, content)
                if count > 0:
                    log.debug(f"模式 '{pattern}' 匹配到 {count} 处并替换为 '{replacement}'")
                    replacements_count += count
                    content = new_content  # 更新内容为替换后的结果
                else:
                    log.warning(f"模式 '{pattern}' 未找到匹配项")
        except re.error as e:
            log.error(f"正则表达式错误: {e}")
            return False
        # 将替换后的内容写回文件
        try:
            with open(target_path, 'w', encoding='utf-8') as file:
                file.write(content)
            log.debug(f"替换完成: 共执行 {replacements_count} 处替换")
            log.debug(f"文件大小变化: {original_length} -> {len(content)} 字符")
            return True

        except IOError as e:
            log.error(f"写入XML文件失败: {e}")
            return False

    def _get_sign_config(self):
        if self.sign_alg:
            return self.sign_alg
        if self.bconfig.hpm_sign_algorithm:
            return self.bconfig.hpm_sign_algorithm.config_path
        return HPM_SIGN_CONFIG_DEFAULT


class SignGenerateException(Exception):
    def __init__(self, message: str):
        super().__init__(message)


# eeprom华为签名生成类
class SignGenerate:
    def __init__(self, un_sign_bin: bytearray, work_dir: str):
        self.sign_data = bytearray()
        self._un_sign_data = un_sign_bin
        self._tmp_sign_path = os.path.join(work_dir, "tmp_sign")
        self._bin_file_path = os.path.join(self._tmp_sign_path, "tmpEeprom.bin")
        self._sign_suffix = ".ecc"
        self._sign_config = os.path.join(EEPROM_SIGN_PATH, "sign_eeprom.xml")
        self._sign_path = f"{self._bin_file_path}{self._sign_suffix}"

    def sign_file_process(self):
        # 清理签名工作空间
        if os.path.exists(self._tmp_sign_path):
            shutil.rmtree(self._tmp_sign_path)
        os.makedirs(self._tmp_sign_path, exist_ok=True)
        with open(self._bin_file_path, 'wb') as f:
            f.write(self._un_sign_data)

    def clean_sign_space(self):
        os.chdir(cwd)
        if os.path.exists(self._tmp_sign_path):
            shutil.rmtree(self._tmp_sign_path)

    def generate_sign(self):
        os.chdir(self._tmp_sign_path)
        sign_cmd = [
            "java",
            "-jar",
            SIGNATURE_TOOL,
            str(self._sign_config),
            "-file",
            str(self._bin_file_path)
        ]
        for _ in range(20):
            result = subprocess.run(sign_cmd, capture_output=True, text=True)
            if result.returncode != 0:
                raise errors.BmcGoException(f"Signature generation failed: {result.stderr}")

            if not os.path.exists(self._sign_path):
                raise errors.BmcGoException(f"Failed to find signature file: {self._sign_path}")
            # 验证签名
            verify_cmd = [
                "python3",
                SIGNATURE_VERIFY_SCRIPT,
                str(self._bin_file_path),
                str(self._sign_path)
            ]
            verify_result = subprocess.run(verify_cmd, capture_output=True, text=True)
            if verify_result.returncode == 0:
                with open(self._sign_path, 'rb') as f:
                    self.sign_data = f.read()
                os.chdir(cwd)
                return
            else:
                # 删除签名文件并重试
                Path(self._sign_path).unlink()
                log.info(f"Signature verification failed, regenerating signature: {verify_result.stderr}")
        raise errors.BmcGoException("Fail to generate valid signature")

    def execute(self) -> bytearray:
        # 签名生成前置文件处理操作
        self.sign_file_process()
        # 签名生成
        self.generate_sign()
        # 签名生成后清理临时工作空间
        self.clean_sign_space()
        return self.sign_data


class PartnerSignGenerate(OriHpmSignGenerator):
    def __init__(self, bconfig: BmcgoConfig, sign_strategy: str, unsigned_file: str):
        super().__init__(bconfig, sign_strategy, unsigned_file)