#!/usr/bin/python
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.

"""
功 能：该脚本实现自动转换指定组件 cmc 源码清单文件为manifest格式，入参为组件SrcBaseline.xml路径,产品name
版权信息：华为技术有限公司，版本所有(C) 2022-2023
"""
import os
import collections
import argparse
import stat
from xml.dom.minidom import parse, getDOMImplementation
import requests
from bmcgo import misc
from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.bmcgo_config import BmcgoConfig

tools = Tools()
log = tools.log

command_info: misc.CommandInfo = misc.CommandInfo(
    group="Misc commands",
    name="srcbaseline_to_manifest",
    description=["将标准srcbaseline.xml文件转换成manifest.xml文件"],
    hidden=True
)


def if_available(bconfig: BmcgoConfig):
    return not bconfig.partner_mode


class BmcgoCommand:
    """该脚本实现自动转换指定组件 cmc 源码清单文件为manifest格式，入参为组件SrcBaseline.xml路径,产品name"""
    def __init__(self, bconfig: BmcgoConfig, *args):
        self.need_xml = []
        self.remote = []
        self.open_source_d = None
        self.vendor_d = None
        self.code_list_d = None
        self.defult_remote = "codehub-dg-y"
        parser = argparse.ArgumentParser(description="从CMC产品包获取srcbaseline.xml文件并下载源码")
        parser.add_argument("-p", "--product_name", help="CMC产品包", required=True)
        parser.add_argument("-x", "--xml_file", help="srcbaseline.xml文件路径", required=True)
        parser.add_argument("-o", "--output_path", help="下载后源码存储目录", required=True)
        args = parser.parse_args(*args)
        self.output_path = os.path.realpath(os.path.join(args.output_path, args.product_name))
        self.product_name = args.product_name
        self.xml_file = os.path.realpath(args.xml_file)

    @staticmethod
    def get_tag_by_commit(commit_id, address):
        if commit_id.startswith(misc.REF_TAGS):
            return commit_id[10:]
        website = 'https://codehub-y.huawei.com/api/v4/projects/'
        encode_adress = address.replace('.git', '').replace('/', '%2F')
        resource2 = '/repository/tags?per_page=100'
        url = website + encode_adress + resource2
        # 配置文件中可能有多个 token, 必须逐个尝试
        git_token = tools.get_codehub_token()
        resp = None
        if isinstance(git_token, set) is True:
            for token in git_token:
                # 尝试下载成功后退出, 
                headers = {"PRIVATE-TOKEN": token}
                res = requests.get(url, headers=headers, verify=False)
                if res.status_code != 200:
                    continue
                resp = res.json()
                break
        else:
            headers = {"PRIVATE-TOKEN": git_token}
            res = requests.get(url, headers=headers, verify=False)
            resp = res.json()
        if resp is None:
            log.error("获取 resp 失败, 请检查 .git-credentials 配置文件或 codehub_token 环境变量")
        try:
            for info in resp:
                if info['commit']['id'] == commit_id:
                    return info['name']
        except Exception:
            log.warning("resp={}".format(resp))
        return None

    def create_xml(self, file_name: str):
        """组装多个配置文件信息
        Args:
            file_name (str): 最终生成的manifest配置文件的名称
        """
        # 生成一个dom对象，这个对象是xml的文档对象模型
        dom = getDOMImplementation().createDocument(None, "manifest", None)
        # 文档的根元素
        root = dom.documentElement
        if file_name == misc.DEPENDENCY_XML:
            # 组装视图xml
            self.get_dependency_xml(root, dom)
        elif file_name == "opensource.xml":
            # 组装 opensource.xml
            self.get_opensource_xml(root, dom)
        elif file_name == "vendor.xml":
            # 组装 vendor.xml
            self.get_vendor_xml(root, dom)
        elif file_name == misc.CODE_XML:
            # 组装 code.xml
            self.get_code_xml(root, dom)
        with os.fdopen(os.open(file_name, os.O_WRONLY | os.O_CREAT | os.O_APPEND,
                               stat.S_IWUSR | stat.S_IRUSR), 'a') as f:
            dom.writexml(f, addindent='\t', newl='\n', encoding='utf-8')

    def get_dependency_xml(self, root, dom):
        """根据文档根元素与文档对象模型配置节点
        Args:
            root (_type_): 文档根元素
            dom (_type_): 文档对象模型
        """
        # 组装 remote
        default = dom.createElement('default')
        default.setAttribute("remote", self.defult_remote)
        default.setAttribute(misc.GIT_REVISION, "master")
        for i_remote in self.remote:
            remote = dom.createElement('remote')
            root.appendChild(remote)
            remote.setAttribute("name", f"{i_remote.split('.huawei.com')[0]}")
            remote.setAttribute("fetch", f"https://{i_remote}")
        root.appendChild(default)
        for xml in self.need_xml:
            if xml != misc.DEPENDENCY_XML:
                # 组装 include的xml
                include = dom.createElement('include')
                root.appendChild(include)
                include.setAttribute("name", f"{self.product_name}/{xml}")

    def get_code_xml(self, root, dom):
        """根据文档根元素与文档对象模型配置节点
        Args:
            root (_type_): 文档根元素
            dom (_type_): 文档对象模型
        """
        project_list = list()
        for _, values in self.code_list_d.items():
            project = dom.createElement('project')
            if self.defult_remote not in values[0]:
                project.setAttribute("remote", values[0].split('/')[2].split('.huawei.com')[0])
            name_attr = values[0][values[0].find('.com') + 5:]
            project.setAttribute("name", name_attr)
            project.setAttribute("path", f"{self.product_name}/{values[3]}")
            is_tag = False
            if values[2].startswith(misc.REF_TAGS):
                project.setAttribute(misc.GIT_REVISION, values[2])
                is_tag = True
            elif values[2].startswith("tag_"):
                project.setAttribute(misc.GIT_REVISION, misc.REF_TAGS + values[2])
                is_tag = True
            else:
                tag = self.get_tag_by_commit(values[1], name_attr)
                if tag:
                    project.setAttribute(misc.GIT_REVISION, misc.REF_TAGS + tag)
                    is_tag = True
                else:
                    project.setAttribute(misc.GIT_REVISION, values[1])
                    project.setAttribute("upstream", values[2])
            project.setAttribute("groups", f"{self.product_name}")
            if is_tag:
                root.appendChild(project)
            else:
                project_list.append(project)
        for project in project_list:
            root.appendChild(project)

    def get_opensource_xml(self, root, dom):
        """根据文档根元素与文档对象模型配置节点
        Args:
            root (_type_): 文档根元素
            dom (_type_): 文档对象模型
        """
        for _, values in self.open_source_d.items():
            project = dom.createElement('project')
            root.appendChild(project)
            if self.defult_remote not in values[0]:
                project.setAttribute("remote", values[0].split('/')[2].split('.huawei.com')[0])
            name_attr = values[0][values[0].find('.com') + 5:]
            project.setAttribute("name", name_attr)
            project.setAttribute("path", f"{self.product_name}/{values[3]}")
            if values[2].startswith(misc.REF_TAGS):
                project.setAttribute(misc.GIT_REVISION, values[2])
            else:
                tag = self.get_tag_by_commit(values[1], name_attr)
                if tag:
                    project.setAttribute(misc.GIT_REVISION, misc.REF_TAGS + tag)
                else:
                    project.setAttribute(misc.GIT_REVISION, values[1])
                    project.setAttribute("upstream", values[2])
            project.setAttribute("groups", f"{self.product_name},{self.product_name}_opensource")

    def get_vendor_xml(self, root, dom):
        """根据文档根元素与文档对象模型配置节点
        Args:
            root (_type_): 文档根元素
            dom (_type_): 文档对象模型
        """
        for _, values in self.vendor_d.items():
            project = dom.createElement('project')
            root.appendChild(project)
            if self.defult_remote not in values[0]:
                project.setAttribute("remote", values[0].split('/')[2].split('.huawei.com')[0])
            name_attr = values[0][values[0].find('.com') + 5:]
            project.setAttribute("name", name_attr)
            project.setAttribute("path", f"{self.product_name}/{values[3]}")
            if values[2].startswith(misc.REF_TAGS):
                project.setAttribute(misc.GIT_REVISION, values[2])
            elif values[2].startswith("tag_"):
                project.setAttribute(misc.GIT_REVISION, misc.REF_TAGS + values[2])
            else:
                tag = self.get_tag_by_commit(values[1], name_attr)
                if tag:
                    project.setAttribute(misc.GIT_REVISION, misc.REF_TAGS + tag)
                else:
                    project.setAttribute(misc.GIT_REVISION, values[1])
                    project.setAttribute("upstream", values[2])
            project.setAttribute("groups", f"{self.product_name},{self.product_name}_vendor")

    def get_sourcecode_info(self, srcbaselinefile, prod_group_map):
        """解析xml文件，根据不同的仓的来源生成不同的xml文件"""
        tree = parse(srcbaselinefile)
        all_project_elem = tree.getElementsByTagName("fileidentify")
        # 遍历fileidentify字段返回结果
        for project_elem in all_project_elem:
            repo_base = project_elem.getAttribute(misc.REPO_BASE)
            # 获取组织名称
            component = repo_base.split('/')[3]
            # 尝试获取组织类型
            group_info = prod_group_map.get(self.product_name)
            # 获取 remote
            remote = repo_base.split('/')[2]
            repo_name = repo_base.split('/')[-1].split('.')[0]
            repo_revision = project_elem.getAttribute(misc.GIT_REVISION)
            repo_branch = project_elem.getAttribute("branch")
            local_path = project_elem.getAttribute("localpath")
            if local_path == "":
                continue
            if remote not in self.remote:
                self.remote.append(remote)
            if "OpenSourceCenter" in component:
                self.need_xml.append("opensource.xml")
                self.open_source_d.setdefault(repo_name, (repo_base, repo_revision, repo_branch, local_path))
            elif component == group_info:  # group信息相同，自研代码
                self.code_list_d.setdefault(repo_name, (repo_base, repo_revision, repo_branch, local_path))
            else:
                # 作为第三方放入
                self.need_xml.append("vendor.xml")
                self.vendor_d.setdefault(repo_name, (repo_base, repo_revision, repo_branch, local_path))

    def run(self):
        cmd = f"artget pull -sc {self.xml_file} -ap {self.output_path}"
        tools.run_command(cmd)
        for src_url_file in os.listdir(self.output_path):
            # 实例化传入参数进行处理
            srcbaselinefile = os.path.join(self.output_path, src_url_file)
            """根据配置文件以及产品名称初始化变量
            Args:
                srcbaselinefile (str): xml配置文件名称
                product_name (str): 产品名称
            """
            work_path = srcbaselinefile[:len(srcbaselinefile) - len(srcbaselinefile.split('/')[-1])]
            self.need_xml = [misc.DEPENDENCY_XML, misc.CODE_XML]
            self.remote = []
            self.open_source_d = collections.defaultdict()
            self.vendor_d = collections.defaultdict()
            self.code_list_d = collections.defaultdict()
            other_d = collections.defaultdict()
            prod_group_map = {
                "RTOS": "RTOS",
                "SDK": "kunpeng"
            }

            self.get_sourcecode_info(srcbaselinefile, prod_group_map)
            # 清理目录
            tools.remove_path(work_path)
            tools.check_path(work_path)
            os.chdir(work_path)
            self.need_xml = list(set(self.need_xml))
            os.chdir(work_path)
            for xml in self.need_xml:
                self.create_xml(xml)
            if len(other_d) > 0:
                log.warning("请检查以下组件 !!!")
                for _, values in other_d.items():
                    log.debug(values)
