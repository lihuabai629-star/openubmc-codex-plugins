#!/usr/bin/env python3
# encoding=utf-8
# 描述：组件的全量二进制构建
# Copyright (c) Huawei Technologies Co., Ltd. 2024. All rights reserved.
import os
import itertools
import json
import sys
import re
import stat
import shutil
import argparse
import importlib
import inspect
import functools
import random
from concurrent.futures import ProcessPoolExecutor, Future
from typing import List

import yaml

from bmcgo import misc
from bmcgo.misc import CommandInfo
from bmcgo.component.component_helper import (
    STAGE_STABLE,
    BUILD_TYPE_DEBUG,
    BUILD_TYPE_RELEASE,
)
from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.bmcgo_config import BmcgoConfig
from bmcgo_pro.tasks.misc import HI171X_MODULE_SYMVERS, HI171X_SDK_PATH

tool = Tools("build_full_conan2")
log = tool.log
command_info: CommandInfo = CommandInfo(
    group="Misc commands",
    name="build_full_conan2",
    description=["获取组件源码并构建出组件的全量二进制"],
    hidden=True,
)


def if_available(bconfig: BmcgoConfig):
    if bconfig.partner_mode:
        return False
    if bconfig.conan_index:
        return False
    return True


class BuildComponent:
    def __init__(
        self,
        pkg,
        profile: str,
        stage: str,
        build_type: str,
        options: dict,
        remote: str,
        upload=False
    ):
        self.bconfig = BmcgoConfig()
        self.pkg = pkg
        self.comp_name, self.comp_version, *_ = re.split("@|/", pkg)
        self.profile = profile
        self.stage = stage
        self.build_type = build_type
        self.options = options
        self.option_cmd = ""
        self.remote = remote
        self.upload = upload

    def run(self):
        for key, value in self.options.items():
            if key in ["enable_luajit", "test"]:
                self.option_cmd = self.option_cmd + f" -o '*/*:{key}={value}'"
            elif isinstance(key, str) and ":" in key:
                self.option_cmd = self.option_cmd + f" -o '{key}={value}'"
            else:
                self.option_cmd = self.option_cmd + f" -o '&:{key}={value}'"
        command = (f"conan install --requires='{self.pkg}' -of temp"
            f" -s:h build_type={self.build_type}"
            f" -pr {self.profile} -pr:b profile.dt.ini {self.option_cmd} --build=missing"
        )
        if self.remote:
            command += f" --remote {self.remote}"
        tool.run_command(command, show_log=True)
        log.success("组件{}构建成功".format(self.comp_name))
        if self.upload:
            log.info("上传组件包至conan仓......")
            tool.run_command(f'conan upload "*" --all --remote {self.remote} -c --no-overwrite')


class BmcgoCommand:
    def __init__(self, bconfig: BmcgoConfig, *args):
        parser = argparse.ArgumentParser(description="Fetch component source code and build all binaries.")
        parser.add_argument("-comp", "--component", help="软件包名, 示例: oms/1.2.6@openubmc/stable", required=True)
        parser.add_argument("-r", "--remote", help="远端仓库名称")
        parser.add_argument("-u", "--upload", action=misc.STORE_TRUE, help="上传组件包到conan仓")
        parser.add_argument("--config_file", help="全量二进制配置文件")
        parser.add_argument("--build_type", action="append", help="构建类型")

        parsed_args, _ = parser.parse_known_args(*args)
        self.bconfig = bconfig
        self.comp = parsed_args.component
        self.comp_name, self.comp_version, *_ = re.split("@|/", self.comp)
        self.remote = parsed_args.remote
        self.config_file_path = None
        if parsed_args.config_file:
            self.config_file_path = os.path.realpath(os.path.join(bconfig.cwd, parsed_args.config_file))
        self.upload = parsed_args.upload
        self.profile_list = ["profile.dt.ini", "profile.ini"]
        self.stage_list = [STAGE_STABLE]
        self.built_type_list = [BUILD_TYPE_DEBUG, BUILD_TYPE_RELEASE]
        if parsed_args.build_type:
            self.built_type_list = parsed_args.build_type
        self.options_dict = {}

    @staticmethod
    def get_build_options(conan_file_cls, config_file):
        options_dict = {}
        if hasattr(conan_file_cls, "options"):
            options_dict = conan_file_cls.options

        # 添加module_symver选项
        module_symvers_path = os.path.join(HI171X_SDK_PATH, HI171X_MODULE_SYMVERS)
        module_symver_key, module_symver_value = tool.get_hi171x_module_symver_option(module_symvers_path)
        if module_symver_key in options_dict:
            options_dict[module_symver_key] = [module_symver_value, ""]
        if config_file:
            with open(config_file, "r") as yaml_fp:
                obj = yaml.safe_load(yaml_fp)
            BmcgoCommand.generate_all_options(obj, options_dict)
            BmcgoCommand.generate_com_options(conan_file_cls, obj, options_dict)
        tool.log.info(f"组件全量options选项为: {options_dict}")
        return options_dict

    @staticmethod
    def generate_com_options(conan_file_cls, obj, options_dict):
        if conan_file_cls.name in obj:
            for exclude_option in obj[conan_file_cls.name].get("exclude_options", []):
                del options_dict[exclude_option]
            if obj[conan_file_cls.name].get("add_options", {}):
                options_dict.update(obj[conan_file_cls.name]["add_options"])

    @staticmethod
    def generate_all_options(obj, options_dict):
        if obj.get("all", {}):
            for exclude_option in obj["all"]["exclude_options"]: 
                if exclude_option in options_dict:
                    del options_dict[exclude_option]
            if obj["all"].get("add_options", {}):
                options_dict.update(obj["all"]["add_options"])

    def run(self):
        conan_file_cls = self.get_conan_file_cls()
        self.options_dict = self.get_build_options(conan_file_cls, self.config_file_path)
        self.build_all_packages()
        if self.upload:
            log.info("上传组件包至conan仓......")
            tool.run_command(f'conan upload "*" --all --remote {self.remote} -c --no-overwrite')

    def get_conan_file_cls(self):
        cache_path = tool.run_command(f"conan cache path {self.comp}", capture_output=True).stdout.strip()
        # 动态导入conanfile.py模块
        sys.path.append(cache_path)
        conan_file_module = importlib.import_module("conanfile")
        all_classes = [
            obj
            for name, obj in inspect.getmembers(conan_file_module)
            if inspect.isclass(obj) and obj.__module__ == conan_file_module.__name__
        ]
        conan_file_cls = None
        for cls in all_classes:
            # 如果有name和version，即返回
            if cls.name and cls.version:
                conan_file_cls = cls
                break
        return conan_file_cls

    def build_all_packages(self):
        """构建出组件所有组合的package包

        Args:
            service_json (str): 显式指定用于生成conanbase.py依赖的service.json路径
        """

        all_attributes = {
            "profile": self.profile_list,
            "stage": self.stage_list,
            "build_type": self.built_type_list,
        }
        # 不参与构建二进制的选项
        block_options = ["asan", "gcov"]
        options_dict = self.options_dict
        for block in block_options:
            options_dict.pop(block, None)

        all_attributes = {**all_attributes, **options_dict}
        # 设置变量让所有场景（包括DT）构建lua代码时都进行编译
        os.environ["TRANSTOBIN"] = "true"
        log.info(f"构建组件{self.comp}的全量二进制, 选项包含：{options_dict}")
        all_build_params = list(itertools.product(*all_attributes.values()))
        for build_args in all_build_params:
            profile, stage, build_type, *option_values = build_args
            build_options = dict(zip(options_dict.keys(), option_values))
            # bmc_sdk打包去除release包的x86测试版本
            if profile == "profile.dt.ini" and (not build_options.get("test") or build_type == BUILD_TYPE_RELEASE):
                continue
            if profile == "profile.ini" and build_options.get("test"):
                continue
            task = BuildComponent(
                self.comp,
                profile,
                stage,
                build_type,
                build_options,
                remote=self.remote,
                upload=self.upload,
            )
            task.run()
