#!/usr/bin/env python3
# encoding=utf-8
# 描述：拉取当前minifest快照下的全量代码
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2023. All rights reserved.
import os
import re
import sys
import argparse
import select

from bmcgo import errors

from bmcgo import misc
from bmcgo_pro.bmcgo_config import BmcgoConfig
from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.utils.install_package import InstallBmcgo
from bmcgo_pro.utils.install_package import InstallStudio

tools = Tools("bmcgo_upgrade")
log = tools.log
cwd = os.getcwd()

command_info: misc.CommandInfo = misc.CommandInfo(
    group="Misc commands",
    name="upgrade",
    description=["升级BMCGO以及BMC STUDIO版本"],
    hidden=False
)


def if_available(bconfig: BmcgoConfig):
    if bconfig.partner_mode:
        return False
    return True


def process_err_cb(err):
    log.error("进程运行失败, 错误: %s", err)


class BmcgoCommand:
    def __init__(self, bconfig: BmcgoConfig, *args):
        self.bconfig = bconfig
        parser = argparse.ArgumentParser(prog="bmcgo upgrade", description="升级bmcgo工具", add_help=True,
                                         formatter_class=argparse.RawTextHelpFormatter)
        parser.add_argument("version", help="指定待升级的版本号\n" +
                            "bmcgo=0.6.0: 升级至0.6.0版本." +
                            "bmcgo=latest: 升级至最新版本（默认值）.\n" +
                            "bmcgo<0.6.0: 升级至小于0.6.0的最新版本." +
                            "bmcgo<=0.6.0: 升级至小于等于0.6.0的最新版本.", nargs="?", default="all=latest")
        parser.add_argument("-f", "--force", help="强制升级无需确认", action="store_true")

        parsed_args, _ = parser.parse_known_args(*args)
        self.version = parsed_args.version
        self.force = parsed_args.force

    @staticmethod
    def install_git_hook():
        hook_file = "/usr/share/bmcgo/git-hooks/commit-msg"
        hook_dir, ret = tools.pipe_command(["git config --global core.hookspath"],
                                           capture_output=True, ignore_error=True)
        if ret != 0:
            hook_dir = os.path.join(os.environ["HOME"], ".git-hooks")
        else:
            hook_dir = hook_dir.strip()
        tgt_file = os.path.join(hook_dir, "commit-msg")
        if os.path.isfile(tgt_file):
            return
        if not os.path.isdir(hook_dir):
            os.makedirs(hook_dir)
        tools.run_command(f"cp -f {hook_file} {tgt_file} -f", ignore_error=True)
        tools.run_command(f"git config --global core.hookspath {hook_dir}")
        tools.run_command(f"chmod +x {tgt_file}")

    def parse_version(self):
        match = re.search("^([bmcgo|studio|all]*)([<=|>=|<|>|=].*)", self.version)
        if not match:
            return ("all", "=latest")

        return (match.group(1), match.group(2))

    def run(self):
        action_list = []
        (app_name, version) = self.parse_version()
        cls_map = {"bmcgo": InstallBmcgo, "studio": InstallStudio}
        if app_name == "all":
            app_notice = "bmcgo 和 studio"
            action_list.append(InstallBmcgo(version=version))
            action_list.append(InstallStudio(version=version))
        else:
            app_notice = app_name
            clas = cls_map.get(app_name)
            action_list.append(clas(version=version))

        if not self.force:
            log.info(f"注意：升级前会自动卸载bmcgo，如安装失败，需要执行pip3 install hw_ibmc_bmcgo安装bmcgo")
            log.info(f"请确认是否执行命令pip3 install {app_notice}， (Y/N)")
            select_in, _, _ = select.select([sys.stdin], [], [], 10)
            if select_in is None or sys.stdin.readline().strip().lower() != "y":
                log.debug("退出..")
                raise errors.BmcGoException("bmcgo版本号不匹配，退出执行。")

        for clas in action_list:
            clas.install()

        self.install_git_hook()
        log.info("升级已完成，请在bmcgo退出后重新执行")      
        return 0
