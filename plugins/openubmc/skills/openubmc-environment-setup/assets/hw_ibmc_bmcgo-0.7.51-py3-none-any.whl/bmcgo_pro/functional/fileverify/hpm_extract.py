#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2023-2025. All rights reserved.

"""
文件名: hpm_extract.py
功能: 拆解hpm包, 分析组成
版权信息: 华为技术有限公司，版本所有(C) 2020-2024
"""
import os
import subprocess
import shutil
from bmcgo_pro.logger import Logger

# hpm包前导字节
global HPM_HEAD_LEN
HPM_HEAD_LEN = 56

# 每次读取的便宜自字节数量
global OFFSET_STEP
OFFSET_STEP = 8

global SIGNATURE_HEAD_LEN
SIGNATURE_HEAD_LEN = 8

log = Logger()


class HpmExtract:
    def __init__(self, hpm_file: str, ca_file: str):
        """ 初始化 hpm 包导出

        Args:
            hpm_file (str): hpm 包的文件名
            ca_file (str): 要进行校验的根证书的名字

        Raises:
            e: 签名格式转换错误时抛出
        """
        self.hpm_file = os.path.realpath(hpm_file)
        self.hpm_name = os.path.basename(self.hpm_file).replace(".hpm", "")
        self.work_path = os.path.join(os.path.dirname(self.hpm_file), "hpm_extract")
        if os.path.exists(self.work_path):
            shutil.rmtree(self.work_path)
        os.makedirs(self.work_path, exist_ok=True)
        self.head_len_conf = self.__get_head_conf()
        # 将 pem 导出目录设置到工作目录
        self.ca_file = self.__trans_der2pem(ca_file)

    def hpm_filelist(self):
        """ 获取被签名的 filelist 的源文件

        Returns:
            str: 返回生成 filelist 源文件名
        """
        offset = HPM_HEAD_LEN
        hpm_filelist_length = self.head_len_conf[2]
        # 由于为第一数据字段, 只偏移 56 字节头
        hpm_filelist = self.__get_field_data(offset, hpm_filelist_length).decode("utf-8")
        output_filelist_name = os.path.join(self.work_path, f"{self.hpm_name}.filelist")
        with open(output_filelist_name, mode="w+") as fp_filelist:
            fp_filelist.write(hpm_filelist)
        return output_filelist_name

    def hpm_filelist_cms(self):
        """ 获取被加密的 cms 文件信息

        Returns:
            str: 返回生成的 cms 文件名
        """
        offset = HPM_HEAD_LEN + self.head_len_conf[2]
        hpm_filelist_cms_len = self.head_len_conf[4]
        # 第二数据字段, 偏移 56 + 第一字段长度 字节头
        hpm_filelist_cms = self.__get_field_data(offset, hpm_filelist_cms_len)
        output_filelist_cms = os.path.join(self.work_path, f"{self.hpm_name}.filelist.cms")
        with open(output_filelist_cms, mode="wb+") as fp_cms:
            fp_cms.write(hpm_filelist_cms)
        return output_filelist_cms

    def hpm_cms_crl(self):
        """ 获取吊销列表

        Returns:
            str: 返回生成的 crl 文件名
        """
        offset = HPM_HEAD_LEN + self.head_len_conf[2] + self.head_len_conf[4]
        hpm_cms_crl_len = self.head_len_conf[6]
        # 第三数据字段, 偏移 56 + 第一字段长度 + 第二段字节长度 字节头
        hpm_cms_crl = self.__get_field_data(offset, hpm_cms_crl_len)
        output_cmc_crl = os.path.join(self.work_path, f"{self.hpm_name}.filelist.crl")
        with open(output_cmc_crl, mode="wb+") as fp_crl:
            fp_crl.write(hpm_cms_crl)
        return output_cmc_crl

    def cms_verify(self):
        """ 检验签名

        Raises:
            e: hpm_verify 命令执行失败时抛出
        """
        filelist_src = self.get_field("hpm_filelist")
        filelist_cms = self.get_field("hpm_filelist_cms")
        try:
            cmd = ["/usr/local/bin/hpm_verify", "-r", self.ca_file, "-s", filelist_cms, "-c", filelist_src]
            subprocess.run(cmd, check=True)
            log.info("校验签名成功")
        except subprocess.CalledProcessError as e:
            # 失败了保留工作目录, 用于调试或检查
            log.error("校验签名失败")
            raise e

    def get_field(self, filed_name: str, *args, **kwargs):
        """ 获取指定函数并执行

        Args:
            filed_name (str): 函数名

        Raises:
            e: 函数名不存在或者函数执行错误时抛出异常

        Returns:
            _type_: 指定函数名的函数返回值, 类型由函数自身决定
        """
        try:
            func = getattr(self, filed_name)
            data = func(*args, **kwargs)
            return data
        except AttributeError as e:
            custom_functions = \
                [func for func in dir(self) if callable(getattr(self, func)) and not func.startswith("__")]
            log.info(f"请检查属性输入是否正确, 可用属性为 {custom_functions}")
            raise e
        except TypeError as e:
            help(func)
            raise e

    def __trans_der2pem(self, ca_file):
        """ 转换文件格式

        Args:
            ca_file (_type_): 下载下来的 der 格式文件

        Raises:
            e: 转换命令报错时抛出

        Returns:
            _type_: 转换后的文件的路径
        """
        pem_format_ca = f"{self.work_path}/{ca_file.rsplit('/', 1)[-1].split('.')[0]}.pem"
        try:
            cmd = [
                "/usr/bin/openssl", "x509", "-in", ca_file, "-inform", "der",
                "-outform", "pem", "-out", pem_format_ca
            ]
            subprocess.run(cmd, check=True)
            log.info("签名格式转换为 pem 成功")
            return pem_format_ca
        except Exception as e:
            log.info("签名格式转换为 pem 失败")
            raise e

    def __get_head_conf(self):
        """ 获取 hpm 包文件头长度配置

        Returns:
            _type_: 包头各部分长度配置
        """
        head_len_conf = []
        # 不使用全局的 fp, 避免重复的重定位与复杂的加减，不如重新打开
        with open(self.hpm_file, mode="rb") as fp:
            # 头部 56 个字节, 包括 8 个字节文件头, 以及用来存储每个字段的编号以及长度
            hpm_head = fp.read(HPM_HEAD_LEN)
            for offset in range(0, HPM_HEAD_LEN, OFFSET_STEP):
                # 分段存储到 list 里面, 用于后续使用
                head_len_conf.append(int(hpm_head[offset:offset + OFFSET_STEP], 16))
        return head_len_conf

    def __get_field_data(self, offset: int, length: int):
        """ 获取文件指定偏移位置的文件

        Args:
            offset (int): 偏移量
            length (int, optional): 偏移长度, 默认值为 0

        Returns:
            byte: 返回一个 byte 对象
        """
        with open(self.hpm_file, mode="rb") as fp:
            fp.seek(offset, 0)
            data = fp.read(length)
            return data


if __name__ == "__main__":
    selftest = HpmExtract("rootfs_TaiShan200_2280v2.hpm", "rootca.der")
    selftest.get_field("cms_verify")