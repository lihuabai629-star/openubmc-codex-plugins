#!/usr/bin/env python3
# encoding=utf-8
# 描述：组件维护工具
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2023. All rights reserved.
import os
import urllib3
from bmcgo.misc import CommandInfo
from bmcgo.functional.deploy import BmcgoCommand as BingoCommand
from bmcgo.functional.deploy import if_available as bingo_if_available
from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.bmcgo_config import BmcgoConfig

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

tool = Tools("deploy")
log = tool.log
command_info: CommandInfo = CommandInfo(
    group="Misc commands",
    name="deploy",
    description=["产品包部署"],
    hidden=True
)


def if_available(bconfig: BmcgoConfig):
    return bingo_if_available(bconfig)


class BmcgoCommand(BingoCommand):
    def __init__(self, bconfig: BmcgoConfig, *args):
        https_proxy = os.environ.get("https_proxy")
        if https_proxy is not None and https_proxy != "":
            log.warning("检测到环境设置了https_proxy代理，可能导致访问iBMC失败.")
            log.warning("  如需关闭代理，请执行命令: export https_proxy=")
            log.warning("  如需关闭特定域名或IP的代理，可以设置no_proxy环境变量，也可将no_proxy设置到/etc/profile中.")
            log.warning("  no_proxy配置示例: export no_proxy=localhost,127.0.0.0/8,.huawei.com,.inhuawei.com")
        super().__init__(bconfig, *args)
        self.config_name = ".ibmc_config.yml"