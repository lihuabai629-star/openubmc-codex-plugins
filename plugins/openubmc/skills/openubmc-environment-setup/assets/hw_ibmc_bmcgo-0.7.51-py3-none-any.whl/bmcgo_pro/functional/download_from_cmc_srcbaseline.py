#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
"""
功 能：download_from_cmc类，该类主要涉及将 CMC上与BMC配套的二进制组件 binIBMC 下载到本地代码库中复位
据信息树配置文件下载配套软件包，平台文件
版权信息：华为技术有限公司，版本所有(C) 2019-2023
"""

import os
import argparse
import shutil
import stat
from xml.dom.minidom import getDOMImplementation

from bmcgo import errors

from bmcgo import misc
from bmcgo_pro.utils.artget_code_down import ArtgetDownload
from bmcgo_pro.utils.get_manifest import GetManifestTree
from bmcgo_pro.bmcgo_config import BmcgoConfig
from bmcgo_pro.utils.tools import Tools


tools = Tools("download_from_cmc_srcbaseline")
log = tools.log
command_info: misc.CommandInfo = misc.CommandInfo(
    group="Misc commands",
    name="download_from_cmc_srcbaseline",
    description=[
        "将 CMC上与BMC配套的二进制组件 binIBMC 下载到本地代码库中",
        "据信息树配置文件下载配套软件包，平台文件"
    ],
    hidden=True
)


def if_available(bconfig: BmcgoConfig):
    return not bconfig.partner_mode and bconfig.manifest


class BmcgoCommand:
    """
    download_from_cmc类，该类主要涉及将 CMC上与BMC配套的二进制组件 binIBMC 下载到本地代码库中复位
    据信息树配置文件下载配套软件包，平台文件
    """
    def __init__(self, bconfig: BmcgoConfig, args):
        """初始化
        Args:
            config (Config): 公共配置
            produce_name (_type_): 产品名称，比如RTOS，SDK
            xml_path (_type_): xml配置文件路径
            donot_download_list (list, optional): 不需要下载的模块列表，默认为空列表
            token (str, optional): 开源的token，默认为"osRUh8ERTgFWJd_aLg4"
            from_source (bool, optional): 是否开启本地调试，默认不开启，也就是不下载代码到本地
        """
        parser = argparse.ArgumentParser(description="Excute download_from_cmc_srcbaseline.py")
        parser.add_argument("-p", "--product", help="Product Name", required=True)
        parser.add_argument("-x", "--xml", required=True,
                            help="Relative path of the srcbaseline.xml file.",)
        parser.add_argument("-d", "--donot_download_list", help="Do not download the module path", default="")
        parser.add_argument("-t", "--token", help="Token value of git download code", default="-osRUh8ERTgFWJd_aLg4")
        parser.add_argument("-s", "--from_source", help="使能全量源码构建", action=misc.STORE_TRUE)
        parsed_args, _ = parser.parse_known_args(args)
        self.bconfig = bconfig
        self.code_root = bconfig.manifest.folder
        self.from_source = parsed_args.from_source
        self.produce_name = parsed_args.product
        self.xml_path = parsed_args.xml
        if self.produce_name == "":
            raise errors.ConfigException("--product 参数无法配置为空字符串")
        if self.xml_path == "":
            raise errors.ConfigException("--xml 参数无法配置为空字符串")
        self.download_path = os.path.join(self.code_root, "temp", "manifest_xml", self.produce_name)
        if os.path.exists(self.download_path):
            shutil.rmtree(self.download_path)
        os.makedirs(self.download_path, exist_ok=True)
        self.donot_download_list = parsed_args.donot_download_list
        self.codehub_token = parsed_args.token

    def create_sourcecode_xml(self, assemble_dict: dict):
        """整合多个xml配置信息(url: Repo)，组成一个新的xml
        Args:
            assemble_dict (dict): xml配置信息
        """
        dom = getDOMImplementation().createDocument(None, "Results", None)
        root = dom.documentElement
        dependent_source_files = dom.createElement('dependentSourceFiles')
        root.appendChild(dependent_source_files)
        for values in assemble_dict.values():
            fileidentify = dom.createElement('fileidentify')
            dependent_source_files.appendChild(fileidentify)
            fileidentify.setAttribute("repoType", "GIT")
            fileidentify.setAttribute(misc.REPO_BASE, values.get_remote_url())
            fileidentify.setAttribute("revision", values.get_revision())
            fileidentify.setAttribute("branch", values.get_branch())
            fileidentify.setAttribute("localpath", values.get_local_path())

        with os.fdopen(os.open(f"{self.download_path}/sourcecode.xml", os.O_WRONLY | os.O_CREAT | os.O_APPEND,
                               stat.S_IWUSR | stat.S_IRUSR), 'a') as f:
            dom.writexml(f, addindent='\t', newl='\n', encoding='utf-8')

    def assemble_xml(self):
        """
        将多个xml解析重组成一个新的xml配置
        """
        assemble_dict = {}
        remove_list = []
        for sub_xml in tools.list_all_file("sourcecode.*", self.download_path):
            xml_obj = ArtgetDownload()
            repodict = xml_obj.get_repodict(sub_xml)
            for values in repodict.values():
                assemble_dict[values.get_local_path()] = values
            remove_list.append(sub_xml)
        # 字典形式为：url: Repo ，Repo为一个class
        self.create_sourcecode_xml(assemble_dict)
        for rm_xml in remove_list:
            os.remove(rm_xml)

    def run(self):
        """下载"""
        # 获取xml的绝对路径，接口调用的是realpath
        dependency_file = os.path.realpath(self.xml_path)
        # 配置日志输出位置
        log.info(f"使用 artget 获取产品 {self.produce_name} 的 xml 配置文件开始")
        # 清理上一次的缓存，每次直接删除，貌似不太合适
        if dependency_file.split('/')[-1].find('*'):
            # 这个参数由work_get_manifest.py传入
            for d_file in tools.list_all_file("srcbaseline.*", os.path.dirname(dependency_file)):
                cmd = f"artget pull -sc {d_file} -ap {self.download_path}"
                tools.run_command(cmd, show_log=True)
            self.assemble_xml()
        else:
            # 普通的下载配置，直接下载
            cmd = f"artget pull -sc {dependency_file} -ap {self.download_path}"
            tools.run_command(cmd, show_log=True)
        # 获取完所有组件的xml配置，里面写了各个仓源码属性
        log.info(f"使用 artget 获取产品 {self.produce_name} 的 xml 配置文件结束")
        artget_download = ArtgetDownload()
        for src_url_file in os.listdir(self.download_path):
            if "source" in src_url_file:
                # 如果是源码构建
                if self.from_source:
                    log.info(f'开始获取 {self.produce_name} 源码')
                    artget_download.download(f"{self.download_path}/{src_url_file}",
                                             self.download_path, f"{self.donot_download_list}",
                                             f"{self.codehub_token}")
                    log.info(f'获取 {self.produce_name} 源码结束')
                    continue

            # 实例化传入参数进行处理
            manifest = GetManifestTree(f"{self.download_path}/{src_url_file}", self.produce_name)
            manifest.get_sourcecode_info()
            # 清理目录
            tools.remove_path(manifest.work_path)
            tools.check_path(manifest.work_path)
            os.chdir(manifest.work_path)
            manifest.need_xml = list(set(manifest.need_xml))
            os.chdir(manifest.work_path)
            for xml in manifest.need_xml:
                manifest.create_xml(xml)
            if len(manifest.other_d) > 0:
                log.warning("请检查以下组件 !!!")
                for _, values in manifest.other_d.items():
                    log.debug(values)
