#!/usr/bin/env python
# coding: utf-8
# Copyright © Huawei Technologies Co., Ltd. 2023-2025. All rights reserved.
# 从ipmc.bin中恢复uboot/gpp/datafs/user分区，用于调试烧片包
import sys
import os
import subprocess
from bmcgo_pro.logger import Logger

log = Logger()


class FileChunk:
    def __init__(self, filename, seek, count, skip):
        self.filename = filename
        self.seek = seek
        self.count = count
        self.skip = skip


class FileOutput:
    def __init__(self, filename, ipmc_bin):
        self.filename = filename
        self.section_name = os.path.basename(self.filename)
        self.ipmc_bin = ipmc_bin
        self.size = 0
        self.file_chunks: list[FileChunk] = []

    def append_chunk(self, chunk: FileChunk):
        last_pos = chunk.seek + chunk.count
        if last_pos > self.size:
            self.size = last_pos
        self.file_chunks.append(chunk)

    def generate(self):
        cmd = ["/usr/bin/dd", "if=/dev/zero", f"of={self.filename}", "bs=512", f"count={self.size}"]
        log.info("执行命令: %s", " ".join(cmd))
        subprocess.run(cmd, check=True)
        for chunk in self.file_chunks:
            cmd = [
                "/usr/bin/dd", f"if={self.ipmc_bin}", f"of={self.filename}", "bs=512", f"seek={chunk.seek}",
                f"count={chunk.count}", f"skip={chunk.skip}", "conv=notrunc"
            ]
            log.info("执行命令: %s", " ".join(cmd))
            subprocess.run(cmd, check=True)


def proc_ipmc_bin(m4i, ipmc_bin, output_path: str):
    if os.path.isabs(output_path) is False:
        # 这里做设置路径, 如果 output 不是绝对路径, 则在 ipmc.bin 同级目录取相对路径
        output_path = os.path.join(os.path.dirname(os.path.realpath(ipmc_bin)), output_path)
    os.makedirs(output_path, exist_ok=True)
    ipmc_bin = os.path.realpath(ipmc_bin)
    m4i = os.path.realpath(m4i)

    file_chunks: list[FileChunk] = []
    with open(m4i, "r") as fp:
        filename = ""
        lines = fp.readlines()
        skip = 0
        for line in lines:
            line = line.strip()
            if not line.startswith("#\t"):
                continue
            if line.startswith("#\tBOOT1"):
                filename = "boot1.bin"
            elif line.startswith("#\tBOOT2"):
                filename = "boot2.bin"
            elif line.startswith("#\tGPP1"):
                filename = "gpp1.bin"
            elif line.startswith("#\tGPP2"):
                filename = "gpp2.bin"
            elif line.startswith("#\tGPP3"):
                filename = "gpp3.bin"
            elif line.startswith("#\tGPP4"):
                filename = "gpp4.bin"
            elif line.startswith("#\tUSER"):
                filename = "user.bin"
            else:
                log.error("无效行: %s", line)
            # line 被重置起始偏移值到行尾
            line = line.split("@", 1)[1]
            # 以 , 分割成列表
            splits = line.split(",", 2)
            # 起始偏移
            seek = int(splits[0])
            # splits 被重置为结束偏移值和路径配置
            splits = splits[1].split("=", 1)
            # 取结束偏移量存储
            count = int(splits[0])
            # skip 从 0 开始计算
            file_chunks.append(FileChunk(filename, seek, count, skip))
            skip += count

    file_outputs: list[FileOutput] = []
    for chunk in file_chunks:
        found = False
        for out in file_outputs:
            # 已存在的字段, 直接在后面追加
            if out.section_name == chunk.filename:
                out.append_chunk(chunk)
                found = True
        if not found:
            # 没有配置的字段新增一个字段
            out = FileOutput(os.path.join(output_path, chunk.filename), ipmc_bin)
            out.append_chunk(chunk)
            file_outputs.append(out)

    for out in file_outputs:
        out.generate()

if __name__ == "__main__":
    if len(sys.argv) != 3:
        log.info("参数错误, 用法: %s <m4i_file> <ipmc.bin>", sys.argv[0])
        sys.exit(-1)
    proc_ipmc_bin(sys.argv[1], sys.argv[2], "output")
