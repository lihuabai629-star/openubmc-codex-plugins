#!/usr/bin/env python3
# encoding=utf-8
# 描述：BMC Studio语法正确性与模型一致性检查
# Copyright (c) Huawei Technologies Co., Ltd. 2024. All rights reserved.
import os
import tempfile
import yaml
from git import Repo

from bmcgo.functional.check import BmcgoCommand as OriBmcgoCommand
from bmcgo import misc
from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.bmcgo_config import BmcgoConfig


log = Tools().log
cwd = os.getcwd()
command_info: misc.CommandInfo = misc.CommandInfo(
    group=misc.GRP_STUDIO,
    name="check",
    description=["BMC Studio语法正确性与模型一致性检查"],
    hidden=False
)
COMMUNITY_URL = "https://codehub-dg-y.huawei.com/iBMC_V3/community.git"
ISSUE_TEMPLATE = '''问题{0}：
【规则名称】{1}
【文件路径】{2}
【错误提示】{3}
【修复建议】{4}
'''
_PACKAGE_INFO_HELP = """
1. 通过组件包名及版本拉取单个组件源码，格式：package/version@user/channel
2. 通过配置文件拉取部分指定版本的组件源码。支持以下2种配置文件：
  a. yml格式
    dependencies:
    - conan: "package/version@user/channel"
  b. 文本格式
    package/version@user/channel
"""


def if_available(bconfig: BmcgoConfig):
    return True


class BmcgoCommand(OriBmcgoCommand):
    MODEL_CHOICES = ["all", "factory", "mds", "device_tree", "resource_tree", "dds", "csr", "interface_mapping"]
    BOARD_NAME_DEFAULT = "TaiShan200_2280v2"
    COMMUNITY_URL = "https://codehub-dg-y.huawei.com/iBMC_V3/community.git"

    def find_community_config(self, tempdir: str):
        """查找community配置文件"""
        Repo.clone_from(self.community_url, tempdir, branch=self.community_branch)
        for entry in os.scandir(os.path.join(tempdir, "sig")):
            if not entry.is_dir():
                continue
            for file in os.scandir(os.path.join(entry, "components")):
                if file.is_file() and file.name in [f"{self.repo_name}.yml", f"{self.repo_name}.yaml"]:
                    return file
        return None

    def parse_community_issues(self):
        """解析community配置中的问题屏蔽记录"""
        with tempfile.TemporaryDirectory(prefix="community_repo_") as tempdir:
            config_file = self.find_community_config(tempdir)
            if config_file is None:
                log.info("community仓库中找不到 %s 对应的屏蔽记录文件", self.repo_name)
                return
            with open(config_file, 'r') as yaml_fp:
                obj = yaml.safe_load(yaml_fp)

        # 更新禁用状态和问题屏蔽列表
        studio_check_config = obj.get("studio_check", {})
        self.disabled = studio_check_config.get("disable", False)

        for issue in studio_check_config.get("issues", []):
            rule = issue.get("rule")
            filepath = issue.get("filepath")
            branch = issue.get("branch")

            condition = (branch is None or branch == self.repo_branch) and \
                       not self.check_overdue(issue) and \
                       rule is not None and filepath is not None

            if condition:
                self.community_issues.add((rule, filepath))

    def _create_parser(self):
        parser = super()._create_parser()
        parser.description = "语法正确性与模型一致性检查"
        parser.prog = "bmcgo check"

        parser.add_argument("--community_url", help="community仓库地址, 用于获取问题屏蔽记录", default=self.COMMUNITY_URL)
        parser.add_argument("--community_branch", help="community仓库分支", default="master")

        return parser

    def _init_specific_attributes(self, parsed_args):
        """初始化子类特有的属性，该函数在父类构造函数被调用"""
        self.community_url = parsed_args.community_url
        self.community_branch = parsed_args.community_branch
        # 子类默认禁用检查，直到解析community配置
        self.disabled = True

    def _before_run(self):
        """运行前的准备工作 - 解析community配置，在父类被调用"""
        self.parse_community_issues()

    def _filter_issue(self, item):
        """重写问题过滤逻辑，添加community issues过滤，在父类被调用"""
        rule = item.get("rule")
        filepath = item.get("filepath")

        if rule is None or filepath is None or (rule, filepath) in self.community_issues:
            return False
        return True