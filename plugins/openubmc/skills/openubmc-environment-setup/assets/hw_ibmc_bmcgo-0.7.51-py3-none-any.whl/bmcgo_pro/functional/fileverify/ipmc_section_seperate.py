#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2023-2025. All rights reserved.

"""
文件名: ipmc_section_seperate.py
功能: 拆解 ipmc.bin 包, 取出成分
版权信息: 华为技术有限公司，版本所有(C) 2020-2024
"""
import os
import subprocess
import re
import shutil
from bmcgo_pro.logger import Logger


log = Logger()
BLOCK_SIZE = 512
EXTRACT_FILE_FUNC = "get_file"


class IpmcSectionSeperate:
    def __init__(self, bin_file: str, user_section_conf="", flag=False):
        """ 初始化, 获取到必要文件的句柄, 以及字段配置

        Args:
            user_section (str): 通过 ipmc.bin 恢复的 user.bin 文件名
            user_section_conf (str): ipmc.bin 文件的配置文件名
        """
        self.bin_file = os.path.realpath(bin_file)
        self.output_path = os.path.join(os.path.dirname(self.bin_file), "ipmc_seperate")
        if os.path.exists(self.output_path):
            shutil.rmtree(self.output_path)
        os.makedirs(self.output_path, exist_ok=True)
        self.user_section_conf = os.path.realpath(user_section_conf)
        self.flag = flag
        normal_data = {
            "partition0": int("0x0", 16),
            "datafs.img": int("0x2000", 16),
            "sp.bin": int("0x40002000", 16),
            "partition1": int("0x11ae4a000", 16),
            "iBMA.bin": int("0x11ae4c000", 16),
            "partition2": int("0x12e17f400", 16),
            "rootfs_iBMC.img": int("0x12e181400", 16),
            "partition3": int("0x15ae4e000", 16),
            "partition4": int("0x180ffe000", 16)
        }

        detailed_data = {
            "partition0": int("0x0", 16),
            "datafs.img": int("0x2000", 16),
            "sp.bin": int("0x40002000", 16),
            "partition1": int("0x11ae4a000", 16),
            "iBMA.bin": int("0x11ae4c000", 16),
            "partition2": int("0x12e17f400", 16),
            "rootfs_iBMC.img": int("0x12e181400", 16),
            "partition_trust": int("0x15ae4e000", 16),
            "partition_sdkm3": int("0x16ae50000", 16),
            "partition_log": int("0x16be52000", 16)
        }

        if self.flag:
            self.data_conf = detailed_data
        else:
            self.data_conf = normal_data

    def get_file(self, section_name: str):
        """ 获取字段文件

        Args:
            section_name (str): 配置字段名
        """
        start, data_len = self.__get_section_offset(section_name)
        self.__get_export_file(start, data_len, os.path.join(self.output_path, section_name))

    def get_field(self, filed_name: str, *args, **kwargs):
        """ 执行对应字段的函数

        Args:
            filed_name (str): 函数名

        Raises:
            AttributeError: 当函数名不存在时抛出
            TypeError: 参数传入错误时抛出

        Returns:
            _type_ : 这个返回值类型与函数返回值相关
        """
        try:
            func = getattr(self, filed_name)
            data = func(*args, **kwargs)
            return data
        except AttributeError as e:
            custom_functions = \
                [func for func in dir(self) if callable(getattr(self, func)) and not func.startswith("__")]
            log.info(f"请检查属性输入是否正确, 可用属性为 {custom_functions}")
            raise e
        except TypeError as e:
            help(func)
            raise e

    def run(self):
        function_name_list = [
            "partition0", "datafs.img", "sp.bin",
            "partition1", "iBMA.bin",
            "partition2", "rootfs_iBMC.img",
        ]

        if self.flag:
            function_name_list.append("partition_trust")
            function_name_list.append("partition_sdkm3")
            function_name_list.append("partition_log")
        else:
            function_name_list.append("partition3")

        for func in function_name_list:
            try:
                # 获取到其中所有的字段
                self.get_field(EXTRACT_FILE_FUNC, func)
            except Exception as e:
                # NOTE 在调试时在这里可以把异常抛出
                continue

    def __get_export_file(self, start: int, length: int, output_file: str):
        """ 根据起始位置和偏移, 来导出文件

        Args:
            start (int): 起始偏移
            length (int): 输出文件长度
            output_file (str): 输出的文件的文件名

        Raises:
            ValueError: ipmc.bin 配置文件中配置的长度异常
            subprocess.CalledProcessError: dd 命令执行错误时抛出
        """
        block_size = BLOCK_SIZE
        if start % BLOCK_SIZE != 0 or length % BLOCK_SIZE != 0:
            raise ValueError(f"长度不能被 {BLOCK_SIZE} 整除, 请检查配置文件是否正确")
        skip_block = start // BLOCK_SIZE
        block_count = length // BLOCK_SIZE
        cmd = [
            "/usr/bin/dd", f"if={self.bin_file}", f"of={output_file}", f"bs={block_size}",
            f"skip={skip_block}", f"count={block_count}"
        ]
        try:
            subprocess.run(cmd, check=True)
        except subprocess.CalledProcessError as e:
            log.error("dd 命令生成 %s 文件时执行错误, 请检查偏移", output_file)
            raise e

    def __get_config_data(self):
        """ 获取配置文件的配置, 接口预留

        Returns:
            {str: int}: 字段名: 起始位置
        """
        data_config = {}
        with open(self.user_section_conf) as cfp:
            for line in cfp.readlines():
                if line.startswith("/"):
                    continue
                else:
                    line_list = re.split(r'\s+', line.strip())
                    offset = int(line_list[2], 16)
                    data_config.update({line_list[0]: offset})
        sort_data_config = dict(sorted(data_config.items(), key=lambda x: x[1]))
        return sort_data_config

    def __get_section_offset(self, section_name: str):
        """ 检查字段配置的存在性, 并返回起始位置以及长度

        Args:
            section_name (str): 要获取的字段名字

        Raises:
            AttributeError: 当要获取的字段名不存在于配置中抛出

        Returns:
            start, len : 字段的起始位置, 字段的长度
        """
        if section_name not in self.data_conf.keys():
            log.info("可用字段为 %s", ','.join(list(self.data_conf.keys())))
            raise AttributeError(f"指定的 {section_name} 不在配置中, 请核对字段名")
        else:
            log.info("配置字段 %s 存在性检查通过, 返回起始位置及偏移开始拆分", section_name)
        start_offset_list = list(self.data_conf.values())
        setction_locate = list(self.data_conf.keys()).index(section_name)
        start_offset = start_offset_list[setction_locate]
        if "partition" in section_name:
            data_len = BLOCK_SIZE
        else:
            data_len = start_offset_list[setction_locate + 1] - start_offset_list[setction_locate]
        return start_offset, data_len

if __name__ == "__main__":
    selftest = IpmcSectionSeperate("user.bin", "config.cfg")
    selftest.run()