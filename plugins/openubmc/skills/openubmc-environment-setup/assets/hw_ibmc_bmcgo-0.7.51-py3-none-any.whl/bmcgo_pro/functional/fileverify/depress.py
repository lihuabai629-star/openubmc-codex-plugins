#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2023-2025. All rights reserved.

"""
文件名: ipmc_section_seperate.py
功能: 拆解 ipmc.bin 包, 取出成分
版权信息: 华为技术有限公司，版本所有(C) 2020-2024
"""
import os
import shutil
import zipfile
import tarfile


class Depress:
    @classmethod
    def unzip(cls, filename: str):
        """ 解压 zip 包

        Args:
            filename (str): 要解压的压缩包的名字

        Returns:
            str: 压缩包同名目录
        """
        file_prefix = filename.rstrip('.zip')
        if os.path.exists(file_prefix):
            shutil.rmtree(file_prefix)
        with zipfile.ZipFile(filename, 'r') as f:
            for name in f.namelist():
                try:
                    fname = name.encode("cp437").decode("utf-8")
                    f.extract(name, file_prefix)
                    os.renames(os.path.join(file_prefix, name), os.path.join(file_prefix, fname))
                except UnicodeEncodeError:
                    f.extract(name, file_prefix)
        return file_prefix

    @classmethod
    def untar(cls, filename: str):
        """ 解压 tar.gz 或 xz 或 bz2 包

        Args:
            filename (str): 要解压的压缩包的名字

        Returns:
            str: 压缩包同名目录
        """
        zipname = os.path.basename(filename).split('.')[0]
        dirname = os.path.dirname(filename)
        file_prefix = os.path.join(dirname, zipname)
        if os.stat(filename).st_size == 0:
            os.remove(filename)
            return file_prefix
        if os.path.exists(file_prefix):
            shutil.rmtree(file_prefix)
        with tarfile.open(filename, 'r:*') as f:
            for member in f.getmembers():
                f.extract(member, file_prefix)
        return file_prefix

    @classmethod
    def depress(cls, filename: str, dir_compatible=False):
        """ 解压压缩包

        Args:
            filename (str): 要解压的压缩包
            dir_compatible (bool, optional): 在默认情况下, 不允许传入目录进行分析

        Raises:
            ValueError: 当传入的不是压缩包报错

        Returns:
            str: 压缩包同名目录
        """
        file_prefix = ""
        try:
            if os.path.isdir(filename) and dir_compatible is False:
                raise ValueError("请传入一个压缩包路径")
            elif os.path.isdir(filename):
                for filepath in os.listdir(filename):
                    cls.depress(os.path.join(filename, filepath), dir_compatible=True)
            else:
                if filename.endswith(".zip"):
                    file_prefix = cls.unzip(filename)
                    cls.depress(file_prefix, dir_compatible=True)
                elif filename.endswith((".tar.gz", ".bz2", ".xz")):
                    file_prefix = cls.untar(filename)
                    cls.depress(file_prefix, dir_compatible=True)
        except Exception as e:
            log.error("递归解压缩包失败, 请检查传入参数与压缩包格式")
            raise e
        return file_prefix


if __name__ == "__main__":
    Depress.depress("aa.zip")
