#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 描述: 提供 json 检查能力
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2023. All rights reserved.
try:
    from bmcgo.functional import json_check
    from bmcgo.misc import CommandInfo

    json_check.CMD = 'bmcgo'
    for attr_name in dir(json_check):
        attr = getattr(json_check, attr_name)
        if attr_name == "command_info":
            attr = CommandInfo(
                group=attr.group,
                name=attr.name,
                description=attr.description,
                hidden=attr.hidden
            )
        globals()[attr_name] = attr

except ImportError:
    from bmcgo_pro.bmcgo_config import BmcgoConfig


    def if_available(bconfig: BmcgoConfig):
        return False

