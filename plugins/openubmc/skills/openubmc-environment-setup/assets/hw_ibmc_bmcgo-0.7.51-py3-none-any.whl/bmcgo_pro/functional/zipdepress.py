#!/usr/bin/env python3
# encoding=utf-8
# 描述：检查两个压缩包之间的差异
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2023. All rights reserved.
import os
import argparse
from bmcgo import misc
from bmcgo_pro.functional.fileverify.depress import Depress
from bmcgo_pro.functional.fileverify.ipmc_section_seperate import IpmcSectionSeperate
from bmcgo_pro.functional.fileverify.ipmc_bin_recovery import proc_ipmc_bin
from bmcgo_pro.logger import Logger
from bmcgo_pro.bmcgo_config import BmcgoConfig

log = Logger()
# NOTE 该命令先隐藏
command_info: misc.CommandInfo = misc.CommandInfo(
    group="Integrated commands",
    name="zipdepress",
    description=["拆解一个压缩包, 并拆解其中的 ipmc.bin 文件"],
    hidden=True
)


def if_available(bconfig: BmcgoConfig):
    if bconfig.manifest is None:
        return False
    if bconfig.partner_mode:
        return False
    return True


class BmcgoCommand:
    def __init__(self, bconfig: BmcgoConfig, *args):
        """ 初始化 zipcheck 功能

        Args:
            bconfig (BmcgoConfig): bmcgo 配置
        """
        self.bconfig = bconfig
        parser = argparse.ArgumentParser(prog="bmcgo zipcheck", description="BMC zip package data check", add_help=True,
                                         formatter_class=argparse.RawTextHelpFormatter)
        parser.add_argument("-m4i", help="指定恢复 ipmc.bin 使用的 m4i 文件(这个路径要zip包下相对路径)", default=None)
        parser.add_argument("--detailedly", help="是否使用新烧片配置", action=misc.STORE_TRUE)
        parser.add_argument("-z", "--zip_name", help="指定要拆包的包名", required=True)
        parsed_args, _ = parser.parse_known_args(*args)
        self.detailedly = parsed_args.detailedly
        self.zip_name = os.path.realpath(parsed_args.zip_name)
        self.m4i_file = parsed_args.m4i
        self.zip_home = self.unzip_dir(self.zip_name)

    @staticmethod
    def unzip_dir(zip_path: str):
        """ 解开压缩包, 参数不允许传入目录名

        Args:
            zip_path (str): zip 包的路径

        Returns:
            str: zip包的释放路径
        """
        depressed_path = Depress.depress(zip_path)
        express_list = os.listdir(depressed_path)
        if len(express_list) == 1 and os.path.isdir(os.path.join(depressed_path, express_list[0])):
            depressed_path = os.path.join(depressed_path, express_list[0])
        log.info("文件释放目录为 %s", depressed_path)
        return depressed_path

    def ipmc_depress(self):
        # 这里将路径规划好, 所有东西放到指定目录 ipmc_divided
        divided_path = "ipmc_divided"

        find_ipmc = False
        for root, _, files in os.walk(self.zip_home):
            for filename in files:
                if filename == "ipmc.bin":
                    find_ipmc = True
                    log.info("恢复 ipmc.bin 文件内部空缺")
                    proc_ipmc_bin(os.path.join(root, self.m4i_file), os.path.join(root, filename), divided_path)
                    log.info("开始拆分 user.bin 文件")
                    # 初始化拆分对象, 拆分全部字段
                    section_sep = IpmcSectionSeperate(os.path.join(root, divided_path, "user.bin"), "", self.detailedly)
                    section_sep.run()
                    log.info("拆分 user.bin 文件结束")
        if find_ipmc is False:
            log.info("此目录没有 ipmc.bin 文件")

    def run(self):
        self.ipmc_depress()