#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 描述：检查两个压缩包之间的差异
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2023. All rights reserved.
import os
import argparse
import re
from string import Template
import yaml

from bmcgo import misc
from bmcgo_pro.functional.fileverify.verify import Verify
from bmcgo_pro.functional.fileverify.depress import Depress
from bmcgo_pro.logger import Logger
from bmcgo_pro.bmcgo_config import BmcgoConfig

IPMCBINCHECK = "ipmcbin"
CMSCHECK = "cms"
CMSTYPELIST = ("pss", "pkcs")
SHA256SUMCHECK = "sha256sum"
CHECKSKIPFILETYPE = (".acxml", ".m4i", "dftimage_v5.hpm", "wbd_verify.hpm")
log = Logger()
# NOTE 该命令先隐藏
command_info: misc.CommandInfo = misc.CommandInfo(
    group="Integrated commands",
    name="zipcheck",
    description=["比较两个打出的 zip 包的差异"],
    hidden=True
)


def if_available(bconfig: BmcgoConfig):
    if bconfig.manifest is None:
        return False
    if bconfig.partner_mode:
        return False
    return True


class BmcgoCommand:
    def __init__(self, bconfig: BmcgoConfig, *args):
        """ 初始化 zipcheck 功能

        Args:
            bconfig (BmcgoConfig): bmcgo 配置
        """
        self.bconfig = bconfig
        parser = argparse.ArgumentParser(prog="bmcgo zipcheck", description="BMC zip package data check", add_help=True,
                                         formatter_class=argparse.RawTextHelpFormatter)
        parser.add_argument("-manifest_yml", help="指定 manifest.yml 指定需要校验的文件的列表", required=True)
        parser.add_argument("-m4i", help="指定恢复 ipmc.bin 使用的 m4i 文件(这个路径要zip包下相对路径)", default=None)
        parser.add_argument("-zb", "--zip_before", help="指定要比较的包的 B 包", required=True)
        parser.add_argument("-za", "--zip_after", help="指定要比较的包的 A 包", required=True)
        parser.add_argument("-zc", "--zip_code", help="需要比较的 zip 包编码", required=False)
        parsed_args, _ = parser.parse_known_args(*args)
        self.zip_before = os.path.realpath(parsed_args.zip_before)
        self.zip_after = os.path.realpath(parsed_args.zip_after)
        self.zip_code = parsed_args.zip_code
        self.manifest_file = os.path.realpath(parsed_args.manifest_yml)
        self.m4i_file = parsed_args.m4i
        self.zip_before_home = self.unzip_dir(self.zip_before)
        self.zip_after_home = self.unzip_dir(self.zip_after)
        self.template = {
            "board_name": self.manifest_file.split("/")[-2],
            "doc_file": "Open Source Software Notice.docx"
        }

    @staticmethod
    def unzip_dir(zip_path: str):
        """ 解开压缩包, 参数不允许传入目录名

        Args:
            zip_path (str): zip 包的路径

        Returns:
            str: zip包的释放路径
        """
        depressed_path = Depress.depress(zip_path)
        express_list = os.listdir(depressed_path)
        if len(express_list) == 1 and os.path.isdir(os.path.join(depressed_path, express_list[0])):
            depressed_path = os.path.join(depressed_path, express_list[0])
        log.info("文件释放目录为 %s", depressed_path)
        return depressed_path

    @staticmethod
    def comporessed_package_check(filename: str, before_file_path: str, after_file_path: str):
        """ 是否压缩包触发不同检查

        Args:
            filename (str): 要检查的文件名
            before_file_path (str): 第 1 个文件的路径
            after_file_path (str): 第 2 个文件的路径
        """
        verify = Verify()
        if filename.endswith((".gz", ".xz", ".bz2")):
            # 如果是压缩包, 校验压缩包下所有文件 sha256sum
            dirname = os.path.basename(filename).split(".")[0]
            work_path = os.getcwd()
            os.chdir(os.path.dirname(before_file_path))
            log.info("comporessed_package_check: 压缩包解包路径名 %s", dirname)
            for root, _, files in os.walk(dirname):
                for f in files:
                    log.info("开始校验文件 %s", f)
                    verify.verify(SHA256SUMCHECK, os.path.join(before_file_path.rsplit('/', 1)[0], root, f),
                                  os.path.join(after_file_path.rsplit('/', 1)[0], root, f))
            os.chdir(work_path)
            os.remove(before_file_path)
            os.remove(after_file_path)
        else:
            log.info("comporessed_package_check: 文件名 %s", filename)
            verify.verify(SHA256SUMCHECK, before_file_path, after_file_path)

    def check_option_run(self, filename: str, before_file_path: str, after_file_path: str, check_option=None):
        """ 检查校验项并调用校验接口

        Args:
            filename (str): 需要校验的文件名称
            before_file_path (str): 第一构建的文件结果路径
            after_file_path (str): 第二构建的文件结果路径
            check_option (_type_, optional): 校验项, 默认为空

        Raises:
            ValueError: 如果 m4i_file 文件名没有赋值抛出
            e: 其它异常正常抛出
        """
        if filename.endswith("ipmc.bin") and self.m4i_file is None:
            raise ValueError("在存在 ipmc.bin 文件时, 选项必须指定 m4i 文件")
        # 初始化 verify 类, 调用其中校验功能
        verify = Verify()
        log_option = None
        try:
            if check_option is not None:
                log_option = check_option
                # 调用 verify 接口, 接收到异常打印异常日志, 统计异常
                if check_option == IPMCBINCHECK:
                    verify.verify(check_option, self.m4i_file, before_file_path, after_file_path)
                elif check_option == SHA256SUMCHECK:
                    self.comporessed_package_check(filename, before_file_path, after_file_path)
                elif check_option in CMSTYPELIST:
                    verify.verify(CMSCHECK, check_option, before_file_path, after_file_path)
                else:
                    verify.verify(check_option, before_file_path, after_file_path)
            else:
                log_option = SHA256SUMCHECK
                self.comporessed_package_check(filename, before_file_path, after_file_path)
        except Exception as e:
            log.error("%s ERROR: 文件 %s 校验 %s 失败", self.zip_code, filename, log_option)
            raise e

    def check(self, checkfile: dict):
        """ 校验配置文件是否相同

        Args:
            checkfile (dict): manifest 中配置的文件

        Raises:
            ValueError: 传参错误时抛出
        """
        # 获取需要校验的文件名, 并将校验的路径路径统一
        filename = self.__get_file_name(checkfile)
        if filename.endswith(CHECKSKIPFILETYPE):
            return
        before_file_path = os.path.join(self.zip_before_home, filename)
        after_file_path = os.path.join(self.zip_after_home, filename)
        # 获取到所有的校验项
        check_options = checkfile.get("verify", None)
        try:
            if check_options is not None:
                if check_options[0] == "skip":
                    return
                for check_option in check_options:
                    self.check_option_run(filename, before_file_path, after_file_path, check_option)
            else:
                self.check_option_run(filename, before_file_path, after_file_path)
        except Exception as e:
            log.error("文件 manifest.yml 配置为: %s", checkfile.get("file"))
            # NOTE 调试时此语句后面可以抛出异常, 用来快速定位问题

    def run(self):
        """ 执行校验动作
        """
        verify = Verify()
        verify.verify("dir_files", self.zip_before_home, self.zip_after_home)
        if self.zip_code:
            checklist = self.__get_check_data(f"manufacture/{self.zip_code}/files")
        else:
            tosupporte = self.__get_check_data("tosupporte")
            zip_package_name = os.path.basename(self.zip_before)
            pattern = re.compile(r"\$\{\w+\}")
            for item in tosupporte:
                package_name = os.path.basename(tosupporte.get(item).get('package_name'))
                package_name = str(Template(package_name).safe_substitute(self.template)) 
                package_name = pattern.sub(".*", package_name)
                if re.findall(package_name, zip_package_name):
                    self.zip_code = item
                    break
            checklist = self.__get_check_data(f"tosupporte/{self.zip_code}/files") 
        if checklist is None:
            raise AttributeError(f"输入的压缩包编码 {self.zip_code} 不在 manufacture 配置中")

        # 逐个校验
        for checkfile in checklist:
            self.check(checkfile)

    def __get_check_data(self, key: str):
        """ 获取到校验包的文件配置

        Args:
            key (str): 使用"a/b/c"形式可逐级取值, 无值则返回 None

        Returns:
            _type_: 返回值为键的值
        """
        with open(self.manifest_file, mode="r") as fp:
            manifest_conf = yaml.safe_load(fp)
        value = manifest_conf
        for sub_key in key.split("/"):
            value = value.get(sub_key, None)
            if value is None:
                return value
        return value

    def __get_file_name(self, file_cfg: dict):
        """ 从 file 字段中读取数据

        Args:
            file_cfg (dict): 从 files 字段的配置里面读取的 file 配置

        Raises:
            AttributeError: 配置中必须有 file 字段, 否则抛出此异常

        Returns:
            str: 在压缩包中的具体位置
        """
        dst_path = file_cfg.get("dst", None)
        if dst_path is None:
            dst_path = file_cfg.get("file")
            if dst_path is not None:
                dst_path = os.path.basename(dst_path)
            else:
                raise AttributeError("参数 manifest.yml 文件配置错误, 请检查配置")
        re_str = str(Template(dst_path).safe_substitute(self.template))
        pattern = re.compile(r"\$\{\w+\}")
        re_str = pattern.sub(".*", re_str) 
        # 如果替换后没有变化, 那么直接返回, 否则执行后面的代码
        if re_str == dst_path:
            return dst_path

        # 保存工作目录
        work_path = os.getcwd()
        os.chdir(self.zip_before_home)
        # 暂存 dst_path 变量
        dst_path_temp = ""
        # 最大匹配次数不能超过 1, 超过 1 视为无法识别
        match_time = 0
        for root, _, files in os.walk("."):
            for filename in files:
                matchlist = re.findall(re_str, os.path.join(root, filename))
                # 如果匹配到, 则开始给其赋值
                if len(matchlist) > 0:
                    match_time = match_time + 1
                    dst_path_temp = re.sub("^./", "", matchlist[0])
        if dst_path_temp == "" or match_time > 1:
            raise ValueError(f"无法识别到文件: {dst_path}, 匹配到次数: {match_time}")
        dst_path = dst_path_temp
        os.chdir(work_path)
        # 如果有 dst 配置, 那么 dst 作为文件名, 且保留路径, 没有 dst, 只取名字
        return dst_path


if __name__ == "__main__":
    pass