#!/usr/bin/env python3
# encoding=utf-8
# 描述：支持自动修改xml文件中依赖的hash值
# Copyright (c) Huawei Technologies Co., Ltd. 2024. All rights reserved.
import sys
import argparse
import tempfile

from bmcgo.misc import CommandInfo
from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.bmcgo_config import BmcgoConfig
from bmcgo_pro.utils.artget_tools import ArtgetDownloadTool

tool = Tools("artget")
log = tool.log
command_info: CommandInfo = CommandInfo(
    group="Misc commands",
    name="artget",
    description=["artget下载xml文件中的依赖，同时支持自动更新xml文件中的依赖hash值"],
    hidden=True,
)


def if_available(bconfig: BmcgoConfig):
    if bconfig.partner_mode:
        return False
    if bconfig.conan_index:
        return False
    return True


class BmcgoCommand:
    def __init__(self, bconfig: BmcgoConfig, *args):
        self.bconfig = bconfig
        parser = argparse.ArgumentParser(
            description="下载xml文件定义的依赖，并支持自动更新依赖文件hash值", 
            formatter_class=argparse.RawTextHelpFormatter
        )
        parser.add_argument("-f", "--xml_path", help="依赖定义的xml文件路径", required=True)
        parser.add_argument("-d", "--download_dir", help="下载依赖的存放路径，默认为临时路径", default=None)
        parser.add_argument("-u", "--update_hashes", help="是否自动修改下载文件的hash值，默认为False", default=False)
        parsed_args, _ = parser.parse_known_args(*args)
        self.xml_path = parsed_args.xml_path
        self.download_dir = parsed_args.download_dir
        self.update_hashes = parsed_args.update_hashes

    def run(self):
        prompt = "此命令仅支持下载并校验xml中定义的依赖 或 下载并自动更新xml文件中依赖的hash值，请确定您是否已更新xml文件中的offering和version等信息,请输入[y/n]："
        is_verify = input(prompt).strip().lower()
        if is_verify != "y":
            log.info("bmcgo artget命令已取消")
        else:
            if self.download_dir is None:
                log.info("因未指定存放路径，依赖文件将会下载到缓存目录并在命令执行完成后自动删除。")
                tmp_dir = tempfile.TemporaryDirectory()
                self.download_dir = tmp_dir.name
            artget_download = ArtgetDownloadTool(self.xml_path, self.download_dir, self.update_hashes)
            artget_download.download()
