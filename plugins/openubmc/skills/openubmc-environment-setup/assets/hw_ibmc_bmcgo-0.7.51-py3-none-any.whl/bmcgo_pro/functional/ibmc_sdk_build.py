#!/usr/bin/env python3
# encoding=utf-8
# 描述：构建平台包
# Copyright (c) Huawei Technologies Co., Ltd. 2024. All rights reserved.
import os
import argparse
import json

import yaml
from bmcgo import errors

from bmcgo import misc
from bmcgo.misc import CommandInfo
from bmcgo.functional.schema_valid import BmcgoCommand as SchemaValid
from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.bmcgo_config import BmcgoConfig

tool = Tools("ibmc_sdk")
log = tool.log
command_info: CommandInfo = CommandInfo(
    group=misc.GRP_IBMC_SDK, name="build", description=["构建ibmc sdk"], hidden=False
)
STAGE_LIST = ("dev", "rc", "stable")


def if_available(bconfig: BmcgoConfig):
    return bconfig.ibmc_sdk is not None


class BmcgoCommand:
    def __init__(self, bconfig: BmcgoConfig, *args):
        self.bconfig = bconfig
        parser = argparse.ArgumentParser(
            prog="bmcgo build_platform",
            description="构建平台conan包",
            add_help=True,
            formatter_class=argparse.RawTextHelpFormatter,
        )
        parser.add_argument(
            "--stage",
            help=f"平台包发布阶段, 可选: {', '.join(STAGE_LIST)}\n默认：dev",
            choices=STAGE_LIST,
            default="stable",
        )
        parser.add_argument(
            "-r",
            "--remote",
            default=misc.conan_remote(),
            help="conan远程仓，请检查conan remote list查看已配置的conan仓",
        )
        parser.add_argument(
            "-u", "--upload", action=misc.STORE_TRUE, help="上传组件包到conan仓"
        )
        parser.add_argument("--rtos_version", help="构建类型, 选择构建某个rtos")
        parsed_args, _ = parser.parse_known_args(*args)
        self.stage = parsed_args.stage
        self.remote = parsed_args.remote
        self.upload = parsed_args.upload
        self.rtos_version = parsed_args.rtos_version
        self.build_dir = self.bconfig.ibmc_sdk.folder
        self.version = ""
        self.channel = self.stage
        if self.stage == "dev":
            # 开发者测试模式
            self.user = misc.conan_user_dev()
        else:
            self.user = misc.conan_user()

    def run(self):
        os.chdir(self.build_dir)

        log.info("Start build package")
        build_options = []
        if self.rtos_version:
            build_options = [self.rtos_version]
        else:
            build_options = os.listdir(self.build_dir)
        for rtos_version in build_options:
            if rtos_version != "subsys" and os.path.isdir(rtos_version):
                config_path = os.path.join(self.build_dir, rtos_version, "manifest.yml")
                if not SchemaValid.schema_valid(config_path):
                    raise errors.BmcGoException(f"schema校验文件{config_path}失败")
                with open(config_path, "r") as yaml_fp:
                    obj = yaml.safe_load(yaml_fp)
                self.version = obj["base"]["version"]
                if misc.conan_v2():
                    self.version = self.version.lower()
                pkg = "ibmc_sdk" + "/" + self.version + "@" + self.user + "/" + self.channel
                if misc.conan_v1():
                    cmd = f"conan create . {pkg} --build -r {self.remote} -o rtos_version={rtos_version}"
                else:
                    cmd = f"conan create . --version={self.version} --build=* --user={self.user} \
                            --channel={self.channel} -o &:rtos_version={rtos_version}"
                tool.run_command(cmd, show_log=True)
                if obj.get("haf_dependencies"):
                    if misc.conan_v1():
                        cmd += f" -o enable_haf=False"
                    else:
                        cmd += f" -o &:enable_haf=False"
                    tool.run_command(cmd, show_log=True)
                self._upload_package(pkg, rtos_version)
        return 0

    def _upload_package(self, pkg, v):
        if not self.upload:
            return
        cmd = [misc.CONAN, "upload"]
        cmd += ("%s -r %s --all" % (pkg, self.remote)).split()
        tool.run_command(cmd, show_log=True)
