#!/usr/bin/env python3
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.

import os
import re
import argparse

import yaml

from bmcgo import misc
from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.bmcgo_config import BmcgoConfig

command_info: misc.CommandInfo = misc.CommandInfo(
    group=misc.GRP_MISC,
    name="make_emmc_image",
    description=["解析emmc配置文件，创建分区"],
    hidden=True,
)

EXTENDED_PARTITION_TYPE = 5
LINUX_SWAP_PARTITION_TYPE = 83


def if_available(bconfig: BmcgoConfig):
    return True


class Partition():
    def __init__(self, name, cfg):
        self.name = name
        self.start = cfg.get("start")
        self.end = cfg.get("end")
        self.type = cfg.get("type")
        if self.type != "extended":
            self.partition_type = cfg.get("partition_type", str(LINUX_SWAP_PARTITION_TYPE))
        else:
            self.partition_type = str(EXTENDED_PARTITION_TYPE)
        self.file = cfg.get("file", None)
        self.verified = False
        match = re.search("([0-9]+)$", self.name)
        if match is None:
            raise Exception(f"Partition {name} with name error, " +
                            f"must endswith number")
        self.number = int(match.group(0))
        if self.start >= self.end:
            raise Exception(f"Partition {self.name} with lba error, " +
                            f"startLBA {self.start} bigger or equal to endLBA {self.end}")
        if self.file:
            file_size = os.path.getsize(self.file)
            part_size = (self.end - self.start + 1) * 512
            if part_size < file_size:
                raise Exception(f"Partition {self.name} too small, " +
                            f"the size of {self.file} is {file_size}Bytes, bigger than {part_size}Bytes")

    def create(self):
        if self.type == "primary":
            return ("n\np\n" +
                    str(self.number) + "\n" +
                    str(self.start) + "\n" +
                    str(self.end) + "\n")
        elif self.type == "extended":
            return ("n\ne\n" +
                    str(self.number) + "\n" +
                    str(self.start) + "\n" +
                    str(self.end) + "\n")
        elif self.type == "logical":
            return ("n\n" +
                    str(self.start) + "\n" +
                    str(self.end) + "\n")
        else:
            raise Exception("Unkown type {self.type} get, only primary、extended、logical supported")

    def set_partition(self):
        return f"t\n{self.number}\n{self.partition_type}\n"

    def verify(self, chunks):
        # 第2个是开始LBA
        if str(self.start) != chunks[1]:
            raise Exception(f"Partiton {self.name} with StartLBA error, " +
                            f"get {chunks[1]}, need {self.start}")
        # 第2个是结束LBA
        if str(self.end) != chunks[2]:
            raise Exception(f"Partiton {self.name} with EndLBA error, " +
                            f"get {chunks[2]}, need {self.end}")
        # 第5个是Id，表示分区类型
        if self.partition_type != chunks[5]:
            raise Exception(f"Partiton {self.name} with Id error, " +
                            f"get {chunks[5]}, need {self.partition_type}")


class BmcgoCommand():
    def __init__(self, bconfig: BmcgoConfig, *args):
        self.bconfig = bconfig
        self.tools = Tools()
        self.log = self.tools.log
        self.partitions: dict[str, Partition] = {}
        parser = argparse.ArgumentParser(prog="make_emmc_img", description="Make emmc image", add_help=True,
                                            formatter_class=argparse.RawTextHelpFormatter)
        parser.add_argument("-conf", "--config_file", help="config file", required=True)
        parser.add_argument("-o", "--output", help="output image", required=True)
        args = parser.parse_args(*args)
        self.config = args.config_file
        self.output = args.output
        if not os.path.isfile(self.config):
            raise FileNotFoundError(f"file {self.config} not found")

    def run(self):
        with open(self.config, "r") as yaml_fp:
            config = yaml.safe_load(yaml_fp)
        p_cfgs = config.get("partitions", {})
        for name, cfg in p_cfgs.items():
            partition = Partition(name, cfg)
            self.partitions[partition.number] = partition
        self._create()
        self._fill_content()
        self._verify()

    def _create(self):
        seek = 0
        for _, partition in self.partitions.items():
            if partition.end > seek:
                seek = partition.end
        if os.path.isfile(self.output):
            os.unlink(self.output)
        # dd的块大小512字节
        bs = 512
        dd_cmd = f"dd if=/dev/zero of={self.output} bs={bs} count=1 seek={seek}"
        self.tools.run_command(dd_cmd)
        for _, partition in self.partitions.items():
            fdisk_cmd = partition.create()
            self.log.info(f">>>>>>>>>>>>>>>  Add new partition {partition.name} <<<<<<<<<<<<<<<<<<<<")
            self.tools.pipe_command([f"echo \"{fdisk_cmd}w\n\"", f"fdisk {self.output}"])

        for _, partition in self.partitions.items():
            fdisk_cmd = partition.set_partition()
            self.log.info(f">>>>>>>>>>>>>>>  Change partition type {partition.name} <<<<<<<<<<<<<<<<<<<<")
            self.tools.pipe_command([f"echo \"{fdisk_cmd}w\n\"", f"fdisk {self.output}"])

    def _fill_content(self):
        for _, partition in self.partitions.items():
            if not partition.file:
                continue
            self.log.info(f"Start write {partition.file}")
            if not os.path.isfile(partition.file):
                raise FileNotFoundError(f"Partition file {partition.file} not found")
            # dd的块大小512字节
            bs = 512
            seek = partition.start
            # dd的最大块大小设置为65536字节（64KB）
            while bs < 65536 and seek >= 2:
                if (seek & 1) == 0:
                    bs *= 2
                    seek = seek >> 1
                else:
                    break
            cmd = f"dd if={partition.file} of={self.output} bs={bs} seek={seek} conv=notrunc"
            self.tools.run_command(cmd)

    def _verify(self):
        output, ret = self.tools.pipe_command(
            [f"fdisk -l {self.output}", f'grep "^{self.output}"'], capture_output=True
        )
        if ret != 0:
            raise Exception(f"Check {self.output} partitions failed")
        for line in output.split("\n"):
            line = line.strip()
            if not line:
                continue
            chunks = line.split()
            match = re.search("([0-9]+)$", chunks[0])
            if match is None:
                raise Exception(f"Partition {chunks[0]} with name error, " +
                                f"must endswith number")
            number = int(match.group(0))
            partition = self.partitions.get(number)
            if not partition:
                raise Exception(f"Unkown partition get, number: {number}")
            self.log.info(f"Check partition {partition.name}")
            self.log.info(">>>> " + line)
            partition.verify(chunks)


if __name__ == "__main__":
    bc = BmcgoConfig()
    img = BmcgoCommand(bc)
    img.run()
