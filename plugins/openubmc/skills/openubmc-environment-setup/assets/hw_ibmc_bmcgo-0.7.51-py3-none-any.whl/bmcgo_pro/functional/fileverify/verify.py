#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2023-2025. All rights reserved.

"""
文件名: verify.py
功能: 提供各种校验功能
版权信息: 华为技术有限公司，版本所有(C) 2020-2024
"""
import os
import hashlib
import subprocess
import time
from bmcgo_pro.logger import Logger
from bmcgo_pro.utils.tools import Tools
from .hpm_extract import HpmExtract
from .ipmc_section_seperate import IpmcSectionSeperate
from .ipmc_bin_recovery import proc_ipmc_bin

tools = Tools("bmcgo_config")
log = Logger()
SUDO = "sudo"
MOUNT = "mount"
UMOUNT = "umount"
MKNOD = "mknod"
SELECTIONT = "-t"
SELECTIONM = "-m"
SELECTIONO = "-o"
TYPE = "ext4"
FILETYPE = "b"
FILESYSTEMTYPE = "ext4"
LOOPTYPE = "7"
PERM = "0660"
TAR = "/usr/bin/tar"
TARSELECTION = "-zcf"
CURPATH = "."
CMSVERIFYFUNC = "cms_verify"
WGET = "wget"
WGETRETRYCONFUSE = "--retry-connrefused"
WGETRETRY = "--waitretry=1"
WGETTIMESEL = "-t"
WGETTIMES = "3"
WGETOUTPUTSEL = "-O"


class Verify:
    @classmethod
    def export_tar_gz(cls, img_path: str, mount_path: str):
        """ 挂载镜像到目录

        Args:
            img_path (str): 镜像路径
            mount_path (str): 挂载路径

        Raises:
            e: 发生任意挂载问题时抛出
        """
        work_path = os.getcwd()
        log.info(f"挂载 datafs, 目标目录: {mount_path}, 镜像文件: {img_path}")
        os.makedirs(mount_path, exist_ok=True)
        tools.run_command(f"{UMOUNT} {mount_path}", ignore_error=True, sudo=True)
        # 直接挂载，挂载成功则直接退出
        ret = tools.run_command(f"{MOUNT} {SELECTIONT} {TYPE} {img_path} {mount_path}", ignore_error=True, sudo=True)
        if ret and ret.returncode == 0:
            pass
        else:
            # 挂载设备进行16次尝试
            for attempt_times in range(0, 64):
                loop_id = attempt_times % 16
                tools.run_command(f"{MKNOD} {SELECTIONM} {PERM} /dev/loop{loop_id} {FILETYPE} {LOOPTYPE} {loop_id}", 
                                  ignore_error=True, sudo=True)
                ret = tools.run_command(f"{MOUNT} {SELECTIONO} loop=/dev/loop{loop_id} {SELECTIONT}" + 
                                        f" {FILESYSTEMTYPE} {img_path} {mount_path}", ignore_error=True, sudo=True)
                if ret is None or ret.returncode != 0:
                    # 创建设备，允许不成功，其他进程可能创建过相同的设备
                    self.log.info(f"挂载 {img_path} 失败, 尝试第 {loop_id} 次, 返回值为: {ret}")
                else:
                    # 挂载成功退出
                    break
                time.sleep(10)
            else:
                # 16次均失败，报错退出
                tools.run_command(f"umount {mount_path}", ignore_error=True, sudo=True)
                raise errors.BmcGoException(f"挂载 {img_path} 失败, 请使用 df -hl 检查设备是否被占用")
        log.info("挂载 %s 成功", img_path)
        os.chdir(work_path)
        tools.run_command(f"umount {mount_path}", ignore_error=True, sudo=True)

    @classmethod
    def sha256sum(cls, file_a: str, file_b: str):
        """ 计算两个文件的 sha256sum 并对比

        Args:
            file_a (str): 文件A的路径
            file_b (str): 文件B的路径

        Raises:
            e: 计算 sha256sum 时发生的任意错误
            ValueError: 两个计算值不一样是抛出
        """
        try:
            with open(file_a, mode="rb") as fp:
                sha256sum_a = hashlib.sha256(fp.read()).hexdigest()
            with open(file_b, mode="rb") as fp:
                sha256sum_b = hashlib.sha256(fp.read()).hexdigest()
        except Exception as e:
            raise e
        if sha256sum_a != sha256sum_b:
            raise ValueError(f"校验 sha256sum 失败: {file_a}:{sha256sum_a} - {file_b}:{sha256sum_b}")
        else:
            log.info("校验 sha256sum 成功: %s: %s - %s: %s", file_a, file_b, sha256sum_a, sha256sum_b)

    @classmethod
    def dir_files(cls, dir_a: str, dir_b: str):
        """ 检查两个文件目录结构是否一致

        Args:
            dir_a (str): 目录A
            dir_b (str): 目录B

        Raises:
            ValueError: 任一目录结构不同时抛出
            e: 任一目录结构不同时抛出
        """
        log.info("开始校验目录树: %s - %s", dir_a, dir_b)
        file_list_a, file_list_b, dir_list_a, dir_list_b = [], [], [], []
        for _, dirs, files in os.walk(dir_a):
            dir_list_a, file_list_a = dirs, files

        for _, dirs, files in os.walk(dir_b):
            dir_list_b, file_list_b = dirs, files

        sorted(dir_list_a)
        sorted(file_list_a)
        sorted(dir_list_b)
        sorted(file_list_b)

        try:
            for i, _ in enumerate(dir_list_a):
                if dir_list_a[i] != dir_list_b[i]:
                    raise ValueError(f"校验两目录文件树失败: {dir_a} - {dir_b}")
            for i, _ in enumerate(file_list_a):
                if file_list_a[i] != file_list_b[i]:
                    raise ValueError(f"校验两目录文件树失败: {dir_a} - {dir_b}")
            log.info("校验两目录树成功: %s - %s", dir_a, dir_b)
        except ValueError as e:
            log.error("目录树A目录: %s", dir_list_a)
            log.error("目录树B目录: %s", dir_list_b)
            log.error("目录树A文件: %s", file_list_a)
            log.error("目录树B文件: %s", file_list_b)
            raise e

    @classmethod
    def size(cls, file_a: str, file_b: str):
        """ 比较两个文件大小

        Args:
            file_a (str): A文件路径
            file_b (str): B文件路径

        Raises:
            ValueError: 文件大小不同时抛出
        """
        file_a_size = os.stat(file_a).st_size
        file_b_size = os.stat(file_b).st_size
        if file_a_size != file_b_size:
            raise ValueError(f"校验两文件大小失败: {file_a}:{file_a_size} - {file_b}:{file_b_size}")
        else:
            log.info("校验两文件大小成功: %s - %s", file_a, file_b)

    @classmethod
    def sp_ibma_check(cls, fs_file_before: str, fs_file_after: str):
        """ sp 和 ibma 检查

        Args:
            fs_file_before (str): 第一次构建结果路径
            fs_file_after (str): 第二次构建结果的路径

        Raises:
            ValueError: 两个文件的大小的值不一致
            Exception: 挂载失败时抛出异常
        """
        try:
            cls.sha256sum(fs_file_before, fs_file_before)
            log.info(f"{fs_file_before} 与 {fs_file_after} 两文件 sha256sum 一致")
            return
        except ValueError:
            log.info(f"{fs_file_before} 与 {fs_file_after} 两文件不一致, 尝试挂载文件系统")

        file_a_size = os.stat(fs_file_before).st_size
        file_b_size = os.stat(fs_file_after).st_size
        if file_a_size != file_b_size:
            raise ValueError(f"校验两文件系统大小失败: {fs_file_before}:{file_a_size} - {fs_file_after}:{file_b_size}")
        # 这两个文件尝试挂载, 这里只测试 iBMA.bin 文件, sp.bin 文件在sha256部分会校验通过
        mount_path = "mount_bin"
        os.makedirs(mount_path, exist_ok=True)
        for filename in (fs_file_before, fs_file_after):
            cmd = [SUDO, MOUNT, filename, mount_path]
            umount_cmd = [SUDO, UMOUNT, mount_path]
            try:
                subprocess.run(cmd, check=True)
                subprocess.run(umount_cmd)
            except Exception as e:
                log.error(f"文件 {filename} 挂载失败, 请确认其正确性")
                subprocess.run(umount_cmd)
                raise e

    @classmethod
    def cms(cls, sign_type: str, hpmname_before: str, hpmname_after: str):
        """ 校验两个 hpm 包的签名

        Args:
            hpmname_before (str): 第 1 个 hpm 包路径
            hpmname_after (str): 第 2 个 hpm 包路径

        Raises:
            e: 两个包签名类型不同时抛出
        """
        # cms 检验头, 两个 der 下载, 一个可以就通过, 但要保证两边是一样的
        log.info("校验文件名为: %s", os.path.basename(hpmname_before))
        ca_store = os.path.join(os.path.dirname(hpmname_before), "ca_store")
        os.makedirs(ca_store, exist_ok=True)
        if sign_type == "pkcs":
            rootca_url = "https://download.huawei.com/dl/"\
                "download.do?actionFlag=download&nid=PKI1000000015&partNo=3001&mid=SUP_PKI"
            ca_file = os.path.join(ca_store, "pkcs_ca.der")
        elif sign_type == "pss":
            rootca_url = "https://download.huawei.com/dl/"\
                    "download.do?actionFlag=download&nid=PKI1100000070&partNo=3001&mid=SUP_PKI"
            ca_file = os.path.join(ca_store, "pss_ca_g2.der")
        else:
            raise AttributeError(f"配置的签名类型不在已知范围内: {sign_type}")
        cmd = [
            WGET, WGETRETRYCONFUSE, WGETRETRY, WGETTIMESEL, WGETTIMES, WGETOUTPUTSEL, ca_file, rootca_url
        ]
        subprocess.run(cmd, check=True)
        log.info("校验签名方式为 %s", os.path.basename(ca_file).split("_")[0])
        try:
            hpm_before = HpmExtract(hpmname_before, ca_file)
            hpm_before.get_field(CMSVERIFYFUNC)
        except subprocess.CalledProcessError as e:
            log.error("%s: 签名校验失败, 请确认签名方式是 PSS 还是 PKCS", hpmname_before)
            raise e

        try:
            hpm_after = HpmExtract(hpmname_after, ca_file)
            hpm_after.get_field(CMSVERIFYFUNC)
        except subprocess.CalledProcessError as e:
            log.error("%s: 签名校验失败, 请确认签名方式是 PSS 还是 PKCS", hpmname_after)
            raise e

    @classmethod
    def ipmcbin(cls, m4i_file_name: str, ipmcbin_before: str, ipmcbin_after: str):
        """ 校验两个 ipmc.bin 包差异

        Args:
            m4i_file_name (str): 拆分 ipmc.bin 文件的 m4i 依赖文件
            ipmcbin_before (str): 第 1 个 ipmc.bin 包
            ipmcbin_after (str):  第 2 个 ipmc.bin 包

        Raises:
            Exception: 发生任意错误时, 将集中抛出问题
        """
        # 这里将路径规划好, 所有东西放到指定目录 ipmc_divided
        divided_path = "ipmc_divided"
        ipmcbin_before_dir = os.path.dirname(ipmcbin_before)
        ipmcbin_after_dir = os.path.dirname(ipmcbin_after)
        m4i_file_before = os.path.join(ipmcbin_before_dir, m4i_file_name)
        m4i_file_after = os.path.join(ipmcbin_after_dir, m4i_file_name)
        user_bin_before_dir = os.path.join(ipmcbin_before_dir, divided_path)
        user_bin_after_dir = os.path.join(ipmcbin_after_dir, divided_path)

        log.info("恢复 ipmc.bin 文件内部空缺")
        proc_ipmc_bin(m4i_file_before, ipmcbin_before, divided_path)
        proc_ipmc_bin(m4i_file_after, ipmcbin_after, divided_path)
        cls.sha256sum(os.path.join(user_bin_before_dir, "boot1.bin"), os.path.join(user_bin_after_dir, "boot1.bin"))
        cls.sha256sum(os.path.join(user_bin_before_dir, "boot2.bin"), os.path.join(user_bin_after_dir, "boot2.bin"))

        # 初始化拆分对象, 拆分全部字段
        log.info("开始拆分 user.bin 文件")
        section_sep_before = IpmcSectionSeperate(os.path.join(user_bin_before_dir, "user.bin"))
        section_sep_after = IpmcSectionSeperate(os.path.join(user_bin_after_dir, "user.bin"))
        section_sep_before.run()
        section_sep_after.run()
        log.info("拆分 user.bin 文件结束")

        log.info("开始核对两目录文件")
        cls.dir_files(section_sep_before.output_path, section_sep_after.output_path)
        # 对比除 img 外所有 sha256sum 值
        dir_file_list = sorted(os.listdir(section_sep_before.output_path))
        exceptions = []
        for partition in dir_file_list:
            try:
                log.info("当前校验 user.bin 字段为 %s", partition)
                before_partition = os.path.join(section_sep_before.output_path, partition)
                after_partition = os.path.join(section_sep_after.output_path, partition)
                if os.path.isdir(before_partition) or os.path.isdir(after_partition):
                    # 这个目录下没有目录文件, 只有一个 data 作为挂载使用, 如果 partition 为目录直接跳过
                    continue
                if partition.endswith(".img"):
                    mount_path_temp = os.path.join(section_sep_before.output_path, "data")
                    cls.export_tar_gz(before_partition, mount_path_temp)

                    mount_path_temp = os.path.join(section_sep_after.output_path, "data")
                    cls.export_tar_gz(after_partition, mount_path_temp)
                else:
                    cls.sp_ibma_check(before_partition, after_partition)
                log.info("ipmc.bin %s 校验成功", partition)
            except Exception as e:
                exceptions.append(e)
                log.error("ipmc.bin %s 校验失败", partition)
        if exceptions:
            raise Exception("发生了多个异常: {}".format(exceptions))

    def verify(self, filed_name: str, *args, **kwargs):
        """ 调用校验方法

        Args:
            filed_name (str): 校验字段名

        Raises:
            AttributeError: 当传入的字段名不支持时抛出
            TypeError: 当传入的参数有问题时抛出

        Returns:
            _type_: 字段对应发放的返回值, 类型由字段决定
        """
        try:
            func = getattr(self, filed_name)
            data = func(*args, **kwargs)
            return data
        except AttributeError as e:
            custom_functions = \
                [func for func in dir(self) if callable(getattr(self, func)) and not func.startswith("__")]
            log.info(f"请检查属性输入是否正确, 可用属性为 {custom_functions}")
            raise e
        except TypeError as e:
            help(func)
            raise e