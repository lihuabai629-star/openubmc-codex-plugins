#!/usr/bin/env python3
# encoding=utf-8
# 描述：组件的版本号间的merge记录或者manifest的commit之间的merge记录
# Copyright (c) Huawei Technologies Co., Ltd. 2024. All rights reserved.
import os
import re
import argparse
import tempfile
import time
from datetime import datetime
from typing import List

import yaml
from git import Repo
from bmcgo.errors import NotFoundException

from bmcgo import misc
from bmcgo_pro.bmcgo_config import BmcgoConfig
from bmcgo_pro.utils.tools import Tools

command_info: misc.CommandInfo = misc.CommandInfo(
    group=misc.GRP_MISC,
    name="dt_analysis",
    description=["解析DT执行结果, 并根据community仓配置进行失败结果屏蔽。"],
    hidden=True,
)


def if_available(bconfig: BmcgoConfig):
    if bconfig.partner_mode:
        return False
    return True


_COMMNUITY_REPO = "https://codehub-dg-y.huawei.com/iBMC_V3/community.git"
_UT = "ut"
_IT = "it"
_DATE_FORMAT = "%Y/%m/%d"


class BmcgoCommand:
    def __init__(self, bconfig: BmcgoConfig, *args):
        self.bconfig = bconfig
        self.tools = Tools()
        self.log = self.tools.log
        parser = argparse.ArgumentParser(
            prog="bmcgo dt_analysis",
            description="BMC component dt result analysis",
            add_help=True,
            formatter_class=argparse.RawTextHelpFormatter,
        )
        parser.add_argument("--component", "-comp", help="需要分析的组件名", required=True)
        parser.add_argument("--test_type", "-t", help="指定需要分析的dt测试类型", choices=[_UT, _IT], required=True)
        parser.add_argument("--result", "-r", help="指定需要分析的dt执行结果文件", required=True)
        parser.add_argument("--commnuity_repo", "-repo", help="指定存放配置文件的代码仓", default=_COMMNUITY_REPO)

        parsed_args, _ = parser.parse_known_args(*args)
        self.component = parsed_args.component
        self.test_type = parsed_args.test_type
        self.result = parsed_args.result
        self.commnuity_repo = parsed_args.commnuity_repo
        if not os.path.isfile(self.result):
            raise NotFoundException(f"{self.result}文件不存在")

    def run(self):
        self._parse_result()

    def _parse_result(self):
        dt_config = self._get_component_config(self.component, self.test_type)
        disable = dt_config.get("disable")
        if disable:
            self.log.info("测试被禁用, 跳过结果分析。")
            return

        self.log.info(f"开始分析组件 {self.component} 的{self.test_type}测试结果")

        if self.test_type == _IT:
            self._parse_it_result(dt_config)
        elif self.test_type == _UT:
            self._parse_ut_result(dt_config)

        self.log.info(f"组件 {self.component} 的{self.test_type}测试结果分析完成")

    def _get_component_config(self, comp_name: str, test_type: str):
        if not self.commnuity_repo:
            return {}

        tmp_dir = tempfile.TemporaryDirectory()
        cwd = os.getcwd()
        dir_name = tmp_dir.name
        os.chdir(dir_name)
        Repo.clone_from(self.commnuity_repo, to_path=dir_name, branch="master")

        comp_config_yml = ""
        sig_dir = os.path.join(dir_name, "sig")
        for root, _, files in os.walk(sig_dir):
            if os.path.basename(root) != "components":
                continue
            for file in files:
                if file == f"{comp_name}.yml":
                    comp_config_yml = os.path.join(root, file)
                    break

        os.chdir(cwd)

        if not comp_config_yml:
            return {}

        with open(comp_config_yml, "r", encoding="UTF-8") as fp:
            comp_config = yaml.safe_load(fp)

        return comp_config.get(test_type, {})

    def _get_fail_skip_config(self, config):
        end_date = None
        dts_deadline = config.get("deadline")
        try:
            end_date = datetime.strptime(dts_deadline, _DATE_FORMAT)
        except ValueError as error:
            self.log.warning(f"deadline字段: {dts_deadline}解析失败, 原因为: {error}")

        dts = config.get("dts", "")
        name = config.get("name", "")
        return {"name": name, "dts": dts, "deadline": end_date}

    def _skip_all_failed(self, dt_config):
        skip_all_failed = dt_config.get("skip_all_failed")
        today = datetime.strptime(time.strftime(_DATE_FORMAT, time.localtime()), _DATE_FORMAT)
        if not skip_all_failed:
            return False

        skip_config = self._get_fail_skip_config(skip_all_failed)
        dts = skip_config.get("dts")
        deadline = skip_config.get("deadline")
        if not (dts or deadline):
            return False

        if deadline >= today:
            self.log.warning(f"部分测试用例失败, 存在全局失败屏蔽, 屏蔽单号为{dts}")
            return True
        else:
            self.log.error(f"部分测试用例失败, 存在屏蔽单号为 {dts}, 但已过解决截止时期{deadline}")

        return False

    def _parse_it_result(self, dt_config):
        fail_re = r"(=== test failed ===|lua call \[.*\] error|FAIL:)"
        failed = False
        # 使用surrogateescape避免日志中的特殊字符导致可能出现的UnicodeDecodeError: 'utf-8' codec...报错
        with open(self.result, "r", errors="surrogateescape") as fp:
            for line in fp:
                if re.search(fail_re, line):
                    failed = True
                    break
        if not failed:
            return
        skip_all_failed = self._skip_all_failed(dt_config)
        if not skip_all_failed:
            self.log.error("执行it测试结果失败, 请查看日志处理。")

    def _get_lua_failed_testcases(self):
        failed_testcases = []
        lua_fail_prefix = "not ok"
        with open(self.result, "r", errors="surrogateescape") as fp:
            for line in fp:
                if line.startswith(lua_fail_prefix):
                    failed_testcases.append(line.split()[-1].strip())

        return failed_testcases

    def _get_c_testcases(self):
        fail_regex = r".*FAIL:"
        pass_regex = r".*PASS:"
        failed_testcases = []
        pass_testcases = []
        with open(self.result, "r", errors="surrogateescape") as fp:
            for line in fp:
                if re.match(fail_regex, line):
                    testcase = re.split(fail_regex, line)[-1].strip()
                    failed_testcases.append(testcase)
                elif re.match(pass_regex, line):
                    testcase = re.split(pass_regex, line)[-1].strip()
                    pass_testcases.append(testcase)

        return {"fail": failed_testcases, "pass": pass_testcases}

    def _parse_failed_testcases(self, dt_config, failed_testcases: List[str]):
        testcases = (failed_testcases or []).copy()
        skip_all_failed = self._skip_all_failed(dt_config)
        if skip_all_failed:
            self.log.warning(f"以下失败的测试用例被全局屏蔽, 请尽快解决:\n {', '.join(testcases)}")
            return

        skip_failed_testcases = dt_config.get("skip_failed_testcases", [])
        today = datetime.strptime(time.strftime(_DATE_FORMAT, time.localtime()), _DATE_FORMAT)
        for skip_testcase in skip_failed_testcases:
            name = skip_testcase.get("name", None)
            if name in testcases:
                skip_config = self._get_fail_skip_config(skip_testcase)
                dts = skip_config.get("dts")
                deadline = skip_config.get("deadline")
                if not (dts or deadline):
                    continue

                if deadline >= today:
                    self.log.warning(f"测试用例 {name} 执行失败, 被 {dts} 屏蔽, 请尽快解决。")
                else:
                    self.log.error(f"部分测试用例失败, 存在屏蔽单号为 {dts}, 但已过解决截止时期{deadline}")
                testcases.remove(name)
        if testcases:
            self.log.error(f"以下{len(testcases)}个测试用例执行失败, 请处理:\n {', '.join(testcases)}")

    def _parse_ut_result(self, dt_config):
        pattern = r"^# Ran (\d+) tests in (.+) seconds, (\d+) success(?:es)?, ((\d+)( failures?| errors?),?){0,2}"
        with open(self.result, "r", errors="surrogateescape") as fp:
            last_line = ""
            for line in fp:
                last_line = line
            if re.match(pattern, last_line):
                self._parse_lua_ut_result(dt_config, last_line)
                return

        c_testcase_dict = self._get_c_testcases()
        c_failed_testcases = c_testcase_dict.get("fail", [])
        c_pass_testcases = c_testcase_dict.get("pass", [])
        if c_pass_testcases:
            self.log.info(f"总计{len(c_pass_testcases)}个测试用例执行成功。")
        if c_failed_testcases:
            self._parse_failed_testcases(dt_config, c_failed_testcases)
            return

        # 在对lua通过pattern查找和c的执行结果分析未查找到测试用例时, 可能执行出现异常, 需报告出来
        if not (c_failed_testcases + c_pass_testcases):
            self.log.error(f"存在ut执行出错或无测试用例, 请查看日志处理。")

    def _parse_lua_ut_result(self, dt_config, result_summary: str):
        def get_result_by_type(match_key):
            pattern = re.compile(f"(\d+)(?= {match_key})")
            for text in result_summary.split(", "):
                result_match = re.match(pattern, text.strip())
                if result_match:
                    return int(result_match.group(1))
            return 0

        successes = get_result_by_type("success")

        if successes:
            self.log.info(f"总计{successes}个测试用例执行成功。")


        failed_testcases = self._get_lua_failed_testcases()
        if failed_testcases:
            self._parse_failed_testcases(dt_config, failed_testcases)
