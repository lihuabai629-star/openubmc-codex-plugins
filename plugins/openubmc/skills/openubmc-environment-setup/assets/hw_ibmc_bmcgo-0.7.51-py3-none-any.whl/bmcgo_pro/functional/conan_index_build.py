#!/usr/bin/env python3
# encoding=utf-8
# 描述：组件维护工具
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2023. All rights reserved.
import os
import pathlib
import shutil
import stat

from bmcgo import misc
from bmcgo.misc import CommandInfo
from bmcgo.functional.conan_index_build import BmcgoCommand as BingoCommand
from bmcgo.functional.conan_index_build import if_available as bingo_if_available
from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.bmcgo_config import BmcgoConfig

tool = Tools("conanIdx")
log = tool.log
command_info: CommandInfo = CommandInfo(
    group="Conan Index commmands",
    name="build",
    description=["构建conan index仓下的组件"],
    hidden=False
)


def if_available(bconfig: BmcgoConfig):
    return bingo_if_available(bconfig)


class BmcgoCommand(BingoCommand):
    def install_luac(self):
        conan_bin = os.path.join(os.path.expanduser('~'), ".conan", "bin")
        # 设置PLD_LIBRARY_PATH环境变量，luajit运行时需要加载so动态库
        ld_library_path = conan_bin + ":" + os.environ.get("LD_LIBRARY_PATH", "")
        os.environ["LD_LIBRARY_PATH"] = ld_library_path
        # 设置PATH环境变量，luajit无需指定全路径
        path = conan_bin + ":" + os.environ.get("PATH", "")
        os.environ["PATH"] = path
        os.environ["LUA_PATH"] = f"{conan_bin}/?.lua"

        luac_path = os.path.join(conan_bin, "luac")
        # 待安装的skynet版本
        skynet_pkg = "skynet/1.7.0.B002@hw.ibmc.release/stable"
        skynet_flag = skynet_pkg.replace("@", "_").replace("/", "_")
        skynet_flag = os.path.join(conan_bin, skynet_flag)

        options = ""
        # 使能luajit时需要安装luajit
        if self.enable_luajit:
            luac_path = os.path.join(conan_bin, "luajit")
            options = "-o skynet:enable_luajit=True"
            skynet_flag += "_luajit"
        else:
            skynet_flag += "_luac"
        # skynet版本一致且luac/luajit存在时赋权即可
        if os.path.isfile(skynet_flag) and os.path.exists(luac_path):
            os.chmod(luac_path, stat.S_IRWXU)
            return
        if os.path.isdir(conan_bin):
            shutil.rmtree(conan_bin)
        os.makedirs(conan_bin)
        # 其它情况都尝试安装skynet
        cmd = f"conan install {skynet_pkg}"
        cmd += f" -pr profile.dt.ini --build -u {options}"
        if self.remote:
            cmd += f" -r {self.remote}"
        self.run_command(cmd)
        os.chmod(luac_path, stat.S_IRWXU)
        if self.enable_luajit:
            luajit2luac = shutil.which("luajit2luac.sh")
            cmd = f"cp {luajit2luac} {conan_bin}/luac"
            self.run_command(cmd)
        pathlib.Path(skynet_flag).touch(exist_ok=True)

    def run(self):
        if misc.conan_v1():
            self.install_luac()
        return super().run()
