#!/usr/bin/env python3
# encoding=utf-8
# 描述：组件的全量二进制构建
# Copyright (c) Huawei Technologies Co., Ltd. 2024. All rights reserved.
import os
import itertools
import json
import sys
import re
import stat
import shutil
import argparse
import importlib
import inspect
import functools
import random
from concurrent.futures import ProcessPoolExecutor, Future
from typing import List

from conans.model.manifest import FileTreeManifest
import yaml

from bmcgo import misc
from bmcgo.misc import CommandInfo, CONAN_USER
from bmcgo.component.component_dt_version_parse import ComponentDtVersionParse
from bmcgo.component.component_helper import (
    ComponentHelper,
    STAGE_DEV,
    STAGE_STABLE,
    STAGE_RC,
    BUILD_TYPE_DT,
    BUILD_TYPE_DEBUG,
    BUILD_TYPE_RELEASE,
)
from bmcgo.component.build import BuildComp
from bmcgo_pro.utils.fetch_component_code import FetchComponentCode
from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.bmcgo_config import BmcgoConfig
from bmcgo_pro.utils.config import Config
from bmcgo_pro.tasks.misc import HI171X_MODULE_SYMVERS, HI171X_SDK_PATH
from bmcgo_pro.tasks.task_build_rootfs_img import TaskClass as BuildRootfs

tool = Tools("build_full")
log = tool.log
command_info: CommandInfo = CommandInfo(
    group="Misc commands",
    name="build_full",
    description=["获取组件源码并构建出组件的全量二进制"],
    hidden=True,
)


def if_available(bconfig: BmcgoConfig):
    if bconfig.partner_mode:
        return False
    if bconfig.conan_index:
        return False
    return True


class BuildComponent:
    def __init__(
        self,
        comp,
        profile: str,
        stage: str,
        build_type: str,
        options: dict,
        code_path: str,
        skynet_version: str,
        remote=misc.conan_remote(),
        service_json="mds/service.json",
        upload=False
    ):
        self.bconfig = BmcgoConfig()
        self.comp_name, self.comp_version, *_ = re.split("@|/", comp)
        self.profile = profile
        self.stage = stage
        self.build_type = build_type
        self.options = options
        self.code_path = code_path
        self.skynet_version = skynet_version
        self.option_cmd = ""
        self.remote = remote
        self.upload = upload
        self.service_json = service_json

    @staticmethod
    def delete_sensitive_info(comp_name, comp_version, stage, strip=False):
        path = os.path.join(
            tool.conan_data,
            comp_name,
            comp_version,
            "hw.ibmc.release",
            stage,
        )
        if not os.path.isdir(path):
            return

        export_folder = os.path.join(path, "export")
        exports_src_folder = os.path.join(path, "export_source")
        package_folder = os.path.join(path, "package")
        manifest = FileTreeManifest.create(export_folder, exports_src_folder)
        manifest.save(export_folder)
        old_hash = manifest.summary_hash
        # 清除旧的包含export和package压缩包的dl目录
        tool.run_command(f"rm -rf {os.path.join(path, 'dl')}")

        BuildComponent.delete_recipe_sensitive_info(export_folder)
        # 清理export_source目录中的内容 (包括patch)
        if os.path.isdir(exports_src_folder):
            shutil.rmtree(exports_src_folder)
            os.mkdir(exports_src_folder)

        manifest = FileTreeManifest.create(export_folder, exports_src_folder)
        manifest.save(export_folder)
        if not os.path.isdir(package_folder):
            tool.log.warning(f"组件package目录{package_folder}不存在, 无package包。")
            return

        if strip:
            BuildComponent.strip_symbols(comp_name, package_folder)

        recipe_hash = manifest.summary_hash
        for pkg_id in os.listdir(package_folder):
            pkg_dir = os.path.join(package_folder, pkg_id)
            if strip:
                pkg_manifest = FileTreeManifest.create(pkg_dir)
                pkg_manifest.save(pkg_dir)
            conaninfo_path = os.path.join(pkg_dir, "conaninfo.txt")
            conaninfo_hash_ret, _ = tool.pipe_command([f"md5sum {conaninfo_path}"], capture_output=True)
            conaninfo_old_hash = conaninfo_hash_ret.split()[0]

            tool.run_command(f"sed -i 's/{old_hash}/{recipe_hash}/g' {conaninfo_path}")
            conaninfo_hash_ret, _ = tool.pipe_command([f"md5sum {conaninfo_path}"], capture_output=True)
            conaninfo_new_hash = conaninfo_hash_ret.split()[0]
            manifest_path = os.path.join(pkg_dir, "conanmanifest.txt")
            tool.run_command(f"sed -i 's/{conaninfo_old_hash}/{conaninfo_new_hash}/g' {manifest_path}")

    @staticmethod
    def delete_recipe_sensitive_info(export_folder: str):
        file_name_list = ["conanfile.py", "conanbase.py"]
        for file_name in file_name_list:
            file_path = os.path.join(
                export_folder,
                file_name,
            )
            scm_pattern = r"scm\s*=\s*\{[^}]*\}"
            url_pattern = r"url\s*=\s*(\([^)]*\)|[^\n]+)"
            home_page_pattern = r"homepage\s*=\s*(\([^)]*\)|[^\n]+)"
            if os.path.exists(file_path):
                conan_file = os.fdopen(os.open(file_path, os.O_RDWR, stat.S_IWUSR | stat.S_IRUSR), "w+")
                content = conan_file.read()
                # 删除scm信息
                updated_content = re.sub(scm_pattern, "", content, flags=re.MULTILINE)
                if file_name == "conanfile.py":
                    updated_content = re.sub(url_pattern, "", updated_content, flags=re.MULTILINE)
                    updated_content = re.sub(home_page_pattern, "", updated_content, flags=re.MULTILINE)
                conan_file.seek(0)
                conan_file.truncate()
                conan_file.write(updated_content)
                conan_file.close()

    @staticmethod
    def strip_symbols(comp_name: str, package_folder: str):
        strip_log_dir = os.path.join(tool.user_home, "strip", comp_name)
        tool.run_command(f"mkdir -p {strip_log_dir}")
        file_list = os.path.join(strip_log_dir, "file2strip.filelist")
        base = BuildRootfs.make_strip_cmd(file_list, package_folder)
        strip = os.path.join(Config.cross_compile_install_path, "bin", f"{Config.cross_prefix}-strip")
        # ignore_error是部分组件中没有包含not stripped的文件, 防止grep 'not stripped'报错
        tool.pipe_command(base, file_list, ignore_error=True)
        if os.path.isfile(file_list):
            cmd = [f"cat {file_list}", "sudo xargs -P 0 -I {{}} {} -R .comment {{}}".format(strip)]
            tool.pipe_command(cmd)
            cmd = [f"cat {file_list}", "sudo xargs -P 0 -I {{}} {} {{}}".format(strip)]
            tool.pipe_command(cmd)


    def run(self):
        os.chdir(os.path.join(self.code_path, self.comp_name))
        for key, value in self.options.items():
            if isinstance(key, str) and ":" in key:
                self.option_cmd = self.option_cmd + f" -o {key}={value}"
            else:
                self.option_cmd = self.option_cmd + f" -o {self.comp_name}:{key}={value}"
        command = (
            f"--remote {self.remote} -nc --stage {self.stage} --build_type {self.build_type.lower()}"
            f" --profile {self.profile} {self.option_cmd}"
        )
        log.info(f"执行构建命令bmcgo build {command}")
        args = command.split()
        build = BuildComp(self.bconfig, args, service_json=self.service_json, skynet_version=self.skynet_version)
        # 恢复工作区为clean状态, 保证conan export时scm信息准确
        tool.run_command("git restore .")
        tool.run_command("git clean -fd")
        build.run(timeout=3600)
        log.success("组件{}构建成功".format(self.comp_name))
        if self.upload:
            log.info("上传组件包至conan仓......")
            tool.run_command(f'conan upload "*" --all --remote {self.remote} -c --no-overwrite')


class BmcgoCommand:
    def __init__(self, bconfig: BmcgoConfig, *args):
        parser = argparse.ArgumentParser(description="Fetch component source code and build all binaries.")
        parser.add_argument("-comp", "--component", help="软件包名, 示例: oms/1.2.6", required=True)
        parser.add_argument("-r", "--remote", help="远端仓库名称", default=misc.conan_remote())
        parser.add_argument(
            "-p",
            "--path",
            help="指定拉取源代码的存放路径\n默认：./temp/source_code",
            default="./temp/source_code",
        )
        parser.add_argument("-pi", "--package_info", help="package_info文件路径", required=True)
        parser.add_argument("-u", "--upload", action=misc.STORE_TRUE, help="上传组件包到conan仓")
        parser.add_argument("--config_file", help="全量二进制配置文件")
        parser.add_argument("--skip_fetch", action=misc.STORE_TRUE, help="跳过fetch")
        parser.add_argument("--build_type", action="append", help="构建类型")

        parsed_args, _ = parser.parse_known_args(*args)
        self.bconfig = bconfig
        self.comp = parsed_args.component
        self.comp_name, self.comp_version, *_ = re.split("@|/", self.comp)
        self.code_path = os.path.realpath(os.path.join(bconfig.cwd, parsed_args.path))
        self.comp_path = os.path.join(self.code_path, self.comp_name)
        self.remote = parsed_args.remote
        self.package_info_path = os.path.realpath(os.path.join(bconfig.cwd, parsed_args.package_info))
        self.config_file_path = None
        if parsed_args.config_file:
            self.config_file_path = os.path.realpath(os.path.join(bconfig.cwd, parsed_args.config_file))
        self.upload = parsed_args.upload
        self.skip_fetch = parsed_args.skip_fetch
        self.profile_list = ["profile.dt.ini", "profile.luajit.ini"]
        self.stage_list = [STAGE_STABLE]
        self.built_type_list = [BUILD_TYPE_DT, BUILD_TYPE_DEBUG, BUILD_TYPE_RELEASE]
        if parsed_args.build_type:
            self.built_type_list = parsed_args.build_type
        self.options_dict = {}

    @staticmethod
    def get_conan_file_cls(comp_path):
        os.chdir(comp_path)
        # 先生成conanbase.py文件
        BuildComp(BmcgoConfig(), gen_conanbase=True)
        # 动态导入conanfile.py模块
        sys.path.append(comp_path)
        conan_file_module = importlib.import_module("conanfile")
        all_classes = [
            obj
            for name, obj in inspect.getmembers(conan_file_module)
            if inspect.isclass(obj) and obj.__module__ == conan_file_module.__name__
        ]
        conan_file_cls = None
        for cls in all_classes:
            # 如果有name和version，即返回
            if cls.name and cls.version:
                conan_file_cls = cls
                break
        # 删除导入的conanbase和conanfile, 保证后续组件的导入是最新的conanbase和conanfile模块
        sys.modules.pop("conanbase")
        sys.modules.pop("conanfile")
        sys.path.pop()
        # 清空编译的conanbase缓存, 防止后续构建时使用了缓存的conanbase（未继承ConanFile版本)
        tool.run_command("rm -rf __pycache__")
        # 恢复工作区为clean状态, 保证conan export时scm信息准确
        tool.run_command("git restore .")
        tool.run_command("git clean -fd")

        return conan_file_cls

    @staticmethod
    def get_build_options(conan_file_cls, config_file):
        options_dict = {}
        if hasattr(conan_file_cls, "options"):
            options_dict = conan_file_cls.options

        # 添加module_symver选项
        module_symvers_path = os.path.join(HI171X_SDK_PATH, HI171X_MODULE_SYMVERS)
        module_symver_key, module_symver_value = tool.get_hi171x_module_symver_option(module_symvers_path)
        if module_symver_key in options_dict:
            options_dict[module_symver_key] = [module_symver_value, ""]
        if config_file:
            with open(config_file, "r") as yaml_fp:
                obj = yaml.safe_load(yaml_fp)
            BmcgoCommand.generate_all_options(obj, options_dict)
            BmcgoCommand.generate_com_options(conan_file_cls, obj, options_dict)
        tool.log.info(f"组件全量options选项为: {options_dict}")
        return options_dict

    @staticmethod
    def generate_com_options(conan_file_cls, obj, options_dict):
        if conan_file_cls.name in obj:
            for exclude_option in obj[conan_file_cls.name].get("exclude_options", []):
                del options_dict[exclude_option]
            if obj[conan_file_cls.name].get("add_options", {}):
                options_dict.update(obj[conan_file_cls.name]["add_options"])

    @staticmethod
    def generate_all_options(obj, options_dict):
        if obj.get("all", {}):
            for exclude_option in obj["all"]["exclude_options"]: 
                if exclude_option in options_dict:
                    del options_dict[exclude_option]
            if obj["all"].get("add_options", {}):
                options_dict.update(obj["all"]["add_options"])

    @staticmethod
    def copy_stable2rc(comp: str):
        com_folder = os.path.join(tool.conan_data, comp)
        cwd = os.getcwd()
        os.chdir(com_folder)
        for version in os.listdir(com_folder):
            pkg = f"{comp}/{version}@{CONAN_USER}/{STAGE_STABLE}"
            if not os.path.exists(os.path.join(tool.conan_data, pkg.replace("@", "/"))):
                continue
            tool.run_command(f"conan copy {pkg} {CONAN_USER}/{STAGE_RC} --all --force")
        os.chdir(cwd)

    @staticmethod
    def copy_all_stable2rc(tools: Tools):
        comps = os.listdir(tools.conan_data)
        tools.log.info(f"创建多进程获取复制conan data下所有组件的stable到rc版本...")
        pool = ProcessPoolExecutor()
        future_tasks: List[Future] = []
        for comp in comps:
            task = pool.submit(BmcgoCommand.copy_stable2rc, comp)
            future_tasks.append(task)

        pool.shutdown()
        for task in future_tasks:
            task_exception = task.exception()
            if task_exception is not None:
                raise task_exception

    @staticmethod
    def _replace_dev_version(temp_service_json: str):
        version_parse = ComponentDtVersionParse(serv_file=temp_service_json)
        for pkg in version_parse.conan_list:
            component = pkg[misc.CONAN]
            if "@" not in component:
                continue
            comp_version, user_channel = component.split("@")
            if user_channel.endswith(STAGE_DEV):
                pkg[misc.CONAN] = f"{comp_version}{ComponentHelper.get_user_channel(STAGE_DEV)}"

        version_parse.write_to_serv_file()

    def fetch_code(self):
        conan_path = os.path.join(tool.conan_data, self.comp_name)
        if os.path.isdir(conan_path):
            shutil.rmtree(conan_path)
        if os.path.isdir(self.code_path):
            shutil.rmtree(self.code_path)
        os.makedirs(self.code_path)
        packages = {self.comp_name: self._full_reference}
        FetchComponentCode(packages, self.code_path, self.remote).run()

    def revise_comp_version(self, service_json: str):
        """修订version为当前指定的版本, 以支持x.y.z-build.x格式的补丁版本

        Args:
            service_json (str): service.json文件路径
        """
        os.chdir(self.comp_path)
        file_open_mode = stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH
        with os.fdopen(os.open(service_json, flags=os.O_RDWR, mode=file_open_mode), "w+") as file_handler:
            service_json_data = json.load(file_handler)
            service_json_data["version"] = self.comp_version
            file_handler.seek(0)
            file_handler.truncate()
            json.dump(service_json_data, file_handler, indent=4, ensure_ascii=False)
            file_handler.close()

    def revise_service_dependencies(self, service_json: str):
        """修订build/test的依赖组件的版本为patch范围版本

        Args:
            service_json (str): service.json文件路径
        """
        os.chdir(self.comp_path)
        with open(service_json, "r", encoding="UTF-8") as file_handler:
            service_json_data = json.load(file_handler)
        dependencies = service_json_data.get(misc.CONAN_DEPDENCIES_KEY, {})
        if not dependencies:
            # service.json中没有依赖，可直接构建
            return
        ComponentDtVersionParse(serv_file=service_json, exclude_dt=True).manifest_version_revise(
            self.package_info_path, use_patch_range=True
        )
        self._replace_dev_version(service_json)

    def run(self):
        if not self.skip_fetch:
            if not self._is_self_developed:
                tool.log.warning(f"非自研组件{self.comp}不支持该功能。")
                return
            self.fetch_code()
        self._package_docs_from_source()
        conan_file_cls = self.get_conan_file_cls(self.comp_path)
        self.options_dict = self.get_build_options(conan_file_cls, self.config_file_path)
        service_json = self._create_temp_service_json()
        self.revise_comp_version(service_json)
        self.revise_service_dependencies(service_json)
        self.build_all_packages(service_json)
        self.copy_all_stable2rc(tool)
        if self.upload:
            log.info("上传组件包至conan仓......")
            tool.run_command(f'conan upload "*" --all --remote {self.remote} -c --no-overwrite')

    def build_all_packages(self, service_json: str):
        """构建出组件所有组合的package包

        Args:
            service_json (str): 显式指定用于生成conanbase.py依赖的service.json路径
        """
        skynet_verison = self._get_skynet_version()

        all_attributes = {
            "profile": self.profile_list,
            "stage": self.stage_list,
            "build_type": self.built_type_list,
        }
        # 不参与构建二进制的选项
        block_options = ["asan", "gcov"]
        options_dict = self.options_dict
        for block in block_options:
            options_dict.pop(block, None)

        all_attributes = {**all_attributes, **options_dict}
        # 设置变量让所有场景（包括DT）构建lua代码时都进行编译
        os.environ["TRANSTOBIN"] = "true"
        log.info(f"构建组件{self.comp}的全量二进制, 选项包含：{options_dict}")
        all_build_params = list(itertools.product(*all_attributes.values()))
        if not self.skip_fetch:
            random.shuffle(all_build_params)
        for build_args in all_build_params:
            profile, stage, build_type, *option_values = build_args
            if profile == "profile.dt.ini" and build_type.lower() != BUILD_TYPE_DT.lower():
                continue
            if profile != "profile.dt.ini" and build_type.lower() == BUILD_TYPE_DT.lower():
                continue
            build_options = dict(zip(options_dict.keys(), option_values))
            task = BuildComponent(
                self.comp,
                profile,
                stage,
                build_type,
                build_options,
                self.code_path,
                skynet_verison,
                remote=self.remote,
                service_json=service_json,
                upload=self.upload,
            )
            task.run()

    @functools.cached_property
    def _is_self_developed(self) -> bool:
        tool.run_command(f"conan download {self._full_reference} --recipe -r {self.remote}")
        comp_package_path = os.path.join(tool.conan_data, self.comp_name)
        ret = tool.run_command(f"find {comp_package_path} -name 'conanbase.py'", capture_output=True)
        return bool(ret.stdout)

    @functools.cached_property
    def _full_reference(self) -> str:
        comp_pkg = self.comp if "@" in self.comp else f"{self.comp}@{CONAN_USER}/{STAGE_STABLE}"
        return comp_pkg

    def _create_temp_service_json(self):
        temp_path = os.path.join(self.comp_path, "temp")
        os.makedirs(temp_path, exist_ok=True)
        temp_service_json = os.path.join(temp_path, "service.json")
        if not os.path.isfile(temp_service_json):
            tool.copy(os.path.join(self.comp_path, "mds/service.json"), temp_service_json)
        return temp_service_json

    def _package_docs_from_source(self):
        os.chdir(self.comp_path)
        current_path = os.getcwd()
        package_folder = []
        for entry in os.listdir(current_path):
            entry_l = entry.lower()
            if entry_l == "mds" or entry_l == "docs":
                package_folder.append(entry)
            elif "changelog" in entry_l or entry_l.endswith(".md"):
                package_folder.append(entry)
        if not package_folder:
            tool.log.info("无docs文档, 跳过文档打包。")
            return
        tar_cmd = ["tar", "-czvf", f"{self.code_path}/{self.comp_name}_docs.tar.gz"] + package_folder
        tool.run_command(tar_cmd)

    def _get_skynet_version(self):
        with open(self.package_info_path, "r") as fp:
            lines = fp.readlines()
            for line in lines:
                comp_name, comp_version, *_ = re.split("@|/", line.strip())
                if comp_name == "skynet":
                    return comp_version
        return ""
