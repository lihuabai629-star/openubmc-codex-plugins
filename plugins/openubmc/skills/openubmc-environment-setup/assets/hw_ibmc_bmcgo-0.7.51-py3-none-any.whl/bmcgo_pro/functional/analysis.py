#!/usr/bin/env python3
# encoding=utf-8
# 描述：组件依赖和接口分析
# Copyright (c) 2024 Huawei Technologies Co., Ltd.
# openUBMC is licensed under Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#         http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.
import os
import urllib3


from bmcgo.misc import CommandInfo
from bmcgo.functional.analysis import BmcgoCommand as AnalysisCommand
from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.bmcgo_config import BmcgoConfig
from bmcgo_pro.component.analysis.analysis import AnalysisComp
from bmcgo_pro.component.analysis.intf_validation import InterfaceValidation
from bmcgo_pro.component.analysis.sr_validation import SrValidate

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

tool = Tools("analysis")
log = tool.log
command_info: CommandInfo = CommandInfo(
    group="Misc commands",
    name="analysis",
    description=["依赖和接口分析"],
    hidden=False
)


def if_available(bconfig: BmcgoConfig):
    return bconfig.manifest is not None or bconfig.component is not None


class BmcgoCommand(AnalysisCommand):
    def __init__(self, bconfig: BmcgoConfig, *args):
        super().__init__(bconfig, args)

    def component_analysis(self):
        if not InterfaceValidation(self.remote).run() or not SrValidate(os.getcwd()).run():
            return -1
        return 0

    def product_analysis(self, custom_sr_dir):
        rule_file = os.path.join(self.bconfig.manifest.folder, "dep-rules.json")
        if not os.path.isfile(rule_file):
            rule_file = None
        analysis_task = AnalysisComp(self.board_name, self.out_dir, self.lock_file, custom_sr_dir, rule_file)
        result = analysis_task.run()
        return result
