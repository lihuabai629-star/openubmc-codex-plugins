# coding: utf-8
# 版权所有 (c) 华为技术有限公司 2023-2023
# 注意：build.py已删除__version__信息

__version__ = '0.7.51'
