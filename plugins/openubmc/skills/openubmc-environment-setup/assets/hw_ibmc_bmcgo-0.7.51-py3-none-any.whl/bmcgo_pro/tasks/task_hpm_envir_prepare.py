#!/usr/bin/env python
# coding:utf-8
# Copyright © Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.

"""
文件名：envir_prepare.py
功能：打包目录形成
版权信息：华为技术有限公司，版本所有(C) 2020-2021
"""
from bmcgo.tasks.task_hpm_envir_prepare import TaskClass as BingoHpmEnvPrepareTask


class TaskClass(BingoHpmEnvPrepareTask):
    """继承并重写TaskClass"""

    # 自签名函数，继承类可扩展，不能变更方法名，重要!!!
    def self_sign(self):
        # 如果是自签名模式，那么则复制预置的cms_hpm.crl作为签名文件，并复制cms
        self.signature(
            f"{self.config.work_out}/rootfs_iBMC.img",
            f"{self.config.work_out}/rootfs_iBMC.img.cms",
            f"{self.config.work_out}/cms.crl",
            f"{self.config.work_out}/rootca.der",
        )

    # 在线签名函数，继承类可扩展，不能变更方法名，重要!!!
    def online_sign(self):
        self.info(f"{self.config.code_path}/manufacture/signature/sign_img.xml")
        # 由manifest.yml定义并存储在board_path目录
        self.run_command(f"cp {self.config.board_path}/sign_img.xml sign_img.xml")
        self.tools.py_sed(
            "sign_img.xml", '(?<=path=").*(?=")', self.config.work_out
        )
        # 签名之后会在$work_out位置生成cms签名文件
        self.run_command(
            "java -jar /usr/local/signature-jenkins-slave/signature.jar sign_img.xml",
            show_log=True,
        )

    def tar_img(self):
        self.run_command("tar --format=gnu --exclude iBMC_rootfs.tar.gz -czf rootfs_iBMC.tar.gz rootfs_iBMC.img")
        self.success("tar iBMC_rootfs.tar.gz successfully")

    def prepare_hpm(self):
        hpm_build_dir = self.config.hpm_build_dir
        hpm_build_dir_src = f"/usr/share/bmcgo/ipmcimage"
        self.tools.copy_all(hpm_build_dir_src, hpm_build_dir)

        self.run_command(f"cp {self.config.board_path}/update_ext4.cfg {hpm_build_dir}/update.cfg")

        self.chdir(hpm_build_dir)
        if not self.skip_post_hpm:
            self._component_cust_action("post_hpm")

        ver, _ = self.pipe_command([
                "cat update.cfg",
                "grep '^Version='",
                "awk -F '=' '{print $2}'",
            ], capture_output=True)
        curr_ver = ver.strip().split("\n")[0]

        # 读取发布时用的包名， 用以定位是否有预置的密钥， 签名文件
        vs = self.config.version.split(".")
        if self.manufacture_version_check(f"{self.config.board_path}/manifest.yml") is True:
            vs[3] = str(int(vs[3]) + 1).zfill(2)
        ver = f"{vs[0]}.{vs[1]}.{vs[2]}.{vs[3]}"

        # 正常包
        self.info(f"bmc 版本: {ver}")
        self.run_command(
            f"sed -i \"/^Version=/s/{curr_ver}/{ver}/g\" update.cfg")
        self.run_command("chmod +x . -R")
