# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
"""
功    能：下载并安装V2X的rtos/hcc工具
版权信息：华为技术有限公司，版本所有(C) 2024
修改记录：2024-08-29 创建
"""
import os
import shutil

from bmcgo import misc
from bmcgo_pro.tasks.task import Task
from bmcgo_pro.tasks.misc import BUILD_TOOLS_SHA256_PATH, RTOS_DIST_SHA256_PATH
from bmcgo_pro.utils.config import Config
from bmcgo_pro.utils.artget_tools import ArtgetDownloadTool


class DownloadHmBuildTools(Task):
    def __init__(self, config: Config):
        super(DownloadHmBuildTools, self).__init__(config, "DownloadHmBuildTools")
        self.dependency_file = os.path.realpath(
            os.path.join(self.config.code_path, self.get_manufacture_config("base/dependency_buildtools"))
        )
        self.rtos_sdk_dir = f"{self.config.tools_path}/rtos-sdk-arm64-hm"
        _, buildtool_config = self.get_profile_config()
        self.standalone_toolchain = buildtool_config.get("standalone_toolchain", self.config.cross_compile_install_path)
        self.rtos_root = buildtool_config.get("rtos_root", f"/opt/{self.config.rtos_offering}")
        self.sysroot = buildtool_config.get("sysroot", self.config.sysroot)
        self.target_host = buildtool_config.get("target_host", self.config.cross_prefix)
        self.download_file_old_sha256 = f"{self.config.tools_path}/buildtools_download_file_old.sha256"
        self.download_file_new_sha256 = f"{self.config.tools_path}/buildtools_download_file_new.sha256"
        self.buildtools_new_sha256 = f"{self.config.tools_path}/buildtools_new.sha256"
        self.skip_install = False

    def download_tools(self):
        self.info(f"移除下载路径: {self.rtos_sdk_dir}")
        self.run_command(f"rm -rf {self.rtos_sdk_dir}", ignore_error=True, sudo=True)
        self.run_command(f"rm -rf {self.download_file_old_sha256}", ignore_error=True, sudo=True)
        self.info("开始下载依赖工具...")
        partner_tools_dir = f"{os.path.expanduser('~')}/rtos_compiler"
        if self.config.partner_mode:
            self.info(f"从缓存目录{partner_tools_dir}复制编译器工具")
            self.run_command(f"cp -rf {partner_tools_dir}/. {self.rtos_sdk_dir}")
        else:
            artget_rtos_sdk = ArtgetDownloadTool(self.dependency_file, f"{self.rtos_sdk_dir}")
            artget_rtos_sdk.download()
            if os.path.isdir(partner_tools_dir):
                shutil.rmtree(partner_tools_dir)
            # 非partner模式复制构建工具，以备伙伴模式使用
            self.run_command(f"cp -rf {self.rtos_sdk_dir}/. {partner_tools_dir}")
            self.run_command(f"cp -af {self.download_file_new_sha256} {self.download_file_old_sha256}")
        self.info("下载依赖工具结束")

    def install_buildtools(self):
        is_ubuntu = self.tools.is_ubuntu
        self.chdir(self.rtos_sdk_dir)
        self.info("安装 rpm 包")
        self.info(f"删除目录 {self.rtos_root}")
        self.run_command(f"rm -rf {BUILD_TOOLS_SHA256_PATH}", sudo=True)
        self.run_command(f"rm -rf {RTOS_DIST_SHA256_PATH}", sudo=True)
        self.run_command(f"rm -rf {self.rtos_root}", sudo=True)
        for rpm in os.listdir("./"):
            if not os.path.isfile(rpm) or not rpm.endswith(".rpm"):
                continue
            self.info("安装 {}".format(rpm))
            if not is_ubuntu:
                self.run_command("rpm -ivh {}".format(rpm), sudo=True)
            else:
                self.pipe_command(["rpm2cpio {}".format(rpm), "sudo cpio -id -D /"])

        self.info(f"删除目录 {self.standalone_toolchain}")
        self.run_command(f"rm -rf {self.standalone_toolchain}", sudo=True)
        self.info("解压 hcc_arm64le")
        self.run_command("tar -xzf hcc_arm64le.tar.gz -C /opt", sudo=True)

        hm_tiny = "/opt/hcc_arm64le_hm_tiny"
        self.info(f"删除目录 {hm_tiny}")
        self.run_command(f"rm -rf {hm_tiny}", sudo=True)
        self.info("解压 hcc_arm64le_hm_tiny")
        self.run_command("tar -xzf hcc_arm64le_hm_tiny.tar.gz -C /opt", sudo=True)

        logname = os.getenv(misc.ENV_LOGNAME, None)
        if logname and logname != "root":
            user_group = f"{os.getuid()}:{os.getgid()}"
            self.run_command(f"chown {user_group} {self.rtos_root} -R", sudo=True)
            self.run_command(f"chown {user_group} {self.standalone_toolchain} -R", sudo=True)
            self.run_command(f"chown {user_group} {hm_tiny} -R", sudo=True)

        self.chdir(self.config.code_path)

        libstdcpp_install_path = os.path.join(self.sysroot, "usr")
        os.makedirs(libstdcpp_install_path, exist_ok=True)

        cross_compile_lib64 = os.path.join(self.standalone_toolchain, self.target_host, "lib64")
        self.run_command(f"cp -rf {cross_compile_lib64} {libstdcpp_install_path}")

        cmake_platform, _ = self.pipe_command(
            ["find /usr/share -type d -wholename */Modules/Platform", "head -n 1"], sudo=True, capture_output=True
        )
        self.info(f"复制HongMeng.cmake到 {cmake_platform}")
        hm_cmake = os.path.join(libstdcpp_install_path, "share/cmake/Modules/Platform/HongMeng.cmake")
        self.run_command(f"cp -af {hm_cmake} {cmake_platform}", sudo=True)
        self.run_command("cp -af {} {}".format(self.buildtools_new_sha256, BUILD_TOOLS_SHA256_PATH), sudo=True)

    def run(self):
        self.skip_download = not self.check_need_download(
            self.dependency_file,
            self.download_file_old_sha256,
            self.download_file_new_sha256,
        )
        if self.skip_download:
            self.info("buildtools下载文件未变更, 跳过下载")
            return
        self.download_tools()

    def install(self):
        self.skip_install = not self.check_need_install(
            self.rtos_sdk_dir, BUILD_TOOLS_SHA256_PATH, self.buildtools_new_sha256
        )
        if self.skip_install:
            self.info("buildtools版本匹配, 跳过安装")
            return
        self.install_buildtools()
