#!/usr/bin/env python
# coding: utf-8
# Copyright © Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.

"""
文件名：work_build_conan.py
功能：编译产品依赖包
版权信息：华为技术有限公司，版本所有(C) 2019-2020
"""

import os
import shutil

from bmcgo import errors

from bmcgo_pro.tasks.task import Task
from bmcgo_pro.utils.config import Config
from bmcgo_pro.utils.docker import Docker


class TaskClass(Task):
    def __init__(self, config: Config, work_name=""):
        super(TaskClass, self).__init__(config, work_name=work_name)
        self.docker = Docker(
            name="server",
            work_path=self.config.code_root,
            container_tag=self.config.container_tag,
            cmd="conan_server &",
        )
        self.conan_remote = "docker_server"

    def docker_prepare(self):
        if self.docker.docker_start():
            self.info("conan_server 启动成功, 等待上传")
        else:
            raise Exception("docker 启动失败, 请检查环境")

    def run(self):
        self.docker_prepare()

        try:
            # 安装rtos/compiler相关包
            self.docker.exec(f"bmcgo build -t install_sdk > temp/docker_build.log 2>&1")
            # 更新work_path, 后续会删除code_root目录（即manifest目录)
            self.docker.work_path = os.path.dirname(self.config.code_root)

            self.purge_sensitive_info()

            archive_path = os.path.join(self.config.output_path, "packet", self.config.archive_path)
            if not os.path.isdir(archive_path):
                os.makedirs(archive_path)
            self.docker.export(archive_path)
        except Exception as exc:
            self.docker.clear()
            raise errors.BmcGoException(f"构建docker镜像失败. {exc}")
        self.docker.clear()

    def purge_sensitive_info(self):
        self.purge_bmc_tools()

        self.docker.exec("conan remote clean")

        self.delete_user_config()

        self.docker.exec(f"rm -rf {self.docker.user_home}/.conan/data/*")
        self.docker.exec("rm -rf /usr/share/maven/conf/settings.xml")
        self.docker.exec("rm -rf /usr/local/signature-jenkins-slave")
        # 删除manifest目录
        self.docker.exec(f"rm -rf {self.config.code_root}")

    def purge_bmc_tools(self):
        self.docker.exec("pip3 uninstall -y hw_ibmc_bmcgo")
        self.docker.exec("pip3 uninstall -y hw-ibmc-bmc-studio")
        luajit2luac = shutil.which("luajit2luac.sh")
        # 备份luajit2luac
        luajit2luac_bak = os.path.join(os.path.dirname(luajit2luac), "luajit2luac_bak")
        self.docker.exec(f"mv {luajit2luac} {luajit2luac_bak}")
        self.docker.exec("dpkg -r hw-ibmc-bmcgo")
        self.docker.exec("dpkg -r bmc-studio")
        # 还原luajit2luac
        self.docker.exec(f"mv {luajit2luac_bak} {luajit2luac}")

        self.docker.exec("rm -rf $(which artget)")

    def delete_user_config(self):
        configs = [".ArtGet", ".git-credentials", ".npmrc", ".config/pip/pip.conf"]
        for config in configs:
            self.docker.exec(f"rm -rf {self.docker.user_home}/{config}")

        source_list = "/etc/apt/sources.list"
        self.docker.exec(f"mv {source_list}_bak {source_list}")
