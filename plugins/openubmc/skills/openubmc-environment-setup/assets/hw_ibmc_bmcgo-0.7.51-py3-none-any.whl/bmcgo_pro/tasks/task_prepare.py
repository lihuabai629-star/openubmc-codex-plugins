#!/usr/bin/env python
# coding:utf-8
# Copyright © Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.

"""
文件名：envir_prepare.py
功能：打包目录形成
版权信息：华为技术有限公司，版本所有(C) 2020-2021
"""
from bmcgo import errors
from bmcgo.tasks.task_prepare import TaskClass as BingoPrepareTask

from bmcgo_pro.tasks.task import Task


class TaskClass(Task, BingoPrepareTask):

    def init_crl(self):
        self.chdir(self.config.board_path)
        if not self.config.self_sign:
            # 兼容其他分支，创建一个空的crl文件
            self.run_command("touch huawei_cms.crl")

    def run(self):
        self.init_crl()
        super().run()
