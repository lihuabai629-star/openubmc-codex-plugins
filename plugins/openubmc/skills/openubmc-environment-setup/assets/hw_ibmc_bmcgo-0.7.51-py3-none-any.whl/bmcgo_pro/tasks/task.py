#!/usr/bin/python3
# coding: utf-8
# 版权所有 (c) 华为技术有限公司 2023-2023
import os
import filecmp
from bmcgo.tasks.task import Task as BingoTask
from bmcgo_pro.utils.config import Config
from bmcgo_pro.utils.swbom import SWBom
from bmcgo_pro.utils.tools import Tools


class Task(BingoTask):
    def __init__(self, config: Config, work_name=""):
        super(Task, self).__init__(config, work_name)
        self.tools: Tools = Tools(work_name, log_file=self.tools.log_name)

    def write_ingredient(self, src_path: str):
        file_list = []
        for root, _, files in os.walk(src_path):
            for file in files:
                filename = os.path.realpath(os.path.join(root, file))
                filename = filename.replace(f"{src_path}/", "")
                file_list.append(filename)
        zip_package_files = {}
        for file in file_list:
            zip_package_files.update({file: self.tools.sha256sum(file)})
        # 生成ZIP包构建元数据
        zip_package_info = {
            "files": zip_package_files
        }

        swbom_file = f"{src_path}/zip_info.yml"
        swbom = SWBom(swbom_file)
        swbom.write(zip_package_info)
        # 生成ZIP包构建元数据

    def check_need_download(self, download_file_path, old_sha, new_sha):
        need_download_flag = True
        if self.config.partner_mode:
            return need_download_flag
        self.pipe_command([f"sha256sum {download_file_path}", "awk '{print $1}'"], new_sha)
        if os.path.isfile(old_sha) and filecmp.cmp(old_sha, new_sha):
            need_download_flag = False
        return need_download_flag

    def check_need_install(self, download_dir_path, old_sha, new_sha):
        need_install_flag = True
        # 计算sdk sha256
        self.pipe_command(
            [
                f"find {download_dir_path} -type f",
                "xargs sha256sum",
                "awk '{print $1}'",
                "sort",
            ],
            new_sha,
        )
        if os.path.isfile(old_sha) and filecmp.cmp(old_sha, new_sha):
            need_install_flag = False
        return need_install_flag

    def _if_match(self, condition):
        if condition is None:
            return True
        hash_unknown = {}
        for key, val in condition.items():
            if key == "build_type":
                if self.config.build_type != val:
                    return False
            elif key == "signature_type":
                if self.config.signature_type != val:
                    return False
            elif key == "encrypt_type":
                if self.config.encrypt_type != val:
                    return False
            else:
                hash_unknown[key] = val
        if hash_unknown:
            return super()._if_match(hash_unknown)
        else:
            return True
