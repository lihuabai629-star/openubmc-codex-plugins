#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
"""
名字: work_package_symble_table_package.py
功 能: 打包包含符号表的根路径脚本, 该脚本 make ext4 image
版权信息：华为技术有限公司，版本所有(C) 2019-2020
"""

import os
from bmcgo_pro.tasks.task import Task


class TaskClass(Task):
    def __init__(self, config, work_name=""):
        super(TaskClass, self).__init__(config, work_name)
        self.zip_name = "apps.zip"
        inner_path = os.path.dirname(self.config.inner_path)
        if self.config.manufacture_code is not None:
            self.zip_name = f"{self.config.manufacture_code}_{self.zip_name}"
            self.zip_path = f"{inner_path}/{self.config.manufacture_code}"
        elif self.config.tosupporte_code != "default":
            self.zip_name = f"{self.config.tosupporte_code}_{self.zip_name}"
            self.zip_path = f"{inner_path}/{self.config.tosupporte_code}"
        else:
            self.zip_path = f"{inner_path}/{self.config.build_type}"

    def archive_package_info(self):
        self.run_command(f"cp -df {self.config.rootfs_path}/etc/package_info {self.zip_path}")

    def package_symbol_table_package(self):
        conan_install = os.path.join(self.config.build_path, "conan_install")
        if os.path.exists(conan_install) is False:
            raise FileExistsError(f"{conan_install} 文件夹不存在, 无法打包文件")
        os.makedirs(self.zip_path, exist_ok=True)
        # 这样打包, 保证解压的时候不会有很多目录
        zip_package = os.path.join(self.zip_path, self.zip_name)
        if os.path.exists(zip_package):
            os.unlink(zip_package)
        # 删除所有 include 目录并打包
        for root, dirs, _ in os.walk(conan_install):
            for dire in dirs:
                dir_name = os.path.join(root, dire)
                if "include" in dir_name and os.path.isdir(dir_name):
                    self.run_command(f"rm -rf {dir_name}")
        os.chdir(self.config.build_path)
        self.run_command(f"zip -rq -1 {zip_package} conan_install")

    def run(self):
        self.package_symbol_table_package()
        self.archive_package_info()
