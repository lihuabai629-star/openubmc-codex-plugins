#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
"""
功 能：制作bma升级文件 bma_image.zip
版权信息：华为技术有限公司，版本所有(C) 2019-2023
"""

import os
import shutil
import zipfile

from bmcgo_pro.utils.config import Config
from bmcgo_pro.tasks.task import Task


class TaskClass(Task):
    def __init__(self, config: Config, work_name=""):
        super(TaskClass, self).__init__(config, work_name=work_name)
        self.download_conf = None
        self.bma_image_conf = None
        # 构建bma_image的工作目录
        self.build_path = os.path.join(self.config.build_path, "bma_image_build")
        os.makedirs(self.build_path, exist_ok=True)
        self.chdir(self.build_path)

    def run(self):
        # 制作生产装备必须使用-z选项配置0502编码
        if self.config.manufacture_code is None:
            self.info("因为 manufacture 中相关配置为空, 跳过打包 bma_image.zip !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            return

        self._config_set()
        self.chdir(self.config.code_path)
        shutil.rmtree(self.build_path)

    def _config_set(self) -> bool:
        self.info("开始打包 bma_image.zip ======================================================================>>")
        manu_path = "manufacture/" + self.config.manufacture_code
        self.bma_image_conf = self.get_manufacture_config(manu_path + "/bma_image")
        self.download_conf = self.get_manufacture_config(manu_path + "/download")
        # 如果没有配置，则直接返回False
        if self.bma_image_conf is None:
            self.info("manifest.yml中缺少属性: {}, 跳过构建 bma_image.zip".format(
                manu_path + "/bma_image"))
            return

        # 复制bma_image/files下的文件
        bma_image_files = self.get_manufacture_config(manu_path + "/bma_image/files")
        self.copy_manifest_files(bma_image_files)

        self.info(f"bma 构建工作路径: {self.build_path}")

        ibma_upgrade_name_zip = ""
        files = os.listdir(self.build_path)
        for f in files:
            if "aarch64.zip" in f and "iBMA" in f:
                self.info(f"找到 bma 前置压缩包升级文件, 文件名为: {f}")
                ibma_upgrade_name_zip = f
        if ibma_upgrade_name_zip == "":
            return
        os.makedirs(f"{self.build_path}/bma_image", exist_ok=True)
        zip_temp = zipfile.ZipFile(ibma_upgrade_name_zip)
        zip_temp.extractall(f"{self.build_path}")
        zip_temp.close()

        files = os.listdir(f"{self.build_path}")
        for f in files:
            if "aarch64.tar.gz.cms" in f:
                shutil.move(f"{self.build_path}/{f}", f"{self.build_path}/bma_image/bma_image.tar.gz.cms")
            elif "aarch64.tar.gz.crl" in f:
                shutil.move(f"{self.build_path}/{f}", f"{self.build_path}/bma_image/bma_image.tar.gz.crl")
            elif "aarch64.tar.gz" in f:
                shutil.move(f"{self.build_path}/{f}", f"{self.build_path}/bma_image/bma_image.tar.gz")
        self.run_command(f"zip -rq bma_image.zip bma_image")
        self.link("bma_image.zip", os.path.join(self.config.work_out, "bma_image.zip"))

        self.info("打包 bma_image.zip 完成=====================================================================>>")