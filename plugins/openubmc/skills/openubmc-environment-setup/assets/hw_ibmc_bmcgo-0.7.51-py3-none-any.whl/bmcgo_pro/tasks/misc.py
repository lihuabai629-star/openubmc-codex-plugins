#!/usr/bin/env python3
# Copyright (c) Huawei Technologies Co., Ltd. 2024. All rights reserved.

HI171X_MODULE_SYMVERS = "Module.symvers"
HI171X_SDK_PATH = "/opt/hi171x_sdk"
BUILD_TOOLS_SHA256_PATH = "/opt/buildtools.sha256"
SDK_SHA256_PATH = "/opt/sdk.sha256"
RTOS_DIST_SHA256_PATH = "/opt/rtos_dist.sha256"
