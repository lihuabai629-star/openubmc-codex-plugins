#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.

'''
功    能：转换平台srcbaseline.xml 为manifest格式xml
版权信息：华为技术有限公司，版本所有(C) 2022-2023
修改记录：2022-08-22 创建
'''
import os

from bmcgo import errors

from bmcgo_pro.tasks.task import Task
from bmcgo_pro.functional.download_from_cmc_srcbaseline import BmcgoCommand as DownloadFromSrcBaseLine


class TaskClass(Task):
    """
    转换平台srcbaseline.xml 为manifest格式xml
    """
    def __init__(self, config, work_name=""):
        """初始化
        Args:
            config (_type_): _description_
            work_name (str, optional): _description_. Defaults to "".
        """
        super(TaskClass, self).__init__(config, work_name)
        self.artifactory = ""
        self.xml_path = ""

    def set_artifactory(self, artifactory):
        self.artifactory = artifactory

    def set_xml_path(self, xml):
        self.xml_path = os.path.join(self.config.code_path, xml)
        if not self.config.manifest_sdk_flag and os.path.isdir(self.config.temp_platform_build_dir):
            self.xml_path = os.path.join(self.config.temp_platform_build_dir, xml)

    def run(self):
        if self.artifactory is None or self.artifactory not in ("SDK", "RTOS"):
            raise errors.ConfigException("二进制仓错误, 必须为 SDK 或 RTOS")
        if self.xml_path is None or not self.xml_path.endswith(".xml"):
            raise errors.ConfigException(f"xml({self.xml_path})路径错误")
        argv = ["-p", self.artifactory, "-x", self.xml_path]
        if self.config.from_source:
            argv.append("-s")
        dfsbl = DownloadFromSrcBaseLine(self.config.bconfig, argv)
        dfsbl.run()
