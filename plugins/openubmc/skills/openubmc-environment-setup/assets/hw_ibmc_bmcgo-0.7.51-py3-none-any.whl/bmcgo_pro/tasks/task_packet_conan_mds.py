#!/usr/bin/env python
# coding:utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2022-2024. All rights reserved.
 
"""
文件名：task_packet_conan_mds.py
功能：打包单板组件mds
版权信息：华为技术有限公司，版本所有(C) 2020-2021
"""
import os
import json5
from bmcgo import misc
from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.tasks.task import Task
from bmcgo_pro.utils.config import Config

tool = Tools()


class TaskClass(Task):
    def __init__(self, config: Config, work_name=""):
        super(TaskClass, self).__init__(config, work_name)
        self.dest_mds_dir = os.path.join(self.config.build_path, "comp_mds_dir")
        self.mds_zip_name = "mds.zip"
        inner_path = os.path.dirname(self.config.inner_path)
        if self.config.manufacture_code is not None:
            self.mds_zip_name = f"{self.config.manufacture_code}_{self.mds_zip_name}"
            self.mds_zip_path = f"{inner_path}/{self.config.manufacture_code}"
        elif self.config.tosupporte_code != "default":
            self.mds_zip_name = f"{self.config.tosupporte_code}_{self.mds_zip_name}"
            self.mds_zip_path = f"{inner_path}/{self.config.tosupporte_code}"
        else:
            self.mds_zip_path = f"{inner_path}/{self.config.build_type}"

    def is_self_developed(self, comp_source_path: str):
        ret = self.run_command(f"find {comp_source_path} -name 'conanbase.py'", capture_output=True)
        return bool(ret.stdout)

    def check_field_exists_in_json5(self, file_path, field_name):
        try:
            # 读取JSON文件
            with open(file_path, 'r', encoding='utf-8') as file:
                data = json5.load(file)
            # 检查字段是否存在,并返回字段value
            if field_name in data:
                return data[field_name]
            else:
                return None
        except json5.JSON5DecodeError:
            self.error(f"{file_path}不是json格式")
        except FileNotFoundError:
            self.error("文件未找到:{file_path}")
        except Exception as e:
            self.error(f"发生错误: {e}")
        return None

    def copy_conan1_mds_dir(self, reps):
        for component_name, component_pkg in reps.items():
            pkg_dir = component_pkg.replace("@", "/")
            comp_code_dir = os.path.join(os.environ["HOME"], ".conan/data", pkg_dir, "source")
            if not self.is_self_developed(comp_code_dir):
                continue                
            comp_mds_dir = os.path.join(comp_code_dir, "mds")
            if not os.path.exists(comp_code_dir):
                self.info(f"{comp_code_dir} 源码路径不存在")
                continue
            # 压缩目录
            mds_dir = os.path.join(self.dest_mds_dir, component_name)
            # 只打包组件service.json中type字段为application的 组件的MDS文件，不存在service.json 不打包。
            comp_service_json_path = os.path.join(comp_mds_dir, "service.json")
            if os.path.exists(comp_service_json_path):
                field_name = "type"
                field_value = self.check_field_exists_in_json5(comp_service_json_path, field_name)
                if field_value == "application":
                    self.tools.check_path(mds_dir)
                    self.run_command(f"cp -r {comp_mds_dir} {mds_dir}")
            # mdb_interface 额外打包 json 目录
            if component_name == "mdb_interface":
                self.tools.check_path(mds_dir)
                comp_json_dir = os.path.join(comp_code_dir, "json")
                self.run_command(f"cp -r {comp_json_dir} {mds_dir}")
            # vpd 组件额外打包 vendor 目录，包含event_def.json
            if component_name == "vpd":
                self.tools.check_path(mds_dir)
                comp_vendor_dir = os.path.join(comp_code_dir, "vendor")
                self.run_command(f"cp -r {comp_vendor_dir} {mds_dir}")

    def copy_conan2_mds_dir(self):
        # 遍历conan_install
        mds_source_dir = self.conan_install
        for entry in os.scandir(mds_source_dir):
            # 检查是否是目录
            if not entry.is_dir():
                continue
            target_path = os.path.join(entry.path, "usr", "share", "doc", "openubmc", entry.name, "mds")
            # 检查mds目录存在性以及service.json的type字段
            if os.path.exists(target_path):
                service_json_path = os.path.join(target_path, "service.json")
                field_name = "type"
                field_value = self.check_field_exists_in_json5(service_json_path, field_name)
                if field_value != "application":
                    continue
                # 创建目标目录
                target_dir = os.path.join(self.dest_mds_dir, entry.name)
                self.tools.check_path(target_dir)
                self.run_command(f"cp -r {target_path} {target_dir}")

    def copy_extra_dir(self, reps, comp_name, extra_dir):
        # 复制额外的目录到mds目录下
        pkg = reps.get(comp_name)
        if pkg is not None:
            recipe_dir = tool.get_conan2_recipe_path(pkg)
            if recipe_dir is not None:
                source_dir = os.path.join(recipe_dir, "..", "s", extra_dir)
                if not os.path.exists(source_dir):
                    self.info(f"{source_dir} 路径不存在")
                    return
                target_dir = os.path.join(self.dest_mds_dir, comp_name)
                self.tools.check_path(target_dir)
                self.run_command(f"cp -r {source_dir} {target_dir}")

    def run(self):
        # 非源码构建不会执行该任务
        if not self.config.from_source:
            self.info("非源码构建跳过 mds 打包")
            return
        self.info("packet mds start ==============>>>")
        reps = self.get_manufacture_config("dependencies")
        develop_packages = {}
        for rep in reps:
            rep = rep.get("conan")
            comp_name = rep.split("/")[0]
            develop_packages[comp_name] = rep
        if misc.conan_v1():
            self.copy_conan1_mds_dir(develop_packages)
        if misc.conan_v2():
            self.copy_conan2_mds_dir()
            self.copy_extra_dir(develop_packages, "vpd", "vendor")
            self.copy_extra_dir(develop_packages, "mdb_interface", "json")

        # 压缩到inner目录
        os.makedirs(self.mds_zip_path, exist_ok=True)
        mds_zip_package = os.path.join(self.mds_zip_path, self.mds_zip_name)
        os.chdir(self.dest_mds_dir)
        self.run_command(f"zip -r -1 {mds_zip_package} .")
        self.info("packet mds end ==============<<<")
