#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
"""
功 能：buildimg_ext4脚本，该脚本 make ext4 image
版权信息：华为技术有限公司，版本所有(C) 2019-2020
"""

import os

from bmcgo.tasks.task_packet_to_supporte import TaskClass as BingoPacketSupporte

from bmcgo_pro.tasks.task import Task
from bmcgo_pro.utils.config import Config


class TaskClass(Task, BingoPacketSupporte):
    def __init__(self, config: Config, work_name=""):
        super().__init__(config, work_name)

    def zip_mib(self, package_name, mib_name):
        mib_path = os.path.join(self.config.rootfs_path, "opt/bmc/apps/snmp/mib", mib_name)
        if not os.path.exists(mib_path):
            mib_path = os.path.join(
                self.config.rootfs_path,
                "opt/bmc/apps/snmp/interface_config/mib",
                mib_name
            )
            if not os.path.exists(mib_path):
                return False
        # 获取MIB归档压缩包文件名称
        zip_name = package_name.replace(".zip", "_MIB.zip")
        cmd = "zip -1 -rqmj {} {}".format(zip_name, mib_path)
        self.run_command(cmd)
        return True

    def package_mib(self, build_path, package_name, target_dir):
        self.chdir(build_path)
        ret = self.zip_mib(package_name, "HUAWEI-SERVER-iBMC-MIB.mib")
        if not ret:
            self.info(f"HUAWEI-SERVER-iBMC-MIB.mib not exist")
        ret = self.zip_mib(package_name, "OPENUBMC-SERVER-MIB.mib")
        if not ret:
            self.info(f"OPENUBMC-SERVER-MIB.mib not exist")
        zip_name = package_name.replace(".zip", "_MIB.zip")
        if os.path.isfile(zip_name):
            self.link(zip_name, os.path.join(target_dir, zip_name))
