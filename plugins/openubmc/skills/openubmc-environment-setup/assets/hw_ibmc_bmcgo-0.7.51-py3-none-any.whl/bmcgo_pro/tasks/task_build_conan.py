#!/usr/bin/env python
# coding=utf-8
# Copyright © Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.

"""
文件名：work_build_conan.py
功能：编译产品依赖包
版权信息：华为技术有限公司，版本所有(C) 2019-2020
"""

import os
import re
import shutil
import pathlib
import stat

from bmcgo import errors

from bmcgo.tasks.task_build_conan import TaskClass as BingoBuildConanTask
from bmcgo_pro.utils.fetch_component_code import FetchComponentCode


class TaskClass(BingoBuildConanTask):
    # 当前软件包的组件依赖列表
    depdencies = []

    def merge_dep_options(self):
        super().merge_dep_options()
        self.enable_1712_option()
        self.merge_qemu_options()

    def enable_1712_option(self):
        if self.config.chip == "1712":
            self.board_option += f" -o *:chipv2_enable=True"

    def merge_qemu_options(self):
        if self.config.enable_qemu:
            self.success(f"添加qemu=True的options成功!")
            self.board_option += f" -o *:qemu=True"

    def install_luac_or_luajit(self):
        """安装luac或luajit工具"""
        conan_bin = os.path.join(self.conan_home, "bin")
        self._setup_environment(conan_bin)
        
        if self._should_skip_installation():
            return
            
        skynet_pkg = self._find_skynet_dependency()
        self._install_skynet_with_lock(conan_bin, skynet_pkg)

    def run(self):
        if self.config.with_strip:
            profile = os.path.join(self.tools.conan_profiles_dir, self.config.profile)
            self.modify_profile_file(profile)
            self.modify_profile_file(os.path.join(self.tools.conan_profiles_dir, "profile.dt.ini"))
        super().run()
        if ("CLOUD_BUILD_RECORD_ID" in os.environ and "artifactVersionForZip" in os.environ):
            self._package_manifest_xml()

    def modify_profile_file(self, filename):
        with open(filename, 'r') as file:
            lines = file.readlines()
        pattern = re.compile(r'^LDFLAGS=')
        with open(filename, 'w') as file:
            for line in lines:
                match = pattern.match(line)
                if match:
                    # 移除行尾换行符，添加 ",-s" 和换行符
                    new_line = line.rstrip() + ',-s\n'
                    file.write(new_line)
                else:
                    file.write(line)

    def _package_manifest_xml(self):
        with open(self.package_info, "r") as fp:
            lines = fp.readlines()
        packages = {}
        for line in lines:
            line = line.strip()
            com_name = line.split("/")[0]
            if com_name == "ibmc_sdk":
                continue
            packages[com_name] = line
        code_path = os.path.join(self.config.temp_path, "manifest_xml")
        fetch = FetchComponentCode(packages, code_path, self.config.remote, True, True)
        fetch.run()

    def _setup_environment(self, conan_bin):
        """设置环境变量和路径"""
        if not os.path.isdir(conan_bin):
            os.makedirs(conan_bin)
        
        # 设置LD_LIBRARY_PATH
        ld_library_path = conan_bin + ":" + os.environ.get("LD_LIBRARY_PATH", "")
        os.environ["LD_LIBRARY_PATH"] = ld_library_path
        
        # 设置PATH
        path = conan_bin + ":" + os.environ.get("PATH", "")
        os.environ["PATH"] = path
        
        # 设置LUA_PATH
        os.environ["LUA_PATH"] = f"{conan_bin}/?.lua"

    def _should_skip_installation(self):
        """检查是否应该跳过安装"""
        return self.config.partner_mode or self.config.build_type == "dt"

    def _find_skynet_dependency(self):
        """查找skynet依赖包"""
        for dep in self.depdencies:
            if dep.startswith("skynet/"):
                return dep
        raise errors.BmcGoException(
            "skynet是必要依赖，未找到正确的skynet包，请确保manifest.yml正确配置skynet"
        )

    def _install_skynet_with_lock(self, conan_bin, skynet_pkg):
        """使用锁机制安装skynet（确保线程安全）"""
        self.config.conan_parallel_lock.acquire()
        try:
            self._install_skynet_safely(conan_bin, skynet_pkg)
        finally:
            self.config.conan_parallel_lock.release()

    def _install_skynet_safely(self, conan_bin, skynet_pkg):
        """安全地安装skynet（在锁保护下执行）"""
        luac, luac_back, skynet_flag = self._get_tool_paths(conan_bin, skynet_pkg)
        
        if self._is_skynet_already_installed(skynet_flag, luac_back):
            self.link(luac_back, luac)
        else:
            self._clean_install_skynet(conan_bin, skynet_pkg)
            self.link(luac, luac_back)
        
        self._setup_luac_tools(luac, conan_bin)
        self._create_installation_flag(skynet_flag)

    def _get_tool_paths(self, conan_bin, skynet_pkg):
        """获取工具路径和配置标志"""
        skynet_flag_base = skynet_pkg.split("@")[0].replace("/", "_")
        skynet_flag = os.path.join(conan_bin, skynet_flag_base)
        
        if self.config.enable_luajit:
            luac = f"{conan_bin}/luajit"
            luac_back = f"{conan_bin}/luajit_back"
            skynet_flag += "_luajit"
        else:
            luac = f"{conan_bin}/luac"
            luac_back = f"{conan_bin}/luac_back"
            skynet_flag += "_luac"
        
        return luac, luac_back, skynet_flag

    def _is_skynet_already_installed(self, skynet_flag, luac_back):
        """检查skynet是否已经安装"""
        return os.path.isfile(skynet_flag) and os.path.isfile(luac_back)

    def _clean_install_skynet(self, conan_bin, skynet_pkg):
        """清理并重新安装skynet"""
        if os.path.isdir(conan_bin):
            shutil.rmtree(conan_bin)
        os.makedirs(conan_bin)
        
        options = "-o skynet:enable_luajit=True" if self.config.enable_luajit else ""
        cmd = f"conan install {skynet_pkg} -pr profile.dt.ini --build {options}"
        
        if self.config.remote:
            cmd += f" -r {self.config.remote}"
        
        self.run_command(cmd)

    def _setup_luac_tools(self, luac, conan_bin):
        """设置luac相关工具"""
        # 覆盖率打桩
        if self.config.enable_arm_gcov:
            self.prepare_luac_for_luacov(luac)
        
        # 设置执行权限
        os.chmod(luac, stat.S_IRWXU)
        
        # 如果是luajit，复制转换脚本
        if self.config.enable_luajit:
            self._copy_luajit_conversion_script(conan_bin)

    def _copy_luajit_conversion_script(self, conan_bin):
        """复制luajit转换脚本"""
        luajit2luac = shutil.which("luajit2luac.sh")
        if luajit2luac:
            cmd = f"cp {luajit2luac} {conan_bin}/luac"
            self.run_command(cmd)

    def _create_installation_flag(self, skynet_flag):
        """创建安装标志文件"""
        pathlib.Path(skynet_flag).touch(0o600, exist_ok=True)
