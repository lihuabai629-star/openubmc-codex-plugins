#!/usr/bin/env python
# coding=utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.

"""
文件名：buildhpm_ext4.py
功能：编译生成 hpm 包
输入参数：板名 board_name
调用方法：python3 -B buildhpm_ext4.py -b board_name -l support_list(-l 可选)
版权信息：华为技术有限公司，版本所有(C) 2019-2020
"""

from bmcgo.tasks.task_buildhpm_ext4 import TaskClass as BingoBuildhpmExt4


class TaskClass(BingoBuildhpmExt4):
    def __init__(self, config, work_name=""):
        super(TaskClass, self).__init__(config, work_name)
