#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.

'''
功    能：
版权信息：华为技术有限公司，版本所有(C) 2021
修改记录：2021-10-11 创建
'''
import os
import shutil
import time

from bmcgo.tasks.misc import MODULE_SYMVERS, SDK_PATH
from bmcgo.tasks.task_download_dependency import TaskClass as BingoDownloadDependency

from bmcgo_pro.tasks.task import Task
from bmcgo_pro.utils.swbom import SWBom
from bmcgo_pro.utils.artget_tools import ArtgetToolUtil, ArtgetDownloadTool


class TaskClass(Task, BingoDownloadDependency):
    def __init__(self, config, work_name=""):
        super().__init__(config, work_name)
        self.sdk_dir = f"{self.config.tools_path}/sdk"
        self.download_file_old_sha256 = f"{self.config.tools_path}/sdk_download_file_old.sha256"
        self.download_file_new_sha256 = f"{self.config.tools_path}/sdk_download_file_new.sha256"
        self.sdk_new_sha256 = f"{self.config.tools_path}/sdk_new.sha256"
        self.skip_download = False
        self.skip_install = False

    def download_from_source_mode(self):
        self.info('使用本地平台文件')
        # 全量源码使用, 等待sdk part1完成
        share_path = os.path.join(self.config.code_root, "share_path/platforms/platform_v6")
        sdk_file_path = os.path.join(share_path, "hi1711sdk.tar.gz")
        if self.config.chip == "1712":
            sdk_file_path = os.path.join(share_path, "Hi1712_SDK.tar.gz")
        cnt = 0
        while not os.path.exists(sdk_file_path):
            self.log.info("正在等待: {}, 当前已等待 {} 秒".format(sdk_file_path, cnt))
            time.sleep(5)  # 等待5秒
            cnt += 5
        shutil.copytree(share_path, self.sdk_dir, symlinks=True,
                        ignore_dangling_symlinks=True, dirs_exist_ok=True)

    def download_dependency(self):
        if self.config.source_mode is not None:
            path = os.path.realpath(os.path.join(self.config.code_path, "rtos_sdk/sdk/srcbaseline.xml"))
            self.download_from_source_mode()
        else:
            rtos_sdk = self.get_manufacture_config("base/rtos_sdk", "rtos_sdk/sdk/software.xml")
            path = os.path.realpath(os.path.join(self.config.code_path, rtos_sdk))
            self.skip_download = not self.check_need_download(
                path, self.download_file_old_sha256, self.download_file_new_sha256
            )
            if self.skip_download and self.config.sdk_debug_dir == "":
                self.info("sdk下载文件未变更, 跳过下载")
                return
            self.info('开始下载依赖组件 ...')
            self.info(f"移除下载路径: {self.sdk_dir}")
            self.run_command(f"rm -rf {self.sdk_dir}", ignore_error=True, sudo=True)
            self.run_command(f"rm -rf {self.download_file_old_sha256}", ignore_error=True, sudo=True)
            partner_sdk_dir = f"{os.path.expanduser('~')}/sdk"
            if self.config.sdk_debug_dir:
                self.info(f"使用本地联调的sdk文件")
                self.run_command(f"cp -rf {self.config.sdk_debug_dir}/. {self.sdk_dir}")
            elif self.config.partner_mode:
                self.info(f"从缓存目录{partner_sdk_dir}复制sdk和rtos二进制文件")
                self.run_command(f"cp -rf {partner_sdk_dir}/. {self.sdk_dir}")
            else:
                artget_sdk = ArtgetDownloadTool(path, self.sdk_dir)
                artget_sdk.download()
                if os.path.isdir(partner_sdk_dir):
                    shutil.rmtree(partner_sdk_dir)
                # 非partner模式复制RTOS和SDK二进制，以备伙伴模式使用
                self.run_command(f"cp -rf {self.sdk_dir}/. {partner_sdk_dir}")
                self.run_command(f"cp -af {self.download_file_new_sha256} {self.download_file_old_sha256}")
        # RTOS_SDK版本信息并复制xml文件到inner目录
        hpm_package_info = {
            "RTOS_SDK": os.path.basename(path)
        }
        inner_software_path = os.path.join(self.config.inner_path, os.path.basename(path))
        self.link(path, inner_software_path)
        ArtgetToolUtil.remove_file_verify_element(inner_software_path)

        swbom_file = f"{self.config.inner_path}/hpm_info_{self.config.board_name}.yml"
        swbom = SWBom(swbom_file)
        swbom.write(hpm_package_info)

        self.success('下载依赖组件结束')

    # 重写前置安装阶段
    def prepare_dependency(self):
        # 移动到构建目录中
        self.tools.remove_path_and_create(self.config.sdk_path, force=True)
        self.run_command(f"cp -rf {self.sdk_dir}/. {self.config.sdk_path}")
        self.chdir(self.config.sdk_path)
        if self.config.chip == "1712":
            self.pipe_command(["find . -name 'Hi1712_SDK*.tar.gz' -type f", "xargs tar -xzf"])
            # 生成1712 hiboot为cms加密的hibmc包
            self._generate_1712_all_cms_hiboot_image()

    # 重写解压sdk逻辑
    def unzip_sdk(self):
        self.info("解压 hi171x_sdk")
        self.run_command(f"mkdir -p {SDK_PATH}", ignore_error=True, sudo=True)
        if os.path.isfile("Module.symvers"):
            self.run_command(f"cp Module.symvers {SDK_PATH}", sudo=True)
        elif self.config.chip == "1712":
            self.run_command(f"cp drivers/Module.symvers {SDK_PATH}", sudo=True)
        else:
            self.run_command(f"tar -xzf hi1711sdk.tar.gz -C {SDK_PATH} {MODULE_SYMVERS}", sudo=True)

    def _generate_1712_all_cms_hiboot_image(self):
        # 遍历目录寻找匹配的文件对
        boot_dir = os.path.join(self.config.sdk_path, "boot", "packeted")
        for file in os.listdir(boot_dir):
            # 匹配hibmc文件
            if file.startswith("hibmc_core_sec_boot") and file.endswith(".bin"):
                # 提取签名类型和debug标志
                parts = file[len("hibmc_core_sec_boot"):-len(".bin")].split("_")

                if "rsa" in parts:
                    hibmc_signature_encrypt_flag = "_rsa"
                    hiboot_signature_flag = ""
                if "aes" in parts:
                    hibmc_signature_encrypt_flag = "_rsa_aes"
                if "sm2" in parts:
                    hibmc_signature_encrypt_flag = "_sm2"
                    hiboot_signature_flag = "_sm2"
                if "sm4" in parts:
                    hibmc_signature_encrypt_flag = "_sm2_sm4"

                if "debug" in file:
                    hibmc_debug_flag = "_debug"
                elif "factory" in file:
                    hibmc_debug_flag = "_factory"
                else:
                    hibmc_debug_flag = ""
                
                # 构建对应的hiboot文件名
                hiboot_file = f"hiboot{hiboot_signature_flag}_cms{hibmc_debug_flag}.bin"
                hiboot_path = os.path.join(boot_dir, hiboot_file)
                
                # 检查hiboot文件是否存在且签名类型一致
                if os.path.exists(hiboot_path):
                    hibmc_path = os.path.join(boot_dir, file)
                    output_file = (
                        f"hibmc_core_sec_boot{hibmc_signature_encrypt_flag}"
                        f"{hibmc_debug_flag}_{hiboot_file}"
                    )
                    
                    # 执行合并操作
                    self.info(f"合并文件: {file} 和 {hiboot_file} 生成 {output_file}")
                    self.run_command(f"dd if=/dev/zero of={output_file} bs=1M count=2")
                    self.run_command(
                        f"dd if={hibmc_path} of={output_file} bs=1K count=1536 conv=notrunc"
                    )
                    self.run_command(
                        f"dd if={hiboot_path} of={output_file} bs=1K seek=1536 conv=notrunc"
                    )
