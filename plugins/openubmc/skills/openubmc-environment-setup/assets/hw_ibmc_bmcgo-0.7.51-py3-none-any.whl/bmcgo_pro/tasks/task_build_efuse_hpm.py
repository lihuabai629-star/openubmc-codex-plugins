#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
"""
功 能：work_create_customize_efuse_pkg.py脚本 -- 用于生成天池产品efuse包
版权信息：华为技术有限公司，版本所有(C) 2023
"""

import os
import shutil
import subprocess

from bmcgo_pro.tasks.task import Task


class TaskClass(Task):
    def __init__(self, config, work_name=""):
        super(TaskClass, self).__init__(config, work_name=work_name)

    def generate_efuse_hpm(self):
        # 根据manifest.yml中的efuse_hpm对象生成对应的efuse hpm包
        manu_path = "manufacture/" + self.config.manufacture_code
        # 如果不存在efuse_hpm对象，退出构建
        efuse_hpm_conf = self.get_manufacture_config(manu_path + "/efuse_hpm")
        if efuse_hpm_conf is None:
            self.info("跳过构建 efuse hpm 包, 在 manifest.yml 中, 没有找到 {} 属性".format(
                manu_path + "/efuse_hpm"))
            return
        # 创建efuse_packet目录
        efuse_path = os.path.join(self.config.hpm_build_dir, "efuse_packet")
        shutil.rmtree(efuse_path, ignore_errors=True)
        os.makedirs(efuse_path, exist_ok=True)
        # 创建临时构建目录
        build_path = os.path.join(efuse_path, "build")
        os.makedirs(build_path, exist_ok=True)
        # 切换到打包目录
        self.chdir(build_path)
        self.info(f"构建 efuse hpm 包, 工作目录: {build_path}")

        # 复制manifest.yml中配置的文件
        files = self.get_manufacture_config(manu_path + "/efuse_hpm/files")
        self.copy_manifest_files(files)

        # 生成efuse.bin文件
        # 适配1712 efuse
        if self.config.chip == "1712":
            self.run_command(f"efuse_tool_1712 28 efuse.txt")
        else:
            self.run_command(f"efuse_tool 28 efuse.txt")

        # 比较生成的efuse.bin的hash值是否与manifest.yml中配置的hash值匹配，不匹配就终止构建。
        sha256 = self.get_manufacture_config(manu_path + "/efuse_hpm/sha256")
        sha256sum = shutil.which("sha256sum")
        cmd = [sha256sum, "efuse.bin"]
        efuse_bin_hash = subprocess.run(cmd, capture_output=True).stdout.decode().strip('\n').split(" ")[0]
        if sha256 is None or sha256 != efuse_bin_hash:
            self.error(f"Efuse 二进制 sha256 值检查失败, efuse_bin_hash={efuse_bin_hash}, expect_hash={sha256}")
            shutil.rmtree(build_path)
            raise Exception(f"Efuse 二进制 sha256 值检查失败, efuse_bin_hash={efuse_bin_hash}, expect_hash={sha256}")

        # 生成hpm文件
        self.run_command(f"/bin/bash {build_path}/packetefuse.sh efuse.bin")

        # 生成.filelist文件
        self.run_command("cms_sign_hpm.sh 1 efuse-crypt-image.hpm")

        # 指定签名证书的使用自签名证书签名
        if self.config.self_sign:
            # 如果是伙伴模式，则复制预置的cms_hpm.crl作为签名文件，并复制cms
            self.signature("efuse-crypt-image.filelist", "efuse-crypt-image.filelist.cms", "cms.crl", "rootca.der")
        else:
            # 从单板配置目录复制签名配置
            self.run_command(f"cp {self.config.board_path}/sign_hpm.xml sign_efuse.xml")

            # 替换sign_efuse.xml中路径
            self.tools.py_sed("sign_efuse.xml", "(?<=path=\").*(?=\")", build_path)
            self.tools.py_sed("sign_efuse.xml", "(?<=<crlfile>).*(?=</crlfile>)", f"{build_path}/crldata.crl")
            # 正常签名模式
            self.run_command("java -jar /usr/local/signature-jenkins-slave/signature.jar sign_efuse.xml")
            self.run_command("cp crldata.crl cms.crl")
        self.run_command("cms_sign_hpm.sh 2 efuse-crypt-image.hpm")

        # 结果处理，移动hpm到目标，删除临时构建文件夹
        shutil.move("efuse-crypt-image.hpm.signed", f"{self.config.work_out}/efuse-crypt-image.hpm")
        self.chdir(self.config.temp_path)
        shutil.rmtree(build_path)

    def run(self):
        if self.config.manufacture_code is None:
            self.info("跳过构建 efuse hpm, 因为 manufacture 配置为空 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            return

        self.info(f"构建 {self.config.board_name} 的 efuse hpm 包 ------------> [开始]")
        self.generate_efuse_hpm()
        self.info(f"构建 {self.config.board_name} 的 efuse hpm 包 ------------> [结束]")
