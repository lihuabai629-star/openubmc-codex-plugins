#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024. All rights reserved.
"""
功 能：还原rootfs_BMC.img
版权信息：华为技术有限公司，版本所有(C) 2024
"""

import argparse
import sys

from bmcgo_pro.utils.config import Config
from bmcgo_pro.tasks.task import Task
from bmcgo_pro.tasks.task_build_rootfs_img import TaskClass as BuildRootfsImage


class TaskClass(Task):
    def __init__(self, config: Config, work_name=""):
        super(TaskClass, self).__init__(config, work_name)
        parser = argparse.ArgumentParser(
            description="准备rootfs_BMC.img", formatter_class=argparse.RawTextHelpFormatter
        )
        parser.add_argument("--rootfs_img", help="rootfs_iBMC.img路径", required=True)
        parsed_args, _ = parser.parse_known_args(sys.argv)
        self.rootfs_img = parsed_args.rootfs_img

    def make_rootfs_img(self):
        build_rootfs_img = BuildRootfsImage(self.config, "build_rootfs_img")
        build_rootfs_img.set_evn()

        self.run_command(f"cp -f {self.rootfs_img} {build_rootfs_img.rootfs_img_path}")
        self.run_command(f"mount {build_rootfs_img.rootfs_img_path} {build_rootfs_img.rtos_rootfs}", sudo=True)
        build_rootfs_img.copy_upgrade_dat_file()
 
        self.tools.umount_datafs(build_rootfs_img.rtos_rootfs)
        build_rootfs_img.post_make_rootfs_img()

    def run(self):
        self.make_rootfs_img()
