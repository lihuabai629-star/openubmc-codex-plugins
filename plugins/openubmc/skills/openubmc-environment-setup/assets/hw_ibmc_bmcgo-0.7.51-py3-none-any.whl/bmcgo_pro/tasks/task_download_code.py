#!/usr/bin/env python
# coding:utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2022-2024. All rights reserved.

"""
文件名：envir_prepare.py
功能：打包目录形成
版权信息：华为技术有限公司，版本所有(C) 2020-2021
"""
import os
import shutil

from bmcgo_pro.tasks.task import Task


class TaskClass(Task):
    def run(self):
        mm_path = "/usr/sbin/git-mm"
        if not os.path.isfile(mm_path):
            self.info("下载 git-mm")
            self.chdir(self.config.temp_path)
            self.run_command("wget https://cmc-szver-artifactory.cmc.tools.huawei.com/artifactory/" +
                             "cmc-software-release/CodeHub/git-mm/0.0/2.6.3/linux64/git-mm --no-check-certificate")
            self.run_command("cp git-mm " + mm_path, sudo=True)
            self.run_command("chmod a+x " + mm_path, sudo=True)
        self.__download("code")
        self.__download("opensource")
        self.__download("vendor")

    def __download(self, name):
        xml_name = name + ".xml"
        self.info("开始下载 " + xml_name)
        src_manifst = os.path.join(self.config.code_root, "manifest", "iBMC300", xml_name)
        sources_path = os.path.join(self.config.temp_path, "all_source")
        code_path = os.path.join(sources_path, name)
        shutil.rmtree(code_path, ignore_errors=True)
        os.makedirs(code_path)
        self.chdir(code_path)
        shutil.copyfile(src_manifst, name + ".xml")
        self.run_command("git init .")
        self.run_command("git add -A")
        self.run_command("git commit -m \"init\"")
        self.run_command("git mm init -u . -m " + xml_name)
        self.run_command("git mm sync -j8", show_log=True)