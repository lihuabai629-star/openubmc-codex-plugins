#!/usr/bin/python3
# -*- coding: UTF-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.

'''
功    能：
版权信息：华为技术有限公司，版本所有(C) 2025
修改记录：2025-1-9 创建
'''
import os
import shutil
import time
import re

from bmcgo import errors

from bmcgo_pro.tasks.task import Task


class TaskClass(Task):
    def run(self):
        if self.config.source_mode is not None and self.config.chip == "1711":
            # 全量源码使用, 等待sdk part2完成
            share_path = os.path.join(self.config.code_root, "share_path/platforms/platform_v6")
            finish_file = os.path.join(share_path, "sdk_finished.txt")
            rtos_tar = os.path.join(self.config.sdk_path, "rtos.tar.gz")
            cnt = 0
            while not os.path.exists(finish_file):
                self.log.info("正在等待: {}, 当前已等待 {} 秒".format(finish_file, cnt))
                time.sleep(5)  # 等待5秒
                cnt += 5
            shutil.copytree(share_path, self.config.sdk_path, symlinks=True,
                            ignore_dangling_symlinks=True, dirs_exist_ok=True)
            if not os.path.exists(rtos_tar):
                raise Exception("找不到 rtos.tar.gz 文件, 构建失败!")
            self.success("移动依赖组件结束")
        self._prepare_sdk()

    def _prepare_sdk(self):
        self.chdir(self.config.sdk_path)
        debug_flag = "_debug" if self.config.build_type == "debug" else ""
        signature_flag = "_rsa" if self.config.signature_type.startswith("rsa") else "_sm2"
        encrypt_flag = "" if not self.config.encrypt_type else f"_{self.config.encrypt_type}"
        src_boot = f"boot/packeted/hibmc_core_sec_boot{signature_flag}{encrypt_flag}{debug_flag}.bin"
        dst_boot = f"{self.config.sdk_path}/Hi1711_boot_4096{debug_flag}.bin"
        if self.config.chip == "1712":
            self.run_command(f"cp -f drivers/sdk_initrd.tar.gz {self.config.sdk_path}")
            self.run_command(f"cp -f drivers/sdk_rootfs.tar.gz {self.config.sdk_path}")
            self.run_command(f"cp -f {src_boot} {dst_boot}")
