#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.

'''
功    能：下载并安装flatbuffers工具
版权信息：华为技术有限公司，版本所有(C) 2022-2022
修改记录：2023-01-29 创建
'''
import os
import shutil
from bmcgo_pro.tasks.task import Task

flatbuffers_url = 'https://cmc-hgh-artifactory.cmc.tools.huawei.com/artifactory/'
flatbuffers_url += 'opensource_general/flatbuffers/2.0.0/package/flatbuffers-2.0.0.tar.gz'
flatbuffers_zip_name = flatbuffers_url[flatbuffers_url.rindex('/') + 1:]
flatbuffers_unzip_name = flatbuffers_zip_name.split('.tar.gz')[0]


class TaskClass(Task):
    def __init__(self, config, work_name=""):
        super(TaskClass, self).__init__(config, work_name)
        self.flatbuffers_dir = os.path.join(self.config.temp_path, "flatbuffers_dir")
        self.flatbuffers_build_dir = os.path.join(self.flatbuffers_dir, flatbuffers_unzip_name, 'build')

    def run(self):
        flatc = shutil.which("flatc")
        if (flatc is not None and not self.config.from_source) or self.config.partner_mode:
            return
        self.info('apt 卸载 ...')
        self.run_command(f"apt autoremove -y flatbuffers-compiler", sudo=True)

        self.info('清理目录 ...')
        shutil.rmtree(self.flatbuffers_dir, ignore_errors=True)

        self.info('开始下载 flatbuffers ...')
        self.tools.check_path(self.flatbuffers_dir)
        os.chdir(self.flatbuffers_dir)
        self.run_command(f"wget --no-check-certificate {flatbuffers_url}")
        self.info('下载 flatbuffers 完成')

        self.info('解压 flatbuffers ...')
        self.run_command(f"tar -xf {flatbuffers_zip_name}")

        self.info('构建并安装 flatbuffers ...')
        self.tools.check_path(self.flatbuffers_build_dir)
        self.chdir(self.flatbuffers_build_dir)
        self.run_command("cmake ..", sudo=True)
        self.run_command("make -j8 install", sudo=True)
        self.info('安装 flatbuffers 结束')
