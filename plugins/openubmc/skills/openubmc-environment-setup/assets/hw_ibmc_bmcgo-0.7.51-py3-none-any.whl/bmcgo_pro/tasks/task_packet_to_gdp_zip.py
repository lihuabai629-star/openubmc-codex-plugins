#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
"""
功 能：制作0502生产装备包
版权信息：华为技术有限公司，版本所有(C) 2019-2023
"""

import os
import shutil
import time

from bmcgo_pro.tasks.task import Task
from bmcgo_pro.utils.file_preprocess import FilePreProcess
from bmcgo_pro.utils.package_swbom_sign import SignFilelist


class TaskClass(Task):
    def run(self):
        if self.config.manufacture_code is None:
            self.info(f"跳过打包 zip 包, 因为 {self.config.manufacture_code} 编码不存在 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            return

        # 要打包的编码的配置
        manu_path = "manufacture/" + self.config.manufacture_code
        # 文件的配置路径以及其名字
        package_name = self.get_manufacture_config(manu_path + "/package_name")
        package_name = time.strftime(package_name, self.config.date)
        self.info("开始打包 ipmc.bin 文件: {}".format(package_name))
        # 获取到文件名
        zip_name = os.path.basename(package_name)
        # 文件名同名目录
        build_path = os.path.join(self.config.build_path, self.config.manufacture_code,
                                  zip_name.replace(".zip", ""))
        self.info("构建 {}, 工作目录: {}".format(package_name, build_path))
        shutil.rmtree(build_path, ignore_errors=True)
        os.makedirs(build_path, exist_ok=True)

        # 切换到打包目录
        self.chdir(build_path)
        # 复制预处理文件
        preprocess_files = self.get_manufacture_config(manu_path + "/file_preprocess")
        filepreprocess = FilePreProcess(self.config, preprocess_files=preprocess_files, build_path=build_path)
        filepreprocess.run()
        # 复制所需文件
        files = self.get_manufacture_config(manu_path + "/files")
        self.copy_manifest_files(files)

        # 生成 xml 文件列表，并签名
        signfilelist = SignFilelist(self.config.board_name, build_path, f"{self.config.board_path}/sign_0502.xml")
        signfilelist.create_filelist()
        if self.config.self_sign:
            self.signature(signfilelist.xml_name, signfilelist.xml_name + ".cms",
                           f"{self.config.board_name}_vercfg.xml.crl", "rootca.der")
        else:
            signfilelist.sign()

        # zip_info 信息不插入到 xml 中
        self.write_ingredient(build_path)
        # 切换工作目录到编码目录下
        self.chdir(os.path.dirname(build_path))
        # 开始打包
        cmd = "zip -1 -rq {} {}".format(zip_name, zip_name.replace(".zip", ""))
        self.run_command(cmd)
        # 组装并新建目标目录
        dirname = os.path.dirname(package_name)
        target_dir = os.path.join(self.config.output_path, "packet", dirname)
        os.makedirs(target_dir, exist_ok=True)
        # 硬链接文件目标目录
        self.link(zip_name, os.path.join(target_dir, zip_name))
        self.chdir(self.config.temp_path)
        shutil.rmtree(os.path.dirname(build_path), ignore_errors=True)
        self.info("打包 ipmc.bin 文件 {} 完成".format(package_name))
