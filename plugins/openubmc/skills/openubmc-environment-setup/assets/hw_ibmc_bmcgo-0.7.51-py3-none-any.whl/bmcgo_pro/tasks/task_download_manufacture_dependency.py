#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.

'''
功    能：依赖manifest
版权信息：华为技术有限公司，版本所有(C) 2023-2025
'''
import os
import time
import fnmatch
from multiprocessing import Process
from bmcgo_pro.tasks.task import Task
from bmcgo_pro.utils.artget_tools import ArtgetDownloadTool
from bmcgo_pro.utils.tools import Tools

tools = Tools()


class TaskClass(Task):
    def artget_pull(self, dependency_file: str, agentpath: str):
        self.info(f"依赖文件: {self.config.ori_board_path}/{dependency_file}"
                     " >>>>>>>>>> artget下载开始")
        artget_dependency = ArtgetDownloadTool(dependency_file, agentpath)
        artget_dependency.download()
        self.info(f"依赖文件: {self.config.ori_board_path}/{dependency_file}"
                     " >>>>>>>>>> artget下载完成")
        # 标记文件已下载成功
        self.run_command("touch {}".format(os.path.join(agentpath, "downloaded")))

    def wget_pull(self, wget_data):
        self.info(">>>>>>>>>> wget下载开始")
        # wget遍历下载所有的 file_url, 并校验sha256sum
        for file in wget_data:
            url, dest, name, checksum = file['file_url'], file['dest'], file['name'], file.get('sha256', None)
            if not os.path.exists(dest):
                os.makedirs(dest, exist_ok=True)
            file_path = os.path.join(dest, name)
            self.run_command(f"wget -O {file_path} {url}")
            if not os.path.exists(file_path):
                self.error(f"{file_path}不存在!")  
            realsum = tools.sha256sum(file_path)
            if checksum is not None and checksum != realsum:
                self.error(f"{name}校验失败")
        self.info(">>>>>>>>>> wget下载完成")

    def download(self):
        self.info('开始下载依赖 sp ibma 文件 ...')
        config = self.get_manufacture_config("manufacture/" + self.config.manufacture_code + "/download")
        if config is None:
            self.info(f"{self.config.manufacture_code} 没有需要下载的依赖文件")
            return

        # 将xml的文件名写入到集合，防止重复下载
        download_file_collection = []
        for conf_file in config:
            artget_file = conf_file.get("xml_file")
            wget_files = conf_file.get("wget_files")
            download_file_collection.append({"xml_file": artget_file, "wget_files": wget_files})

        # 下载目录根据xml文件名字配置
        task_list = []
        self.info(f"下载文件: {download_file_collection}")
        for file_config in download_file_collection:
            file, wget_files = file_config["xml_file"], file_config["wget_files"]
            # 伙伴烧片包依赖文件使用wget下载，需要在单板yml中配置wget_files
            if wget_files is not None:
                t = Process(name="download_dependency", target=self.wget_pull, args=(wget_files,))
                t.start()
                task_list.append(t)
            else:
                if file is None:
                    continue
                dependency_file = os.path.realpath(os.path.join(self.config.code_path, f"dependency/{file}"))
                agentpath = os.path.join(self.config.download_0502, file.replace('.xml', ''))
                if os.path.isfile(os.path.join(agentpath, "downloaded")):
                    continue
                else:
                    os.makedirs(agentpath, exist_ok=True)
                t = Process(name="download_dependency", target=self.artget_pull, args=(dependency_file, agentpath))
                t.start()
                task_list.append(t)

        start_time = time.time()
        while True:
            # 每秒检查一次，平均下载时间为7分钟，10分钟超时，避免挂死
            time.sleep(1)
            cur_time = time.time()
            if cur_time - start_time > 1200:
                raise TimeoutError
            # 退出状态列表，未完成为None，完成为数字，异常会提前抛出异常退出
            exit_code_list = []
            for task in task_list:
                if task.exitcode is not None and task.exitcode != 0:
                    raise RuntimeError(f"{task.name} 返回错误 !!! {task.exitcode}")
                exit_code_list.append(task.exitcode)
            # 检查是否有未完成，未完成则继续
            if None not in exit_code_list:
                break

    def unzip_dependency(self):
        self.download_conf = self.get_manufacture_config(f"manufacture/{self.config.manufacture_code}/download")
        if self.download_conf is None:
            self.info(f"{self.config.manufacture_code} 没有需要解压的依赖文件")
            return
        # 支持使用wget和artget下载sp压缩包,在此处进行解压
        for bin_conf in self.download_conf:
            if bin_conf.get("type") == "sp" and bin_conf.get("bin") is not None:
                # 使用wget或artget下载都须在在单板的yml中配置保存路径和文件名"
                self.sp_bin_path = bin_conf.get("bin")
                self.sp_bin_dir = os.path.dirname(self.sp_bin_path)
                # 开发者本地第二次构建烧片包不进行sp解压缩
                xml_file = bin_conf.get("xml_file")
                if os.path.isfile(os.path.join(self.sp_bin_dir, "unzipped")) and xml_file is not None:
                    continue
                # artget和wget下载的sp压缩包名字不是确定的,例sp_aarch64_bin.zip、sp_bin.zip这里直接判断sp_bin_path是否是zip结尾
                if self.sp_bin_path.endswith(".zip") and os.path.isfile(self.sp_bin_path):
                    self.run_command(f"unzip -o {self.sp_bin_path} -d {self.sp_bin_dir}")
                    # 重命名bin文件，确保解压出来的文件与yml中的bin的配置一致
                    files = os.listdir(self.sp_bin_dir)
                    bin_files = fnmatch.filter(files, 'sp*.bin')
                    self.run_command(f"mv {self.sp_bin_dir}/{bin_files[0]} {self.sp_bin_path}")
                    # 标记sp文件已压缩
                    self.run_command("touch {}".format(os.path.join(self.sp_bin_dir, "unzipped")))

    def run(self):
        if self.config.manufacture_code is None:
            self.info("跳过下载 manufacture 依赖")
            return
        self.download()
        self.unzip_dependency()
