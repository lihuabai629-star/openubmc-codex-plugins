#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.

'''
功    能：下载并安装rtos/hcc工具
版权信息：华为技术有限公司，版本所有(C) 2021
修改记录：2021-10-11 创建
'''
import os
import shutil

from bmcgo import misc
from bmcgo.tasks.task_download_buildtools import DownloadDefaultBuildtools as BingoDownloadDefaultBuildtools
from bmcgo.tasks.task_download_buildtools import TaskClass as BingoDownloadBuildtools

from bmcgo_pro.tasks.task import Task
from bmcgo_pro.tasks.misc import RTOS_DIST_SHA256_PATH
from bmcgo_pro.utils.config import Config
from bmcgo_pro.utils.artget_tools import ArtgetDownloadTool
from bmcgo_pro.tasks.download_buildtools_hm import DownloadHmBuildTools


class DownloadDefaultBuildtools(BingoDownloadDefaultBuildtools):
    def __init__(self, config: Config):
        super().__init__(config)
        self.task = Task(config, "DownloadDefaultBuildtools")
        self.rtos_sdk_dir = f"{self.config.tools_path}/rtos-sdk-arm64"
        self.dependency_file = os.path.realpath(os.path.join(
            self.config.code_path, self.get_manufacture_config("base/dependency_buildtools")))
        self.download_file_old_sha256 = f"{self.config.tools_path}/buildtools_download_file_old.sha256"
        self.download_file_new_sha256 = f"{self.config.tools_path}/buildtools_download_file_new.sha256"
        self.skip_download = False

    def download_tools(self):
        self.skip_download = not self.task.check_need_download(
            self.dependency_file,
            self.download_file_old_sha256,
            self.download_file_new_sha256,
        )
        if self.skip_download:
            self.info("buildtools下载文件未变更, 跳过下载")
            return
        self.info(f"移除下载路径: {self.rtos_sdk_dir}")
        self.run_command(f"rm -rf {self.rtos_sdk_dir}", ignore_error=True, sudo=True)
        self.run_command(f"rm -rf {self.download_file_old_sha256}", ignore_error=True, sudo=True)
        self.info('开始下载依赖工具...')
        partner_tools_dir = f"{os.path.expanduser('~')}/rtos_compiler"
        if self.config.partner_mode:
            self.info(f"从缓存目录{partner_tools_dir}复制编译器工具")
            self.run_command(f"cp -rf {partner_tools_dir}/. {self.rtos_sdk_dir}")
        else:
            artget_rtos_sdk = ArtgetDownloadTool(self.dependency_file, f"{self.rtos_sdk_dir}")
            artget_rtos_sdk.download()
            if os.path.isdir(partner_tools_dir):
                shutil.rmtree(partner_tools_dir)
            # 非partner模式复制构建工具，以备伙伴模式使用
            self.run_command(f"cp -rf {self.rtos_sdk_dir}/. {partner_tools_dir}")
            self.run_command(f"cp -af {self.download_file_new_sha256} {self.download_file_old_sha256}")
        self.info("下载依赖工具结束")

    def install_rtos(self):
        self.run_command(f"rm -rf {RTOS_DIST_SHA256_PATH}", sudo=True)
        super().install_rtos()

    def install_hcc(self):
        super().install_hcc()
        # 1712机型新增linx编译工具
        if self.config.chip == "1712":
            if not os.path.exists("linx-llvm-binary-release-musl.tar.gz"):
                return
            self.info("删除目录 /opt/linx-llvm-binary-release-musl")
            self.run_command("rm -rf /opt/linx-llvm-binary-release-musl", sudo=True)
            self.info("解压 linx-llvm-binary-release-musl")
            self.run_command("tar -xzf linx-llvm-binary-release-musl.tar.gz -C /opt", sudo=True)

    def setup_path(self):
        super().setup_path()
        logname = os.getenv(misc.ENV_LOGNAME, None)
        if logname and logname != "root":
            user_group = f"{os.getuid()}:{os.getgid()}"
            if self.config.chip == "1712":
                self.run_command(f"chown {user_group} /opt/linx-llvm-binary-release-musl -R", sudo=True)


class TaskClass(BingoDownloadBuildtools):
    def __init__(self, config, work_name=""):
        super(TaskClass, self).__init__(config, work_name)
        profile, _ = self.get_profile_config()
        self.download_buildtools = None
        if profile and profile.settings.get("os") == "HongMeng":
            self.download_buildtools = DownloadHmBuildTools(config)
        else:
            self.download_buildtools = DownloadDefaultBuildtools(config)
