#!/usr/bin/env python3
# coding:utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2024. All rights reserved.
import os
import stat
import sys
import argparse
from concurrent.futures import ProcessPoolExecutor, Future
import json
from typing import List
import yaml

from bmcgo import misc
from bmcgo.utils.fetch_component_code import FetchComponentCode
from bmcgo.component.build import BuildComp
from bmcgo.component.component_helper import ComponentHelper, BUILD_TYPE_DT, STAGE_DEV, STAGE_RC, STAGE_STABLE
from bmcgo.component.component_dt_version_parse import ComponentDtVersionParse
from bmcgo.functional.fetch import BmcgoCommand as Fetch

from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.tasks.task import Task
from bmcgo_pro.bmcgo_config import BmcgoConfig
from bmcgo_pro.utils.config import Config


tools = Tools("gen_recipes")


class TaskClass(Task):
    def __init__(self, config: Config, work_name=""):
        super().__init__(config, work_name=work_name)
        self.bconfig = BmcgoConfig()
        self.source_code = os.path.join(self.config.temp_path, "source_code")
        parser = argparse.ArgumentParser(
            prog="bmcgo gen package_info and recipes",
            formatter_class=argparse.RawTextHelpFormatter,
        )
        parser.add_argument(
            "-pio", "--package_info_only", help="是否只生成package_info, 默认False", action=misc.STORE_TRUE
        )
        parser.add_argument(
            "--skip_dt", help="是否跳过dt包, 默认False", action=misc.STORE_TRUE
        )
        parser.add_argument("--comp_list", help="额外指定需要生成recipes的组件列表, 文本格式每行一个组件", default=None)
        parsed_args, _ = parser.parse_known_args(sys.argv)
        self.package_info_only = parsed_args.package_info_only
        self.skip_dt = parsed_args.skip_dt
        self.comp_list = parsed_args.comp_list

    def generate_comp_recipe(self, comp_path: str, package_info_path: str):
        cwd = os.getcwd()
        comp_name = os.path.basename(comp_path)
        os.chdir(comp_path)

        os.makedirs("temp", exist_ok=True)
        temp_service_json = os.path.join("temp", "service.json")
        if not os.path.isfile(temp_service_json):
            tools.copy("mds/service.json", temp_service_json)

        with open(temp_service_json, "r", encoding="UTF-8") as file_handler:
            service_json_data = json.load(file_handler)
        dependencies = service_json_data.get(misc.CONAN_DEPDENCIES_KEY, {})
        if dependencies:
            # 设置依赖组件版本
            tools.log.info(f"设置{comp_name}的依赖组件patch范围版本...")
            ComponentDtVersionParse(serv_file=temp_service_json, exclude_dt=True).manifest_version_revise(
                package_info_path, use_patch_range=True
            )

        # 先生成conanbase.py文件
        BuildComp(self.bconfig, gen_conanbase=True, service_json=temp_service_json)
        # 恢复工作区为clean状态, 保证conan export时scm信息准确
        tools.run_command("git restore .")
        tools.run_command("git clean -fd")

        for stage in [STAGE_STABLE, STAGE_RC]:
            user_channel = ComponentHelper.get_user_channel(stage).strip("@")
            tools.run_command(f"conan export . {user_channel}")
        tools.log.success(f"成功生成组件{comp_name}的recipe")
        os.chdir(cwd)

    def run(self):
        self.prepare_conan()
        self.tools.run_command(f"rm -rf {self.source_code}")
        os.makedirs(self.source_code)

        self.log.info(f"开始生成package_info{'' if self.package_info_only else '和recipes'}......")
        self.generate_package_and_recipes()
        self.log.info(f"package_info{'' if self.package_info_only else '所有组件recipes'}生成完成。")

    def generate_package_and_recipes(self):
        self.log.info(f"获取stage为{STAGE_STABLE}的所有单板需要的组件和DT依赖的组件列表")
        # 使用stable作为获取manifest组件列表的基础, rc直接使用stable的组件版本列表, 避免执行过程中ibmc_sdk变化, 导致出现部分组件版本不一致
        manifest_deps = self.get_manifest_deps(STAGE_STABLE)
        all_stable_deps = self.get_all_deps(manifest_deps, STAGE_STABLE)

        package_info_path = self.create_package_info(all_stable_deps)
        self.tools.run_command(f"cp -f {package_info_path} {self.config.output_path}")
        if self.package_info_only:
            return

        self.generate_dt_packages()

        ComponentHelper.download_recipes(all_stable_deps, self.tools, self.config.remote_list)
        if misc.conan_v2():
            self.tools.run_command("conan cache clean")
            return
        self_developed_pkgs = self.get_self_developed_pkgs(all_stable_deps)
        non_self_developed_pkgs = []
        for pkg in all_stable_deps:
            comp_version, _ = pkg.split("@")
            if comp_version not in self_developed_pkgs:
                non_self_developed_pkgs.append(pkg)

        self.generate_comps_recipe(self_developed_pkgs, package_info_path)

        # 非自研组件提前准备依赖组件的recipe
        non_self_developed_deps = self.get_others_deps(non_self_developed_pkgs) + self.get_others_deps(
            non_self_developed_pkgs, BUILD_TYPE_DT
        )
        ComponentHelper.download_recipes(non_self_developed_deps, self.tools, self.config.remote_list)
        from bmcgo_pro.functional.full_component import BmcgoCommand as BuildFull
        BuildFull.copy_all_stable2rc(self.tools)

    def generate_dt_packages(self):
        if misc.conan_v2() and not self.skip_dt:
            with open(self.bconfig.conf_path, "r") as fp:
                config = yaml.safe_load(fp)
            dt_dependencies_conan2 = list(config.get("dt_dependencies", {}).values())
            ComponentHelper.download_recipes(dt_dependencies_conan2, self.tools, self.config.remote_list)
            if self.config.build_type == "debug":
                build_type = "Debug"
            else:
                build_type = "Release"
            for dt_comp in dt_dependencies_conan2:
                cmd = f"conan install --requires='{dt_comp}' -pr:h profile.dt.ini -pr:b profile.dt.ini"
                cmd += f" -of temp -s:a build_type={build_type} --build={dt_comp.split('/')[0]}/* --build=missing"
                self.tools.run_command(cmd)

    def copy_stable2rc(self):
        comps = os.listdir(self.tools.conan_data)
        for comp in comps:
            com_folder = os.path.join(self.tools.conan_data, comp)
            cwd = os.getcwd()
            os.chdir(com_folder)
            for version in os.listdir(com_folder):
                pkg = f"{comp}/{version}@{misc.CONAN_USER}/{STAGE_STABLE}"
                if not os.path.exists(os.path.join(self.tools.conan_data, pkg.replace("@", "/"))):
                    continue
                self.tools.run_command(f"conan copy {pkg} {misc.CONAN_USER}/{STAGE_RC} --all --force")
            os.chdir(cwd)

    def get_all_deps(self, manifest_deps: List[str], stage: str):
        addtional_pkgs = self._get_addtional_pkgs(stage)
        all_deps: List[str] = [*manifest_deps, *addtional_pkgs]
        if misc.conan_v2():
            return all_deps
        comp_versions = [dep.split("@")[0] for dep in all_deps]
        unique_deps = list(set(ComponentHelper.get_full_reference(comp_versions, stage)))
        return unique_deps

    def get_manifest_deps(self, stage):
        product_path = os.path.join(self.config.code_path, "product")
        all_deps = []
        for root, _, files in os.walk(product_path):
            if "manifest.yml" not in files:
                continue

            board_name = os.path.basename(root)
            all_deps += self._get_board_manifest_deps(board_name, stage)

        unique_deps = list(set(all_deps))
        return unique_deps

    def create_package_info(self, deps: List[str]):
        package_info = os.path.join(self.config.board_path, "package_info")
        fp = os.fdopen(os.open(package_info, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, stat.S_IWUSR | stat.S_IRUSR), "w")
        for dep in deps:
            fp.write(dep + "\n")
        fp.close()
        return package_info

    def generate_comps_recipe(self, self_developed_pkgs: List[str], package_info_path: str):
        full_pkgs = ComponentHelper.get_full_reference(self_developed_pkgs, STAGE_STABLE)
        packages = {pkg.split("/")[0]: pkg for pkg in full_pkgs}
        self.log.info("获取自研组件的源码...")
        FetchComponentCode(packages, self.source_code, self.config.remote).run()

        comps = os.listdir(self.source_code)
        pool = ProcessPoolExecutor()
        future_tasks: List[Future] = []
        for comp in comps:
            comp_path = os.path.join(self.source_code, comp)
            task = pool.submit(self.generate_comp_recipe, comp_path, package_info_path)
            future_tasks.append(task)

        pool.shutdown()
        for task in future_tasks:
            task_exception = task.exception()
            if task_exception is not None:
                raise task_exception

    def get_others_deps(self, pkgs: List[str], build_type: str = None):
        """获取非自研组件的依赖组件recipe

        Args:
            pkg (_type_): 组件包列表
            build_type: 构建类型
        """
        self.log.info(f"创建多进程获取组件的所有依赖...")
        pool = ProcessPoolExecutor()
        future_tasks: List[Future] = []
        for pkg in pkgs:
            future = pool.submit(ComponentHelper.get_all_dependencies, [pkg], self.config.remote, build_type)
            future_tasks.append(future)

        pool.shutdown()

        deps = pkgs
        for task in future_tasks:
            task_exception = task.exception()
            if task_exception is not None:
                raise task_exception
            deps += task.result()

        return list(set(deps))

    def get_dt_full_deps(self, stage: str):
        with open(self.bconfig.conf_path, "r") as fp:
            config = yaml.safe_load(fp)
        dt_dependencies = config.get("dt_dependencies", {})
        dt_deps = dt_dependencies.values()
        dt_full_deps = []
        for dep in dt_deps:
            cmds = [f"conan search {dep} --remote {self.config.remote} --raw"]
            full_dep, _ = self.tools.pipe_command(cmds, capture_output=True)
            all_pkgs = [pkg for pkg in reversed(full_dep.splitlines()) if not pkg.endswith(STAGE_DEV)]
            stage_pkgs = [pkg for pkg in all_pkgs if pkg.endswith(stage)]
            other_stage_pkg_versions = [pkg.split("@")[0] for pkg in all_pkgs if not pkg.endswith(stage)]
            full_pkg = ""
            # 获取rc/stable都存在的组件版本
            for pkg in stage_pkgs:
                comp_version = pkg.split("@")[0]
                if comp_version in other_stage_pkg_versions:
                    full_pkg = pkg
                    break
            dt_full_deps.append(full_pkg)

        all_dt_deps = dt_full_deps + ComponentHelper.get_all_dependencies(
            dt_full_deps, self.config.remote, build_type=BUILD_TYPE_DT
        )
        return all_dt_deps

    def get_self_developed_pkgs(self, deps: List[str]):
        self_developed_pkgs = []
        for dep in deps:
            if self._is_self_developed(dep):
                comp_version, _ = dep.split("@")
                self_developed_pkgs.append(comp_version)
        return self_developed_pkgs

    def _get_board_manifest_deps(self, board_name: str, stage: str) -> List[str]:
        config = Config(self.config.bconfig, board_name)
        args = ["-b", board_name, "--stage", stage]
        config.parse_args(args)
        config.pre_cook_manifest()
        mani = config.load_manifest_yml()
        dependencies = [dep["conan"] for dep in mani["dependencies"]]
        return dependencies

    def _is_self_developed(self, pkg: str):
        comp_name = pkg.split("/")[0]
        comp_package_path = os.path.join(self.conan_data, comp_name)
        ret = self.tools.run_command(f"find {comp_package_path} -name 'conanbase.py'", capture_output=True)
        return bool(ret.stdout)

    def _get_addtional_pkgs(self, stage: str) -> List[str]:
        if not self.comp_list or not os.path.isfile(self.comp_list):
            return []
        subsys_dir = os.path.join(self.config.code_path, "subsys")
        components = Fetch.get_subsys_file_components(subsys_dir, stage)

        pkgs = []
        with open(self.comp_list, encoding="UTF-8", mode="r") as fp:
            for line in fp.readlines():
                comp = line.strip()
                if "/" in comp:
                    continue
                if comp in components:
                    pkgs.append(components.get(comp))
        return pkgs
