#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2020. All rights reserved.
"""
功 能: 归档文件到cmc
版权信息：华为技术有限公司，版本所有(C) 2019-2023
"""

import os
import subprocess

from bmcgo import misc
from bmcgo_pro.tasks.task import Task
from bmcgo_pro.utils.config import Config
from bmcgo_pro.utils.docker import Docker

DOCKER_REPO_URL = 'cd-docker-hub.szxy5.artifactory.cd-cloud-artifact.tools.huawei.com/ibmc_docker_partner'


class TaskClass(Task):
    def __init__(self, config: Config, work_name=""):
        super(TaskClass, self).__init__(config, work_name=work_name)
        self.mount_path = os.path.join(os.path.dirname(self.config.code_root),
                                  os.path.basename(self.config.partner_workspace))
        self.docker_env = "DOCKERENV"
        # 这里只使用基础功能, 其余功能暂且保留
        self.docker = Docker(name="server",
                             env=f"{self.docker_env}=True",
                             volumns=f"{self.config.docker_component_home}:{self.mount_path}",
                             work_path=self.config.code_root,
                             container_tag=self.config.container_tag,
                             # 这个是后台 docker 日志, 无法打到前台, 如果在上传过程中有问题, 前台上传日志会报错
                             cmd="conan_server &")
        self.conan_remote = "docker_server"
        self.archive_conf = self.get_manufacture_config("archive")

    def docker_prepare(self):
        if self.docker.docker_start():
            self.info("conan_server 启动成功, 等待上传")
        else:
            raise Exception("docker 启动失败, 请检查环境")

    def conan_remote_config(self):
        self.run_command(f"conan remote remove {self.conan_remote}", ignore_error=True)
        # 添加容器内为远端
        self.run_command(f"conan remote add {self.conan_remote} http://0.0.0.0:9300/")
        # 配置账户密码
        self.run_command(f"conan user ibmc_conan_dev -p Huawei12#$ -r {self.conan_remote}")

    def conan_remote_remove(self):
        self.run_command(f"conan remote remove {self.conan_remote}", ignore_error=True)

    def conan_remote_rename(self, old_name, new_name):
        self.run_command(f"conan remote rename {old_name} {new_name}", ignore_error=True)

    def component_upload(self):
        self.pipe_command(['conan search "*"', 'tail -n +3',
                          f'xargs -P 12 -I {{}} conan upload {{}} -c --all -r {self.conan_remote}'])

    def partner_env_clip(self):
        sys_root_path = os.path.abspath("/")
        user_home = os.path.expanduser('~')
        os.chdir(self.config.code_root)
        remove_cmd = 'sudo xargs rm -rf'
        self.run_command(f"rm -rf {sys_root_path}usr/bin/artget", sudo=True)
        self.run_command(f"rm -rf {user_home}/.ArtGet")
        self.run_command(f"rm -rf {self.conan_data}")
        self.run_command(f"rm -rf {user_home}/.git-credentials")
        os.chdir(os.path.join(self.config.code_root, "build", "conan_index"))
        self.pipe_command([f'ls', 'grep -v "^ibmc"', remove_cmd], ignore_error=True)

        os.chdir(self.config.code_root)
        self.run_command("git config --global user.name partner")
        self.run_command("git config --global user.email partner@partner.com")
        self.run_command("rm -rf dev_tools .git .vscode", sudo=True)
        self.run_command("rm -rf init.py", sudo=True)
        self.run_command("git init")
        self.run_command("git add -A")
        self.run_command("git commit -m 'init'")
        os.chdir(os.path.join(os.path.abspath('/'), "opt"))
        self.pipe_command(['sudo find . -iregex ".*\.c\|.*\.cpp"', remove_cmd])
        os.chdir(self.config.temp_path)
        self.run_command(f"cp -rf {self.mount_path} {os.path.dirname(self.config.code_root)}/component_home")
        self.run_command(f"umount {self.mount_path}", sudo=True)
        self.run_command(f"rm -rf {self.mount_path}", sudo=True)
        self.pipe_command(['ls', remove_cmd])
        self._create_partner_mode()

    def run(self):
        self.docker_prepare()
        self.conan_remote_config()
        self.component_upload()
        # docker 内部执行, 前面之类的, 还有 sdk 之类的部署
        self.docker.exec(f"bmcgo build -t personal -b {self.config.board_name} > " + \
                            f"{self.config.log_path}/docker_personal.log 2>&1")
        # docker 导出
        archive_path = os.path.join(self.config.output_path, "packet", self.config.archive_path)
        if not os.path.isdir(archive_path):
            os.makedirs(archive_path)
        self.docker.export(archive_path)
        # 上传docker远端repo
        if self.config.upload_docker:
            cwd = os.getcwd()
            os.chdir(archive_path)
            self.info(f"上传镜像至远端: {DOCKER_REPO_URL}/{self.config.partner_name}:{self.config.docker_tag}")
            self.docker.push(DOCKER_REPO_URL, self.config.partner_name, self.config.docker_tag)
            os.chdir(cwd)
        self.docker.clear()

    def _create_partner_mode(self):
        scheme = {
            'conan': {
                'user': 'hw.ibmc.partner'
            },
            'partner': {
                'enable': True
            },
        }
        Config.set_conf(misc.GLOBAL_CFG_FILE, scheme)

    def _clean_partner_mode(self):
        scheme = {
            'partner': {
                'enable': False
            },
        }
        Config.set_conf(misc.GLOBAL_CFG_FILE, scheme)