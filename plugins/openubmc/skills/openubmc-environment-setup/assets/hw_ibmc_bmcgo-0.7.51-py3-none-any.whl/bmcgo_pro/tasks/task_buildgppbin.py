#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
"""
功 能：buildgppbin脚本，该脚本 make pme jffs2 cramfs gpp bin image
版权信息：华为技术有限公司，版本所有(C) 2019-2020
"""

import os

from bmcgo.tasks.task_buildgppbin import TaskClass as BingoBuildgppbin
from bmcgo import errors
from bmcgo import misc

from bmcgo_pro.utils.swbom import SWBom
from bmcgo_pro.tasks.task import Task


class TaskClass(Task, BingoBuildgppbin):
    def __init__(self, config, work_name=""):
        super(TaskClass, self).__init__(config, work_name=work_name)
        self.suffix = "iBMC"

    def copy_files(self):
        # 兼容性设计：伙伴签名方案的rootca.der由伙伴提供，cms.crl由签名工具提供
        # 为保障兼容ibmc_sdk的gpp/files提供rootca.der场景
        # 如果文件已存在由不再复制gpp配置的证书
        rootca = os.path.join(self.config.work_out, misc.ROOTCA_DER)
        crl = os.path.join(self.config.work_out, misc.CMS_CRL)
        exclude_files = []
        if os.path.isfile(rootca):
            self.tools.copy(rootca, misc.ROOTCA_DER)
            exclude_files.append(misc.ROOTCA_DER)
        if os.path.isfile(crl):
            self.tools.copy(crl, misc.CMS_CRL)
            exclude_files.append(misc.CMS_CRL)
        # 复制gpp需要使用的文件,记录rootfs.img、rootfs.img.cms、cms.crl、rootca.der、Hi1711_boot_4096.bin、Hi1711_boot_pmode.bin共六个文件
        files = self.get_manufacture_config(f"gpp/files")
        if files is None:
            raise errors.BmcGoException("获取 manifest.yml 中 gpp/files 配置失败, 退出码: -1")
        # 复制构建emmc gpp镜像所需的文件
        self.copy_manifest_files(files, exclude_files)

        # 如果manufacture包中的有sdk描述，覆盖gpp/files中的文件
        if self.config.manufacture_code is None:
            return
        gpp_files = self.get_manufacture_config(f"manufacture/{self.config.manufacture_code}/gpp/files")
        if gpp_files is not None:
            self.copy_manifest_files(gpp_files, exclude_files)

    def copy_gpp_headers_files(self):
        # 复制gpp pkg_headers需要使用的文件,记录emmc_header、hpm_header、emmc_uboot_header共三个文件
        files = self.get_manufacture_config(f"gpp/pkg_headers")
        if files is None:
            if self.config.chip != "1711":
                raise errors.BmcGoException("获取 manifest.yml 中 gpp/pkg_headers 配置失败, 退出码: -1")
            else:
                files = []
                files.append({"file": "/usr/local/bin/emmc_header.config", "dst": "emmc_header.config"})
                files.append({"file": "/usr/local/bin/hpm_header.config", "dst": "hpm_header.config"})
                files.append({"file": "/usr/local/bin/emmc_uboot_header.config", "dst": "emmc_uboot_header.config"})
        # 复制构建emmc gpp镜像所需的文件
        self.copy_manifest_files(files)

    def build_gpp_rootfs_bin(self):
        self.info("开始构建 gpp rootfs 二进制文件")
        # 装备非ipmc_bin打包的不需要构建
        if self.config.manufacture_code is None:
            return
        self.chdir(self.config.gpp_build_dir)
        self.copy_files()
        if not self.config.self_sign:
            # 复制cms.crl
            self.run_command(f"cp {self.config.build_path}/crldata.crl cms.crl")
        self.copy_gpp_headers_files()
        self.run_command("gpp_header emmc")
        self.info("打包: GPP_rootfs.bin")
        cmd = f"ls -al rootfs_{self.suffix}.img emmc_sub_header rootca.der rootfs_{self.suffix}.img.cms cms.crl "
        cmd += "Hi1711_boot_4096.bin emmc_top_header"
        self.run_command(cmd, show_log=True)
        if self.config.chip == "1711":
            self.run_command(f'make_emmc_gpp.sh {self.config.board_name} 384')
        else:
            self.run_command(f'make_emmc_gpp.sh {self.config.board_name} 768')
        self.link(f"GPP_rootfs.bin", f"{self.config.work_out}/GPP_rootfs.bin")
        self.info(os.listdir(self.config.work_out))

    def build_gpp_hpm_bin(self):
        self.build_gpp_rootfs_bin()
        self.info("构建 gpp 二进制文件")
        self.chdir(self.config.hpm_build_dir)
        self.copy_files()
        if not self.config.self_sign:
            # 复制cms.crl
            self.run_command(f"cp {self.config.build_path}/crldata.crl cms.crl")
        self.copy_gpp_headers_files()

        self.run_command("gpp_header hpm")

        if not os.path.exists("hpm_top_header"):
            raise errors.BmcGoException(f"hpm_top_header 不存在 ! 创建 hpm_sub_header 失败!")

        if not os.path.exists("hpm_sub_header"):
            raise errors.BmcGoException(f"hpm_sub_header 不存在 ! 创建 hpm_sub_header 失败!")

        # 生成boot和sign元数据
        hpm_package_info = {
            "boot": {
                "Hi1711_boot_4096.bin": self.tools.sha256sum("Hi1711_boot_4096.bin"),
            },
            "sign": {
                "sign_type": "sm2" if self.config.signature_type == "sm2" else "pss",
                "crl": "cms.crl",
                "crl_sha256sum": self.tools.sha256sum("cms.crl"),
                "rootca": "from code path: HuaweiRootCA.der",
                "rootca_sha256sum": self.tools.sha256sum(misc.ROOTCA_DER)
            }
        }
        if self.config.chip == "1711":
            pmode_file = "Hi1711_boot_pmode.bin "
            hpm_package_info["boot"]["Hi1711_boot_pmode.bin"] = self.tools.sha256sum("Hi1711_boot_pmode.bin")
        else:
            pmode_file = "LiteOS_M.bin "
            hpm_package_info["boot"]["LiteOS_M.bin"] = self.tools.sha256sum("LiteOS_M.bin")

        swbom_file = f"{self.config.inner_path}/hpm_info_{self.config.board_name}.yml"
        swbom = SWBom(swbom_file)
        swbom.write(hpm_package_info)
        # 生成boot和sign元数据 -- end

        self.write_gpp_bin(pmode_file)

    def prepare_boot_1712(self):
        # 继承函数，不允许变更函数名，供扩展实现
        if self.config.self_sign:
            debug_flag = "_debug" if self.config.build_type == "debug" else ""
            # 解压uboot_debug未签名包
            dir_name = f"origin_uboot{debug_flag}"
            os.makedirs(dir_name)
            self.run_command(f"tar -xzf boot/original/external_hiboot{debug_flag}.tar.gz -C {dir_name}")
            self.self_sign_uboot_1712(dir_name, ".")

    def self_sign_uboot_1712(self, uboot_dir, output_dir):
        """签名uboot包"""
        debug_flag = "_debug" if self.config.build_type == "debug" else ""
        signature_flag = "" if self.config.signature_type.startswith("rsa") else "_sm2"
        output_dir = os.path.realpath(output_dir)
        cwd = os.getcwd()
        cmd = f"dd if=Hi1711_boot_4096{debug_flag}.bin of={uboot_dir}/l0l1.bin bs=1K count=1K count=1536"
        self.run_command(cmd)
        self.run_command(f"cp boot/packeted/hiboot{signature_flag}_cms{debug_flag}.bin {uboot_dir}/u-boot_cms.bin")
        self.run_command(f"cp {uboot_dir}/hiboot.bin {uboot_dir}/uboot.bin")
        self.chdir(uboot_dir)
        self.signature("uboot.bin", "uboot.bin.cms", "cms.crl", "rootca.der")
        self.copy_gpp_headers_files()
        self.run_command("gpp_header uboot")
        self.run_command(f"make_uboot_img.sh 1536")
        self.run_command(f"cp Hi1711_boot_4096.bin {output_dir}/Hi1711_boot_4096{debug_flag}.bin")
        self.chdir(cwd)
