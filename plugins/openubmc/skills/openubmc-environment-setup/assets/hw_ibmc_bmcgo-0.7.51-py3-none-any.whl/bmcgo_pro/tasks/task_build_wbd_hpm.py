#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
"""
功 能：work_build_wbd_hpm.py脚本 -- 用于生成产品白牌包
版权信息：华为技术有限公司，版本所有(C) 2023
"""

import os
import shutil
from bmcgo_pro.tasks.task import Task


class TaskClass(Task):
    def __init__(self, config, work_name=""):
        super(TaskClass, self).__init__(config, work_name=work_name)

    def generate_wbd_hpm(self, index, wbd_hpm):
        # 创建wbd_packet目录
        wbd_path = os.path.join(self.config.hpm_build_dir, "wbd_packet")
        shutil.rmtree(wbd_path, ignore_errors=True)
        os.makedirs(wbd_path, exist_ok=True)
        # 创建临时构建目录
        build_path = os.path.join(wbd_path, "build")
        os.makedirs(build_path, exist_ok=True)
        self.chdir(build_path)
        # 如果没有repo或tag，报错退出
        if "repo" not in wbd_hpm or "tag" not in wbd_hpm:
            shutil.rmtree(build_path)
            raise Exception("请检查 manifest 中关于 wbd_hpm 的配置, 当前未找到 tag 或 repo 相关配置")
        repo = wbd_hpm.get("repo")
        tag = wbd_hpm.get("tag")
        if not repo.startswith("https"):
            self.info("建议使用 https 协议的仓库地址")
        # 下载customization仓库的白牌素材
        self.run_command(f"git clone {repo} -b {tag}")
        # 创建wbd_up_file目录
        wbd_up_file_path = os.path.join(build_path, "wbd_up_file")
        # 复制manifest.yml中配置的文件到build目录
        files = wbd_hpm.get("files")
        self.copy_manifest_files(files)
        profile, _ = self.get_profile_config()
        if profile and profile.settings.get("os") == "HongMeng":
            self.run_command(f"cp /usr/bin/busctl {wbd_up_file_path}")
        else:
            busctl_path = f"{build_path}/../../../buildimg/rtos_with_driver/rootfs/usr/bin/busctl"
            self.run_command(f"cp {busctl_path} {wbd_up_file_path}")

        self.info(f"开始构建 wbd hpm 包, 工作目录: {build_path}")
        # 生成hpm文件
        self.run_command(f"/bin/bash {build_path}/packetwbd.sh wbd_up_file hpm_wbd.config")

        self.sign_hpm(build_path)

        # 结果处理，移动hpm到目标，删除临时构建文件夹
        shutil.move("wbd-crypt-image.hpm.signed", f"{self.config.work_out}/wbd_hpm{index + 1}.hpm")
        self.chdir(self.config.temp_path)
        shutil.rmtree(build_path)

    def sign_hpm(self, build_path: str):
        # 生成.filelist文件
        self.run_command("cms_sign_hpm.sh 1 wbd-crypt-image.hpm")

        # 指定签名证书的使用自签名证书签名
        if self.config.self_sign:
            self.signature("wbd-crypt-image.filelist", "wbd-crypt-image.filelist.cms", "cms.crl", "rootca.der")
        else:
            # 从单板配置目录复制签名配置
            self.run_command(f"cp {self.config.board_path}/sign_hpm.xml sign_wbd.xml")

            # 替换sign_wbd.xml中路径
            self.tools.py_sed("sign_wbd.xml", "(?<=path=\").*(?=\")", build_path)
            self.tools.py_sed("sign_wbd.xml", "(?<=<crlfile>).*(?=</crlfile>)", f"{build_path}/crldata.crl")
            # 正常签名模式
            self.run_command("java -jar /usr/local/signature-jenkins-slave/signature.jar sign_wbd.xml")
            self.run_command("cp crldata.crl cms.crl")
        self.run_command("cms_sign_hpm.sh 2 wbd-crypt-image.hpm")

    def generate_wbd_hpms(self):
        # 根据manifest.yml中的wbd_hpms对象生成对应的wbd hpm包
        manu_path = "manufacture/" + self.config.manufacture_code
        # 如果不存在wbd_hpms对象，退出构建
        dirname = "/wbd_hpms"
        wbd_hpm_conf = self.get_manufacture_config(manu_path + dirname)
        if wbd_hpm_conf is None:
            self.info("在 manifest.yml 中没有 {} 属性, 跳过构建 wbd hpm 包".format(
                manu_path + dirname))
            return

        wbd_hpms = self.get_manufacture_config(manu_path + dirname)
        for index, wbd_hpm in enumerate(wbd_hpms):
            self.generate_wbd_hpm(index, wbd_hpm)

    def run(self):
        if self.config.manufacture_code is None:
            self.info("跳过构建 wbd hpm 包, 因为 manufacture 为空 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            return

        self.info(f"构建 {self.config.board_name} wbd hpm 包 ------------> [开始]")
        self.generate_wbd_hpms()
        self.info(f"构建 {self.config.board_name} wbd hpm 包 ------------> [结束]")
