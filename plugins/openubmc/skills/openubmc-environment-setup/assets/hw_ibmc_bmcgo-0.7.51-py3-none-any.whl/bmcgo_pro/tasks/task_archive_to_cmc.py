#!/usr/bin/env python3
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
"""
功 能: 归档文件到cmc
版权信息：华为技术有限公司，版本所有(C) 2019-2023
"""

import os
import sys
import json
import stat
import signal
import shutil
import time
import copy
import multiprocessing
from multiprocessing import Process

import yaml

from git import Repo
from bmcgo import misc
from bmcgo_pro.tasks.task import Task
from bmcgo_pro.utils.config import Config

WEBUI_APP = "webui"
DOCUMENTATION_DIR = 'ibmc_documentations'
BMCGO_GEN_BLACK_LIST = [
    'app_demo',
    'app_extend_demo',
    'mdb_interface',
    'webui',
    'customization'
]
BMCGO_BUILD_BLACK_LIST = [
    DOCUMENTATION_DIR,
    'web_online_help',
    'docs'
]
LIBMC4LUA = "libmc4lua"


class DeployRepository:
    """部署必要依赖仓, 自行创建目录, 自行下载
    """
    def __init__(self, url: str, branch: str, path: str):
        """clone 仓库的配置

        Args:
            url (str): url 地址
            branch (str): 要下载的分支
            path (str): 存放的目标路径, 此路径即为代码仓根目录
        """
        self.url = url
        self.path = path
        self.branch = branch

    def clone(self):
        """执行 clone 动作
        """
        self._git_clone()

    def sparse_checkout(self, work: Task):
        cwd = os.getcwd()
        self._git_clone()
        os.chdir(os.path.join(cwd, self.path))
        work.run_command(r"git sparse-checkout set --no-cone '*.md' '![Cc][Hh][Aa][Nn][Gg][Ee][Ll][Oo][Gg]*.md'")
        work.run_command(r'rm -r .git')
        os.chdir(cwd)

    def _git_clone(self):
        """自动创建配置的目录, 并 clone 代码
        """
        if os.path.exists(self.path):
            shutil.rmtree(self.path)
        os.makedirs(self.path)
        Repo.clone_from(url=self.url, to_path=self.path, branch=self.branch)


class BuildComponent(Process):
    def __init__(self, name, path, work: Task, enable_luajit, ignore_error=False):
        super().__init__()
        self.name = name
        self.path = path
        self.work = work
        self.ignore_error = ignore_error
        self.enable_luajit = enable_luajit
        self.options = ''
        self.get_options()

    def get_options(self):
        opts = self.work.all_options.get(self.name, {})
        if opts is None:
            return
        for key, val in opts.items():
            self.options += f' -o {self.name}:{key}={val}'

    def run_command(self, build_type, stage):
        log_file = os.path.join(self.work.config.log_path, f"{self.name}.log")
        cmd = f"bmcgo build -nc -bt {build_type} --stage {stage}"
        if self.enable_luajit:
            cmd += ' -jit'
        cmd += self.options
        self.work.info(f"RUN: Component: {self.name}, path: {self.path}, {cmd}")
        ret = self.work.run_command(cmd, log_file)
        if ret.returncode != 0:
            if self.ignore_error is True:
                self.work.warning(f"执行: 组件: {self.name}, 路径: {self.path}, {cmd} 失败，忽略错误")
                sys.exit(-1)
            else:
                self.work.error(f"执行: 组件: {self.name}, 路径: {self.path}, {cmd} 失败")
                raise OSError(f"执行: 组件: {self.name}, 路径: {self.path}, {cmd} 失败")

    def run(self):
        if os.path.isfile(self.path) or os.path.exists(f"{self.path}/build.py") is False:
            return
        os.chdir(self.path)
        self.work.info(f"bmcgo 当前工作路径: {os.getcwd()}")
        self.work.run_command("git clean -fdx", ignore_error=True)
        self.work.run_command("git restore .", ignore_error=True)
        if self.name not in BMCGO_BUILD_BLACK_LIST:
            self.run_command("debug", "rc")
            self.run_command("release", "rc")
        if self.name != WEBUI_APP and self.name not in BMCGO_BUILD_BLACK_LIST:
            self.run_command("debug", "stable")
            self.run_command("release", "stable")
            self.run_command("dt", "dev")
            self.work.run_command("bmcgo test", ignore_error=True)
        if self.name not in BMCGO_GEN_BLACK_LIST and os.path.isfile('mds/model.json'):
            self.work.info(f"开始bmcgo gen: {self.name}")
            self.work.run_command("bmcgo gen", ignore_error=True)
            self.work.run_command("git clean -fdx", ignore_error=True)
            self.work.run_command("git restore .", ignore_error=True)
        self.work.info(f"bmcgo 构建: {self.path} 结束")


class PkgInfo(object):
    def __init__(self, name, version, requires_id):
        self.name = name
        self.version = version
        self.requires_id = requires_id
        self.requires: dict[str, PkgInfo] = {}


class TaskClass(Task):
    """ 打包文件至CMC

    Args:
        Task (class): 继承 Task 类, 处理一系列流程
    """
    def __init__(self, config: Config, work_name=""):
        """ 初始化

        Args:
            config (Config): config 类, 类似于上帝类, 基本能取到所有资源
            work_name (str, optional): work 的名字, 默认为空
        """
        super(TaskClass, self).__init__(config, work_name=work_name)
        self.workspace = self.config.partner_workspace
        self.source_code_path = os.path.join(self.workspace, "source")
        self.subsys_path = os.path.join(self.workspace, "subsys")
        self.component_path = os.path.join(self.workspace, "components")
        self.deps_file = "dep.yml"
        self.packages: dict[str, PkgInfo] = {}
        self.packages_map: dict[str, PkgInfo] = {}  # 包id到PkgInfo映射
        self.lock = multiprocessing.Lock()
        self.skynet = self.config.skynet_config
        self.enable_luajit = self.skynet.get('options', {}).get('enable_luajit', False)
        self.all_options = {}

    def crates_and_demo_deploy(self):
        """ app 开头为示例仓, crates 为自动生成代码必要仓
        """
        # yaml下载配置
        os.chdir(self.source_code_path)
        crates_and_demo_list = self.config.archive_conf.get("crates_and_demo", [])
        self.info("需要 url 下载的组件仓: %s", crates_and_demo_list)
        for repository in crates_and_demo_list:
            DeployRepository(url=repository["address"], branch=repository["branch"], path=repository["path"]).clone()

    def download_open_component_sourcecode(self):
        """ 根据依赖的 dict 来获取组件的源码
        """
        os.chdir(self.source_code_path)
        check = True
        deps = {misc.CONAN_DEPDENCIES_KEY: []}
        component_list = self.config.archive_conf.get("source_code_component", [])
        if len(component_list) == 0:
            self.info("组件下载源码列表未配置")
            return
        self.info(f"构建下载源码列表: %s", component_list)
        # 用于检查需要源码的组件是否参与构建 hpm 包
        for component in component_list:
            deps[misc.CONAN_DEPDENCIES_KEY].append({misc.CONAN: component})
        if check is False:
            raise ArithmeticError("请检查是否所有配置都参加了 hpm 包构建!!!")

        with os.fdopen(os.open(self.deps_file, flags=os.O_WRONLY | os.O_CREAT | os.O_TRUNC, \
            mode=stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH), "w") as dep_fp:
            yaml.dump(deps, dep_fp)
        # bmcgo 必须在根目录下才能执行, 不支持相对路径
        # bmcgo fetch 必须将 stage 配置为 stable 才能执行
        os.chdir(self.config.code_root)
        self.run_command(f"bmcgo fetch --stage stable\
            -p {self.source_code_path} --manifest_yml {self.source_code_path}/dep.yml")

    def readme_integration(self):
        """集成所有组件README文档"""
        os.chdir(self.source_code_path)
        readme_repos = self.get_manufacture_config('dependencies')
        readme_repos = [repo.get('conan') for repo in readme_repos]

        def search_and_download_readme_repos(repo_name):
            url, err = self.pipe_command([
                f'conan search {repo_name}',
                'tail -n 1',
                'xargs conan get',
                "grep -Po '(?<=\"url\": \")(.*)(?=\")'",
            ], get_output=True, ignore_error=True)
            if err != 0 or url is None:
                self.warning(f'{repo_name} Readme Excluded')
                return
            url = url.split('\n')[0]
            DeployRepository(url=url, 
                            branch='master', 
                            path=os.path.join(DOCUMENTATION_DIR, repo_name)).sparse_checkout(self)

        mtprocess_pool = []
        for repository in readme_repos:
            p = Process(target=search_and_download_readme_repos, args=(repository, ))
            p.start()
            mtprocess_pool.append(p)
        for p in mtprocess_pool:
            p.join()

    def load_package_lock(self):
        lock_file = os.path.join(self.config.output_path, f"package.lock")
        with open(lock_file, "r") as fp:
            lock_json = json.load(fp)
        nodes = lock_json.get("graph_lock").get("nodes")
        # 从package.lock中加载所有组件并存入self.packages字典中
        for key, node in nodes.items():
            name_version = node.get("ref").split("@")[0]
            chunks = name_version.split("/")
            name = chunks[0]
            version = chunks[1]
            requires_id = node.get("requires", [])
            pi = PkgInfo(name, version, requires_id)
            self.packages[name] = pi
            self.packages_map[key] = pi
        # 将所有package的requires填充为真实的组件名和版本号
        for _, pi in self.packages.items():
            for key in pi.requires_id:
                require_pi = self.packages_map.get(key)
                if not require_pi:
                    self.error(f"获取包 {key} 失败")
                    continue
                pi.requires[require_pi.name] = pi

    # service.json的依赖关系变更为明确依赖
    def fixed_service_dependencies(self, service_file):
        """当发生变更时返回True"""
        changed = False
        with open(service_file, "r") as fp:
            service_json = json.load(fp)
        dependencies = service_json.get(misc.CONAN_DEPDENCIES_KEY, {})

        def get_real_dep(dep_type):
            nonlocal changed
            real_dep = []
            deps = dependencies.get(dep_type, [])
            for dep in deps:
                pkg = dep.get(misc.CONAN, None)
                if not pkg:
                    continue
                name = pkg.split("/")[0]
                pi = self.packages.get(name)
                pkg_ver, *pkg_stage = tuple(dep[misc.CONAN].split('@'))
                if pi and pkg_ver != pi.name + "/" + pi.version:
                    dep[misc.CONAN] = pi.name + "/" + pi.version
                    if pkg_stage:
                        dep[misc.CONAN] += "@" + pkg_stage[0]
                    changed = True
                real_dep.append(dep)
            return real_dep

        real_test = get_real_dep("test")
        real_build = get_real_dep("build")
        if len(real_test) == 0 and len(real_build) == 0:
            return changed
        service_json[misc.CONAN_DEPDENCIES_KEY]["test"] = real_test
        service_json[misc.CONAN_DEPDENCIES_KEY]["build"] = real_build
        with os.fdopen(os.open(service_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                               stat.S_IWUSR | stat.S_IRUSR), 'w') as fp:
            json.dump(service_json, fp, indent=4)
            return changed

    def checkupload(self):
        # 准备上传文件，但不上传
        self.pipe_command(
            [
                'conan search "*"',
                "tail -n +3",
                f"xargs -P 12 -I {{}} conan upload {{}} -c --skip-upload --all -r {self.config.open_remote}",
            ]
        )

    def sync_open_components_to_docker(self):
        """ 准备齐全构建所需文件, 然后上传
        """
        os.chdir(self.conan_home)
        if os.path.exists(self.config.docker_component_home):
            shutil.rmtree(self.config.docker_component_home)
        os.makedirs(self.config.docker_component_home)
        for component in os.listdir(self.source_code_path):
            comp_path = os.path.join(self.source_code_path, component)
            if os.path.isdir(comp_path):
                os.renames(comp_path, f"{self.config.docker_component_home}/{component}")

    def wait_tasks_finish(self, tasks):
        while len(tasks) > 0:
            time.sleep(0.1)
            for p in tasks:
                if p.is_alive():
                    continue
                if p.exitcode is not None and p.exitcode == 0:
                    tasks.remove(p)
                    continue
                for w in tasks:
                    w.terminate()
                sys.exit(p.exitcode)

    def create_work_tree(self):
        """ 创建工作目录树
        """
        os.makedirs(self.source_code_path, exist_ok=True)
        os.makedirs(self.subsys_path, exist_ok=True)
        if os.path.isdir(self.component_path):
            shutil.rmtree(self.component_path)
        os.makedirs(self.component_path, exist_ok=True)

    def fix_all_open_component_dependencies_version(self):
        for component in os.listdir(self.source_code_path):
            comp_path = os.path.join(self.source_code_path, component)
            if os.path.isfile(comp_path):
                os.unlink(comp_path)
                continue
            if not os.path.isdir(comp_path):
                continue
            pi = self.packages.get(component)
            if pi:
                # 固定源码依赖关系
                service_file = os.path.join(comp_path, "mds", "service.json")
                os.chdir(comp_path)
                ret = self.fixed_service_dependencies(service_file)
                if ret:
                    # 有变更时提交变更
                    self.run_command("git add -A", command_key=component)
                    self.run_command("git commit -m \"fixed dependencies package version\"", command_key=component)

    def download_all_component_source_code(self):
        """ 下载所有开放组件源码
        """
        self.crates_and_demo_deploy()
        self.download_open_component_sourcecode()
        self.readme_integration()
        self.fix_all_open_component_dependencies_version()

    def get_all_components_options(self):
        all_options = {}
        dependencies = self.get_manufacture_config('dependencies', [])
        for dep in dependencies:
            name = dep.get('conan')
            if name is None: 
                continue
            option = dep.get('options')
            all_options[name] = option
        return all_options

    def build_all_component(self, enable_luajit):
        """ 构建所有开放组件
        """
        # 构建组件前，获取所有组件的options
        self.all_options = self.get_all_components_options()
        os.chdir(self.source_code_path)
        components = os.listdir(self.source_code_path)
        path = os.path.join(self.source_code_path, WEBUI_APP)
        webui = None
        if os.path.isdir(path):
            webui = BuildComponent(WEBUI_APP, path, self, enable_luajit)
            webui.start()
            components.remove(WEBUI_APP)
        if LIBMC4LUA in components:
            webui = BuildComponent(LIBMC4LUA, path, self, enable_luajit)
            webui.run()
            components.remove(LIBMC4LUA)
        tasks: list[BuildComponent] = []
        for component in components:
            path = os.path.join(self.source_code_path, component)
            thread = BuildComponent(component, path, self, enable_luajit, True)
            thread.start()
            tasks.append(thread)
        # 等待多进程打包完成
        while len(tasks) > 0:
            time.sleep(0.1)
            tmp_tasks = copy.copy(tasks)
            for p in tmp_tasks:
                if p.is_alive():
                    continue
                # 正常退出的任务从components中删除
                if p.exitcode is not None and p.exitcode == 0:
                    components.remove(p.name)
                tasks.remove(p)
        # 如果有剩余组件未打包的，顺序打包
        self.info(f"开始尝试构建: {components}")
        for component in components:
            path = os.path.join(self.source_code_path, component)
            thread = BuildComponent(component, path, self, enable_luajit)
            thread.run()

        while webui and webui.is_alive():
            time.sleep(0.1)

    def clear_workspace(self):
        """ 清理工作空间
        """
        if os.path.exists(self.workspace):
            shutil.rmtree(self.workspace)

    def signal_handler(self, sig, frame):
        self.info("构建开始前清理环境....")

    def signal_exit(self, sig, frame):
        self.signal_handler(sig, frame)
        sys.exit(-1)

    def run(self):
        """ 构建 cmc 归档所需文件
        """
        os.environ['TRANSTOBIN'] = "true"
        self.info(os.getenv('TRANSTOBIN'))
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTSTP, self.signal_exit)
        self.load_package_lock()
        try:
            if self.config.archive_conf is None:
                return
            self.clear_workspace()
            self.create_work_tree()
            self.download_all_component_source_code()
            self.build_all_component(enable_luajit=False)
            if self.enable_luajit:
                self.build_all_component(enable_luajit=True) 
            self.checkupload()
            self.sync_open_components_to_docker()
        except Exception as e:
            self.signal_handler(None, None)
            raise e
        self.signal_handler(None, None)
