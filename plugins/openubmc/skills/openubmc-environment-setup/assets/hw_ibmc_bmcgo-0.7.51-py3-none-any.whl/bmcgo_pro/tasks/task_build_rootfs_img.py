#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
"""
功 能：buildimg_ext4脚本，该脚本 make ext4 image
版权信息：华为技术有限公司，版本所有(C) 2019-2020
"""

import os
import re

from bmcgo import errors
from bmcgo import misc
from bmcgo.tasks.task_build_rootfs_img import TaskClass as BingoBuildRootfsImg

from bmcgo_pro.utils.config import Config


class TaskClass(BingoBuildRootfsImg):
    def __init__(self, config: Config, work_name=""):
        super(TaskClass, self).__init__(config, work_name)
        self.rootfs_img_path = f"{self.config.work_out}/rootfs_iBMC.img"

    def make_rtos_rootfs(self):
        rtos_tar = os.path.join(self.config.sdk_path, "rtos_with_ko.tar.gz")
        # 解压OS
        self.run_command(f"rm -rf {self.rtos_rootfs}", sudo=True)
        self.run_command(f"tar --xattrs --xattrs-include=* -xf {rtos_tar}", sudo=True)
        self.run_command(f"chown -R 0:0 {self.rtos_rootfs}", sudo=True)
        self.info("拷贝RTOS提供的mke2fs.conf配置文件覆盖本地环境中的/etc/mke2fs.conf文件, 确保mkfs.ext4使用该配置文件")
        self.run_command(f"cp -f {self.rtos_rootfs}/etc/mke2fs.conf /etc/mke2fs.conf", sudo=True)
        self.run_command(f"rm -rf {self.rtos_rootfs}/etc/ssh", sudo=True)

    def copy_rtos_modules(self):
        super().copy_rtos_modules()
        self.run_command(f"rm -rf {self.rtos_rootfs}/usr/share/doc/openubmc", sudo=True)

    def copy_ko_modules(self):
        # bmcgo无需copy ko
        pass

    def copy_upgrade_dat_file(self):
        self.run_command(f"mkdir -p  {self.rtos_rootfs}/opt/pme/upgrade", sudo=True)
        dat_files = [
            {"source": "pme_profile_en.dat", "dest": "pme_profile_en"},
            {"source": "datatocheck_upgrade.dat", "dest": "datatocheck_upgrade.dat"},
        ]
        for dat_file in dat_files:
            source = dat_file["source"]
            origin_dat_file_path = f"{self.config.code_path}/manufacture/misc/{source}"
            _, returncode = self.pipe_command([f"file {origin_dat_file_path}", "grep ': data$'"], ignore_error=True)
            if returncode != 0:
                raise errors.BmcGoException(f"{origin_dat_file_path}是系统必要文件且内容不能为空。经检测该文件内容为空，请正确配置该文件。")

            dest = dat_file["dest"]
            dest_dat_file_path = f"{self.rtos_rootfs}/opt/pme/upgrade/{dest}"
            self.run_command(f"cp -df {origin_dat_file_path} {dest_dat_file_path}", sudo=True)
            self.run_command(f"chmod 400 {dest_dat_file_path}", sudo=True)

    def make_img(self):
        if self.config.chip == "1711":
            # 1711使用376M
            self.tools.make_img(self.rootfs_img_path, self.mnt_datafs, "376")
        else:
            # 1712使用740M
            self.tools.make_img(self.rootfs_img_path, self.mnt_datafs, "740")
