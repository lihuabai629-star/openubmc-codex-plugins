#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
"""
功 能：制作烧片文件 ipmc.bin
版权信息：华为技术有限公司，版本所有(C) 2019-2023
"""

import os
import time

from bmcgo import errors

from bmcgo import misc
from bmcgo_pro.utils.config import Config
from bmcgo_pro.tasks.task import Task
from bmcgo_pro.functional.make_emmc_image import BmcgoCommand as MakeEmmcCommand


class TaskClass(Task):
    def __init__(self, config: Config, work_name=""):
        super(TaskClass, self).__init__(config, work_name=work_name)
        self.download_conf = None
        self.sp_bin = None
        self.ibma_bin = None
        self.ipmc_bin_conf = None
        # 构建ipmc.bin的工作目录
        self.build_path = os.path.join(self.config.build_path, "ipmc_bin_build")
        os.makedirs(self.build_path, exist_ok=True)
        self.chdir(self.build_path)

    def run(self):
        # 制作生产装备必须使用-z选项配置0502编码
        if self.config.manufacture_code is None:
            self.info("跳过打包 ipmc.bin 文件, 因为 manufacture 配置为空!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            return

        self._config_set()
        self.chdir(self.config.code_path)

    def _get_config(self):
        if os.path.isfile("config.cfg"):
            return "config.cfg"
        if os.path.isfile("config_detailed.cfg"):
            return "config_detailed.cfg"

        raise errors.BmcGoException("config.cfg文件不存在, 请检查config.cfg文件")

    def _copy_rootca_and_crl(self, files):
        rootca = os.path.join(self.config.work_out, misc.ROOTCA_DER)
        crl = os.path.join(self.config.work_out, misc.CMS_CRL)
        exclude_files = []
        for file in files:
            filename = file.get("file")
            if filename is None:
                continue
            filename = time.strftime(filename, self.config.date)
            dst = file.get("dst")
            if dst is None:
                dst = os.path.basename(filename)
            if dst == misc.ROOTCA_DER:
                exclude_files.append(dst)
            elif dst == misc.CMS_CRL:
                exclude_files.append(dst)
        if os.path.isfile(rootca) and misc.ROOTCA_DER in exclude_files:
            self.tools.copy(rootca, misc.ROOTCA_DER)
        if os.path.isfile(crl) and misc.CMS_CRL in exclude_files:
            self.tools.copy(crl, misc.CMS_CRL)
        return exclude_files

    def _config_set(self):
        self.info("开始打包 ipmc.bin 文件======================================================================>>")
        manu_path = "manufacture/" + self.config.manufacture_code
        self.ipmc_bin_conf = self.get_manufacture_config(manu_path + "/ipmc_bin")
        self.download_conf = self.get_manufacture_config(manu_path + "/download")
        # 如果没有配置，则直接返回False
        if self.ipmc_bin_conf is None:
            self.info("跳过打包 ipmc.bin 文件, 因为在 manifest.yml 中缺少属性 {}".format(manu_path + "/ipmc_bin"))
            return
        # 复制gpp需要使用的文件,记录rootfs_BMC.img、Hi1711_boot_4096.bin
        files = self.get_manufacture_config(f"gpp/files")
        if files is None:
            raise errors.BmcGoException("获取 manifest.yml 中 gpp/files 配置失败, 请检查 gpp/files 配置, 退出 !!!")
        # 复制构建emmc gpp镜像所需的文件
        exclude_files = self._copy_rootca_and_crl(files)
        self.copy_manifest_files(files, exclude_files)
        # 再复制0502包指定的gpp/files
        gpp_files = self.get_manufacture_config(f"manufacture/{self.config.manufacture_code}/gpp/files")
        if gpp_files is not None:
            exclude_files = self._copy_rootca_and_crl(files)
            self.copy_manifest_files(gpp_files, exclude_files)
        # ! 默认ibma与sp的bin文件只有一个，有多个时代码需要修改
        if self.download_conf:
            for bin_conf in self.download_conf:
                if bin_conf.get("type") == "sp":
                    self.sp_bin = bin_conf.get("bin")
                elif bin_conf.get("type") == "ibma":
                    self.ibma_bin = bin_conf.get("bin")
                files = bin_conf.get("files")
                self.copy_manifest_files(files)
        # 复制所有ipmc_bin/files下的文件
        ipmc_bin_files = self.get_manufacture_config(manu_path + "/ipmc_bin/files")
        self.copy_manifest_files(ipmc_bin_files)

        # 复制sp文件
        if self.sp_bin is None or not os.path.isfile(self.sp_bin):
            self.log.warning("SP 文件不存在, 将创建空 SP 文件")
            self.run_command("dd if=/dev/zero of=sp.bin bs=1 count=0 seek=1024")
        else:
            self.link(self.sp_bin, "sp.bin")
        # 复制或制作ibma.bin文件
        if self.ibma_bin is None or not os.path.isfile(self.ibma_bin):
            self.run_command("dd if=/dev/zero of=iBMA.bin bs=1024 count=314573")
            self.run_command('mkfs -V -t vfat -F 32 -n "iBMA" iBMA.bin', sudo=True)
        else:
            self.link(self.ibma_bin, "iBMA.bin")
        # 制作ipmc.bin
        self._make_ipmc_bin()

    def _make_ipmc_bin(self):
        emmc_layout = self.get_manufacture_config(f"manufacture/{self.config.manufacture_code}/ipmc_bin/emmc_layout")
        if not emmc_layout:
            config = self._get_config()
            # 使用工具生成ipmc.bin
            self.run_command(f"unix2dos {config}")
            self.run_command(f"converfile {config}")

            self.run_command("dd if=ipmc.bin of=user_data_256.bin bs=1M count=256")
            # 给 GPP4 烧写空文件，使 GPP4 分区能够 mount 上 (128M)
            self.run_command("dd if=/dev/zero of=GPP_4.img bs=128M count=1")
            self.run_command("mkfs.ext4 GPP_4.img", sudo=True)
            # 校验p8分区偏移
            portion8_info, _ = self.pipe_command(["fdisk -l ipmc.bin", "grep ipmc.bin8"], capture_output=True)
            _, start, end, _, size, *_ = portion8_info.strip().split()
            if start != "12615680" or end != "12648447" or size != "16M":
                raise errors.BmcGoException("ipmc分区错误，portion8分区偏移不能修改，请检查分区配置文件")
        else:
            layout = emmc_layout.get("user").get("layout")
            argv = ["-conf", layout, "-o", "ipmc.bin"]
            cmd = MakeEmmcCommand(self.config.bconfig, argv)
            cmd.run()
            gp3_size = emmc_layout.get("gp3").get("size")
            linx_bin_path = f"{self.config.linx_build_dir}/out/LiteOS_M.bin"
            top_header_path = f"{self.config.linx_build_dir}/out/gpp4_top_hdr.bin"
            self.run_command(f"make_gpp3.sh {gp3_size[:-1]} {linx_bin_path} {top_header_path}")

        # make_emmc_flash_bin 工具需要单板名入参，在当前目录查找GPP_rootfs.bin文件
        # make_emmc_flash_bin 会生成Hi1711_THGBMHG6C1LBAIL_output.m4i文件，该文件是后续制作烧片m4i文件的一部分
        self.run_command("make_emmc_flash_bin {}".format(self.config.board_name))
        self.link("Hi1711_THGBMHG6C1LBAIL_output.m4i", f"{self.config.work_out}/m4i_template.m4i")

        self.run_command(
            "acxmlgenerator -b emmc_output_ipmc.bin -x AUTO_BURNING_CONFIG.hwxml -o AUTO_BURNING_CONFIG.acxml")
        self.link("AUTO_BURNING_CONFIG.acxml", os.path.join(self.config.work_out, "AUTO_BURNING_CONFIG.acxml"))
        self.link("emmc_output_ipmc.bin", os.path.join(self.config.work_out, "ipmc.bin"))
        if os.path.exists("iBMA_version.ini"):
            self.link("iBMA_version.ini", os.path.join(self.config.work_out, "iBMA_version.ini"))
        self.info("打包 ipmc.bin 成功 =====================================================================>>")
