#!/usr/bin/env python
# coding: utf-8
# Copyright © Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.

"""
文件名：work_build_conan.py
功能：编译产品依赖包
版权信息：华为技术有限公司，版本所有(C) 2019-2020
"""

import os
import shutil
from git import Repo
from bmcgo_pro.tasks.task import Task

DOCKER_LOGINUSER = "root" # 与Dockerfile保持一致


class TaskClass(Task):
    def docker_env_check(self):
        if shutil.which("docker") is None:
            raise Exception("本地没有安装 docker 命令, 请检查环境")
        else:
            self.info("docker 构建环境正常, 开始构建 docker 镜像")
            return True

    def set_docker_name(self, docker_name):
        self.config.container_tag = docker_name

    def build_docker(self):
        filename = "manifest"
        os.chdir(self.config.partner_docker_home)
        if os.path.exists(filename):
            shutil.rmtree(filename)
        cmd = f'rsync -av --progress {self.config.code_root} . ' + \
            f'--exclude=partner_docker/manifest/ --exclude=.git/ --exclude=output/ --exclude=temp'
        self.run_command(cmd)
        # 路径直接映射, 在当前路径构建镜像, 则直接映射到 docker 里面
        self.run_command(f"docker build --build-arg 'CODEROOT={os.path.abspath(self.config.code_root)}'\
            --build-arg 'LOGINUSER={DOCKER_LOGINUSER}' -t {self.config.container_tag} -f Dockerfile .", sudo=True)

    def run(self):
        if self.docker_env_check() is True:
            self.build_docker()