#!/usr/bin/env python3
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
from bmcgo_pro.tasks.task import Task


class TaskClass(Task):
    def upload_all(self):
        self.pipe_command(['conan search "*"', 'tail -n +3',
            f'xargs -P 12 -I {{}} conan upload {{}} -c --all -r {self.config.open_remote}'])

    def run(self):
        if not self.config.open_remote:
            return
        self.upload_all()
        self.info("Conan Upload 完成...")