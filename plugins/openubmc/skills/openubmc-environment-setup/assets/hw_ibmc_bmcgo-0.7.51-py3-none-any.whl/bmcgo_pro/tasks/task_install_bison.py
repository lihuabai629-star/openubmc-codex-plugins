#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2023-2025. All rights reserved.

'''
功    能：下载并安装bison工具
版权信息：华为技术有限公司，版本所有(C) 2022-2022
修改记录：2022-12-16 创建
'''
import os
import shutil
from bmcgo_pro.tasks.task import Task

bison_url = 'https://cmc-hgh-artifactory.cmc.tools.huawei.com/'
bison_url += 'artifactory/opensource_general/Bison/3.8.2/package/bison-3.8.2.tar.xz'
biosn_zip_name = bison_url[bison_url.rindex('/') + 1:]


class TaskClass(Task):
    def __init__(self, config, work_name=""):
        super(TaskClass, self).__init__(config, work_name)
        self.bison_dir = os.path.join(self.config.temp_path, "bison_dir")

    def run(self):
        self.info('apt 卸载 ...')
        self.run_command(f"apt remove -y bison", sudo=True)

        self.info('清理目录 ...')
        shutil.rmtree(self.bison_dir, ignore_errors=True)

        self.info('开始下载 bison ...')
        self.tools.check_path(self.bison_dir)
        os.chdir(self.bison_dir)
        self.run_command(f"wget --no-check-certificate {bison_url}")
        self.info('下载 bison 结束')

        self.info('解压 bison ...')
        os.makedirs("bison", exist_ok=True)
        self.run_command(f"tar -xf {biosn_zip_name} -C bison --strip-component=1")
        self.chdir("bison")

        self.info('执行配置命令并构建 bison ...')
        self.run_command("./configure")
        self.run_command("make", sudo=True)
        self.run_command("make uninstall", sudo=True)
        self.run_command("make install", sudo=True)
        self.info('安装 bison 结束')
