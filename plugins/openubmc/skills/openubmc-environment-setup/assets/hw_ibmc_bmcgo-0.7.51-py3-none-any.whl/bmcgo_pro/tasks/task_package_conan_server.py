#!/usr/bin/env python3
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
import os
from multiprocessing import Process

from bmcgo_pro.tasks.task import Task
from bmcgo_pro.utils.config import Config


class TarConan(Process):
    def __init__(self, data_dir, tar_file, name, work):
        super().__init__()
        self.data_dir = data_dir
        self.tar_file = tar_file
        self.work = work
        self.name = name

    def run(self):
        cmd = f'tar -cvzf "{self.tar_file}" -C {self.data_dir} {self.name}'
        self.work.run_command(cmd)


class TaskClass(Task):
    def __init__(self, config: Config, work_name=""):
        """ 初始化

        Args:
            config (Config): config 类, 类似于上帝类, 基本能取到所有资源
            work_name (str, optional): work 的名字, 默认为空
        """
        super(TaskClass, self).__init__(config, work_name=work_name)
        self.community_path = os.path.join(self.config.output_path, "packet", self.config.archive_path)
        self.conan_server = os.path.expanduser('~')

    def check_conan_server(self):
        for remote in self.config.conan_remotes:
            if 'http://0.0.0.0:9300/' == remote.get(self.config.open_remote, None):
                return True
        return False

    def run(self):
        if not self.check_conan_server():
            return
        self.chdir(self.community_path)
        tar_file = os.path.join(self.community_path, 'conan_server.tar.gz')
        tar = TarConan(self.conan_server, tar_file, '.conan_server', self)
        tar.start()
        tar.join()
        self.info("Conan Server Packaging Finished...")