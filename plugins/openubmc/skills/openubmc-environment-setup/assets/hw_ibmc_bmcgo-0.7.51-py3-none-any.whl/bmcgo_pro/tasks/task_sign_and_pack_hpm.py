#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
"""
功 能：buildimg_ext4脚本，该脚本 make ext4 image
版权信息：华为技术有限公司，版本所有(C) 2019-2020
"""
from bmcgo.tasks.task_sign_and_pack_hpm import TaskClass as BingoSignPackHpm


class TaskClass(BingoSignPackHpm):

    # 重写在线签名逻辑
    def _online_sign(self):
        self.chdir(self.config.build_path)
        primary_sign_dep_file = f"{self.config.board_path}/sign_hpm.xml"
        self.run_command(f"cp {primary_sign_dep_file} sign_hpm.xml")

        # 请勿挪动此语句位置(CI和本地构建均使用到)
        self.tools.py_sed("sign_hpm.xml", "(?<=path=\").*(?=\")", self.config.work_out)

        self.info("在线签名")
        # CI要对这里的脚本进行替换，请勿随意换行！
        self.info(f"self.config.build_path: {self.config.build_path}")
        self.run_command("java -jar /usr/local/signature-jenkins-slave/signature.jar sign_hpm.xml")
        self.run_command(f"cp crldata.crl  {self.config.work_out}/cms.crl")
