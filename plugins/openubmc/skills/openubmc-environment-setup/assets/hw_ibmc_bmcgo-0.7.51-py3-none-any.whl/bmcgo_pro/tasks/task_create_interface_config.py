#!/usr/bin/env python3
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.

import os
import shutil

from bmcgo.tasks.task_create_interface_config import TaskClass as BingoCreateInterfaceConfig
from bmcgo.utils.mapping_config_patch import MappingConfigGenerate

from bmcgo_pro.utils.config import Config
from bmcgo_pro.tasks.task import Task


class TaskClass(Task, BingoCreateInterfaceConfig):
    def __init__(self, config: Config, work_name=""):
        super(TaskClass, self).__init__(config, work_name)

    @BingoCreateInterfaceConfig.execute_all_interface
    def get_resource_config_file(self, interface):
        config_path = os.path.join(self.rootfs_path, "opt/bmc/apps", interface, "interface_config")
        if not os.path.isdir(config_path):
            self.warning(f"{interface}接口配置文件不存在")
            return
        os.makedirs(self.product_temp_path, exist_ok=True)
        output_config_path = os.path.join(self.product_temp_path, interface)
        if os.path.exists(output_config_path):
            shutil.rmtree(output_config_path)
        shutil.copytree(config_path, output_config_path)

    @BingoCreateInterfaceConfig.execute_all_interface
    def custom_config_patch(self, interface, custom_temp_path, custom):
        config_file_path = os.path.join(custom_temp_path, interface)
        if not os.path.exists(config_file_path):
            return
        generate_work = MappingConfigGenerate(self.config, config_path=config_file_path, custom=custom)
        try:
            generate_work.run()
        except Exception as e:
            self.warning("生成{}接口配置时发生错误: {}".format(custom, e))

    def run(self):
        try:
            self.info("开始生成全量接口配置")
            self.create_interface_config()
            self.info("生成全量接口配置完成")

        except Exception as e:
            self.warning("生成全量接口配置时发生错误: {}".format(e))
            error_message = str(e)
            if 'Permission denied' in error_message:
                self.warning("权限不足，无法生成全量接口配置，若需要生成全量接口配置，请使用sudo bmcgo build")
