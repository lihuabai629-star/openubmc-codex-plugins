#!/usr/bin/python3
# coding: utf-8
# 版权所有 (c) 华为技术有限公司 2023-2023


class CTypeBase(object):
    def __init__(self, c_type, c_len):
        self.c_type = c_type
        self.c_len = c_len
        pass


class CTypes():
    types: dict = {
        "U8": CTypeBase(
                       c_type="guint8 <arg_name><bit_field>",
                       c_len=1),
        "U8[]": CTypeBase(
                       c_type="guint8 <arg_name>[<type_len>]<bit_field>",
                       c_len=1),
        "S16": CTypeBase(
                        c_len=2,
                        c_type="gint16 <arg_name><bit_field>"),
        "S16[]": CTypeBase(
                       c_type="gint16 <arg_name>[<type_len>]<bit_field>",
                       c_len=2),
        "U16": CTypeBase(
                       c_type="guint16 <arg_name><bit_field>",
                       c_len=2),
        "U16[]": CTypeBase(
                       c_type="guint16 <arg_name>[<type_len>]<bit_field>",
                       c_len=2),
        "S32": CTypeBase(
                       c_type="gint32 <arg_name><bit_field>",
                       c_len=4),
        "S32[]": CTypeBase(
                       c_type="gint32 <arg_name>[<type_len>]<bit_field>",
                       c_len=4),
        "U32": CTypeBase(
                       c_type="guint32 <arg_name><bit_field>",
                       c_len=4),
        "U32[]": CTypeBase(
                       c_type="guint32 <arg_name>[<type_len>]<bit_field>",
                       c_len=4,
                       ),
        "S64": CTypeBase(
                       c_type="gint64 <arg_name><bit_field>",
                       c_len=8),
        "S64[]": CTypeBase(
                       c_type="gint64 <arg_name>[<type_len>]<bit_field>",
                       c_len=8,),
        "U64": CTypeBase(
                       c_type="guint64 <arg_name><bit_field>",
                       c_len=8),
        "U64[]": CTypeBase(
                       c_type="guint64 <arg_name>[<type_len>]<bit_field>",
                       c_len=8,
                       ),
        "Double": CTypeBase(
                       c_type="gdouble <arg_name>",
                       c_len=8),
        "Double[]": CTypeBase(
                       c_type="gdouble <arg_name>[<type_len>]",
                       c_len=8,),
        "String": CTypeBase(
                       c_type="gchar <arg_name>[<type_len>]",
                       c_len=1),
        "String *": CTypeBase(
                       c_type="gchar *<arg_name>",
                       c_len=1),
        "U8 *": CTypeBase(
                       c_type="guint8 *<arg_name>",
                       c_len=1),
    }
