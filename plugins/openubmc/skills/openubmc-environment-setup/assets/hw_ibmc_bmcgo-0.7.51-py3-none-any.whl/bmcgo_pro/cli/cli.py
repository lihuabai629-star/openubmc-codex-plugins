#!/usr/bin/python3
# coding: utf-8
# 版权所有 (c) 华为技术有限公司 2023-2023
import os
import signal
import sys
import subprocess
import traceback

from bmcgo import errors
from bmcgo.frame import Frame
from bmcgo.cli.cli import Command as BingoCli
from bmcgo.cli.cli import ExtraCases
from bmcgo.cli.cli import prepare_conan
from bmcgo.cli.cli import run as BmcgoRun
from conan import conan_version

from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.utils.config import Config
from bmcgo_pro.bmcgo_config import BmcgoConfig
from bmcgo_pro.component.build import BuildComp
from bmcgo_pro import __version__

cwd = os.getcwd()
tools = Tools()
log = tools.log

SKIP_CONFIG_COMMANDS = ("config")


class Command(BingoCli):
    """A single command of the bmcgo application, with all the first level commands. Manages the
    parsing of parameters and delegates functionality in collaborators. It can also show the
    help of the tool.
    """
    def __init__(self):
        super().__init__(BmcgoConfig())
        self.inte_cmds["qemu"] = "qemu"
        bmcgo_install_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.ext_targets_dir = os.path.join(bmcgo_install_path, "target")

    # qemu package
    def qemu(self, *args):
        """
        创建仿真环境，运行构建的产品包
        """
        is_integrated, _ = self._is_integrated_project()
        if not is_integrated:
            raise errors.NotIntegrateException("检测到当前环境中缺少frame.py，可能不是一个合法的manniest仓")
        return self.frame_build(args=['-qi'])

    def frame_build(self, args=None):
        _, work_dir = self._is_integrated_project()
        os.chdir(work_dir)
        config = Config(self.bconfig)
        frame = Frame(self.bconfig, config)
        frame.parse(args, self.ext_targets_dir)
        return frame.run()

    def build(self, *args):
        """
        构建出包

            组件需要支持多种跨平台构建场景，典型的包括DT（X86-64）、交叉编译（arm64）
        """
        if self.__is_valid_component:
            os.chdir(self.bconfig.component.folder)
            BuildComp(self.bconfig).run()
        super().build(*args)

    def show_version(self):
        log.info("bmcgo 版本为: %s", __version__)
        super().show_version()

    def _get_command_group(self):
        if self._command_group:
            return self._command_group
        self._gen_command_group_base()
        functional_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "functional")
        self._load_functional(functional_path)
        return self._gen_command_group()


def check_environment():
    cmd = tools.run_command("uname -a", capture_output=True, command_echo=False)
    if "microsoft-standard-WSL" in cmd.stdout:
        memory_command = ["sh", "-c", "free -g | grep Mem | awk '{print $2}'"]
        memory_result = subprocess.check_output(memory_command).decode().strip()
        if int(memory_result) > 16:
            wsl_link = "https://ibmc.openx.huawei.com/#/docs/software_engineering/howto_use_wsl"
            log.warning("当前wsl内存设置大于16G，请参考文档限制内存：%s", wsl_link)
    faq_link = "https://ibmc.openx.huawei.com/#/docs/software_engineering/faq"
    log.warning("自助解决文档：%s", faq_link)


def main(args):
    os.environ["OPENUBMC_COMMUNITY_NAME"] = "ibmc"
    if conan_version.major == 1:
        os.environ["OPENUBMC_DEFAULT_CONAN_USER"] = "hw.ibmc.release"
        os.environ["OPENUBMC_DEFAULT_CONAN_USER_DEV"] = "hw.ibmc.dev"
    os.environ["OPENUBMC_DEFAULT_CONAN_REMOTE"] = "ibmc_dev"
    os.environ["OPENUBMC_DEFAULT_BOARD_NAME"] = "TaiShan200_2280v2"
    os.environ["OPENUBMC_DEFAULT_LOGO"] = "iBMC"
    # 默认厂商名称，可以使用manifest/vendor配置
    if not os.environ.get("OPENUBMC_DEFAULT_VENDOR"):
        os.environ["OPENUBMC_DEFAULT_VENDOR"] = "Huawei Technology Inc."
    os.environ["OPENUBMC_ENCRYPTO_HPM_PACKAGE"] = "True"

    command = Command()
    if args in ["-v", "--version"]:
        command.show_version()
    extra_cases_file = os.path.join(
        os.path.dirname(__file__), "..", "error_cases", "cases.yml"
    )
    extra_cases = ExtraCases(extra_cases_file, "bmcgo_cases")
    error = BmcgoRun(args, command, extra_cases)
    if error and error != 0 and not BmcgoConfig().partner_mode:
        check_environment()
    return error
