#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2024. All rights reserved.
"""
归档openUBMC需要的组件及工具制品到指定目录。

输入: yml配置文件, 格式如下：
components:
    xxx:
    xxx:
archive:
    - archive_path: xxx/xx (cmc归档路径)
        source:
            foo: (制品来源分类目录)
                - xx (相对于分类目录的制品目录)
            bar:
                - yy
                - tt
输出: 制品集合
"""
import os
import sys
import argparse
from typing import List
from multiprocessing import Pool

import yaml
from bmcgo.errors import ConfigException, BmcGoException

from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.functional.full_component import BuildComponent

tools = Tools()
cwd = os.getcwd()


class OpenUBMCArchive:
    conan_server = "openubmc_dev"

    def __init__(self, args: List[str]):
        parser = argparse.ArgumentParser(description="openUBMC制品归档工具")
        parser.add_argument("-config", "--config_yml", help="openUBMC制品配置yml的路径", required=True)
        parser.add_argument("-src", "--source", help="openUBMC制品来源路径", required=True)
        parser.add_argument("-dest", "--destination", help="openUBMC制品存放目录, 默认当前执行路径", default=cwd)
        parser.add_argument("-ip", "--conan_server_ip", help="Conan Server的IP地址", default="0.0.0.0")
        parsed_args, _ = parser.parse_known_args(args)

        self.config_yml = parsed_args.config_yml
        self.source_dir = os.path.join(cwd, parsed_args.source)
        self.destination = os.path.join(cwd, parsed_args.destination)
        self.conan_server_ip = parsed_args.conan_server_ip
        if not os.path.isfile(self.config_yml):
            raise ConfigException(f"配置yml文件{self.config_yml}不存在")

    @staticmethod
    def package_component(comp_name: str, category_paths: List[str]):
        os.chdir(tools.conan_data)
        OpenUBMCArchive.delete_comp_sensitive_info(comp_name)
        tools.run_command(["tar", "-zcf", f"{comp_name}.tar.gz", comp_name])
        for category_path in category_paths:
            tools.run_command(["cp", "-f", f"{comp_name}.tar.gz", category_path])
        tools.run_command(["rm", "-f", f"{comp_name}.tar.gz"])

    @staticmethod
    def delete_comp_sensitive_info(comp_name: str):
        comp_dir = os.path.join(tools.conan_data, comp_name)
        comp_versions = os.listdir(comp_dir)
        for version in comp_versions:
            for channel in ["rc", "stable"]:
                BuildComponent.delete_sensitive_info(comp_name, version, channel)

    def run(self):
        self.conan_init()
        self.download_packages()
        self.package_components()
        self.archive()

    def archive(self):
        archive_config = self.get_archive_config()
        for archive in archive_config:
            self.archive_files(self.source_dir, archive)

    def archive_files(self, source_dir: str, archive: dict):
        archive_path = os.path.join(self.destination, archive.get("archive_path", ""))
        sources: List[dict] = archive.get("sources", [])
        cur_dir = os.getcwd()
        for source in sources:
            compress_cmd: str = source.get("compress_cmd", None)
            os.chdir(cur_dir)
            paths = source.get("paths", [])
            output = source.get("output", None)
            target_path = os.path.join(archive_path, output)
            tools.run_command(f"mkdir -p {os.path.dirname(target_path)}")
            if compress_cmd:
                os.chdir(source_dir)
                cmds = compress_cmd.split()
                tools.run_command([*cmds, target_path, *paths])
                continue

            for path in paths:
                full_path = os.path.join(source_dir, path)
                dest = os.path.join(archive_path, os.path.dirname(full_path))
                tools.run_command(f"cp -rf {full_path} {dest}")

    def get_archive_config(self):
        with open(self.config_yml) as fp:
            config_data: dict = yaml.safe_load(fp)
            archive_config = config_data.get("archive")
        return archive_config

    def conan_init(self):
        tools.log.info("================初始化conan配置==========")
        tools.run_command(f"conan remote remove {self.conan_server}", ignore_error=True)
        tools.run_command(f"conan remote add {self.conan_server} http://{self.conan_server_ip}:9300")
        tools.run_command(f"conan user demo -p demo -r {self.conan_server}")

    def get_packages(self, stage: str):
        ret = tools.run_command(
            f"conan search *@hw.ibmc.release/{stage} -r {self.conan_server} --raw",
            capture_output=True,
        )
        pkgs = ret.stdout.splitlines()
        return pkgs

    def download_package(self, pkg: str):
        ret = tools.run_command(f"conan download -r {self.conan_server} {pkg}", uptrace=1)
        if ret.returncode != 0:
            raise BmcGoException(f"Download {pkg} failed")

    def download_packages(self):
        tools.log.info("================从conan server下载所有conan包==========")
        tools.run_command("rm -rf ~/.conan/data")
        stable_pkgs = self.get_packages("stable")
        rc_pkgs = self.get_packages("rc")

        all_pkgs = stable_pkgs + rc_pkgs
        process_count = min(len(all_pkgs), os.cpu_count())
        tools.log.info(f"创建 {process_count} 个进程下载组件")
        pool = Pool(processes=process_count)

        for pkg in all_pkgs:
            pool.apply_async(func=self.download_package, args=(pkg,))

        pool.close()
        pool.join()

    def get_components_category_map(self) -> dict:
        with open(self.config_yml, "r") as f:
            data = yaml.safe_load(f)

        components_category_map = {}
        components = data.get("components")
        for category, comps in components.items():
            for item in comps:
                comp_name = item.get("conan")
                if components_category_map.get("comp_name"):
                    components_category_map[comp_name] += [category]
                else:
                    components_category_map[comp_name] = [category]
        return components_category_map

    def package_components(self):
        tools.log.info("============打包归档组件到对应分类目录=========")
        components_category_map = self.get_components_category_map()
        cur_dir = os.getcwd()

        comps = os.listdir(tools.conan_data)
        process_count = min(len(comps), os.cpu_count())
        tools.log.info(f"创建 {process_count} 个进程打包组件")
        pool = Pool(processes=process_count)

        for comp_name in comps:
            categories: List[str] = components_category_map.get(comp_name, ["others"])
            category_paths = []
            for category in categories:
                category_path = os.path.join(self.source_dir, category)
                category_paths.append(category_path)
                tools.run_command(f"mkdir -p {category_path}")
            pool.apply_async(func=self.package_component, args=(comp_name, category_paths))

        pool.close()
        pool.join()
        os.chdir(cur_dir)


if __name__ == "__main__":
    openubmc_archive = OpenUBMCArchive(sys.argv)
    openubmc_archive.run()
