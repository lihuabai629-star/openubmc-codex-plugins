#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2024. All rights reserved.
import os
import json
import stat
import sys
import argparse
from typing import List
from concurrent.futures import ProcessPoolExecutor, Future

from bmcgo import misc
from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.functional.full_component import BuildComponent

tools = Tools()


class GeneratePackages:

    def __init__(self, args):
        parser = argparse.ArgumentParser(description="conan制品归档工具")
        parser.add_argument("--strip", help="是否strip二进制的符号表", action=misc.STORE_TRUE)
        parsed_args, _ = parser.parse_known_args(args)
        self.strip = parsed_args.strip

    @staticmethod
    def package_component(comp_name: str, strip=False):
        GeneratePackages.delete_comp_sensitive_info(comp_name, strip)

    @staticmethod
    def package_metadata(comp_name, comp_version, stage):
        metadate_path = os.path.join(
            tools.conan_data,
            comp_name,
            comp_version,
            "hw.ibmc.release",
            stage,
            "metadata.json"
        )
        if not os.path.exists(metadate_path):
            return
        with open(metadate_path, "r") as conf_fp:
            metadata = json.load(conf_fp)
        metadata_pakages = metadata.get("packages", {})
        if metadata_pakages:
            sorted_packages = dict(sorted(metadata_pakages.items()))
            metadata["packages"] = sorted_packages
            sorted_metadata = json.dumps(metadata, ensure_ascii=False)
            with os.fdopen(os.open(metadate_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                                   stat.S_IWUSR | stat.S_IRUSR), "w") as f:
                f.write(sorted_metadata)

    @staticmethod
    def delete_comp_sensitive_info(comp_name: str, strip=False):
        comp_dir = os.path.join(tools.conan_data, comp_name)
        comp_versions = os.listdir(comp_dir)
        for version in comp_versions:
            for channel in ["rc", "stable"]:
                GeneratePackages.package_metadata(comp_name, version, channel)
                BuildComponent.delete_sensitive_info(comp_name, version, channel, strip)

    @staticmethod
    def package_components(strip=False):
        comps = os.listdir(tools.conan_data)
        pool = ProcessPoolExecutor()
        future_tasks: List[Future] = []
        for comp in comps:
            task = pool.submit(GeneratePackages.package_component, comp, strip)
            future_tasks.append(task)

        pool.shutdown()
        for task in future_tasks:
            task_exception = task.exception()
            if task_exception is not None:
                raise task_exception

    def run(self):
        self.package_components(self.strip)


if __name__ == "__main__":
    gen = GeneratePackages(sys.argv)
    gen.run()
