#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2024. All rights reserved.
"""
下载并收集RTOS/SDK/编译器等构建编译工具链相关的工具及其他文件。

输入: yml配置文件, 格式如下：
archive_source:
    - src_path: xxx (当type为artget时, 填写artget xml格式文件)
      type: artget | file
      move: (可选)
        - source: file
          dest: xx/zz
      destination: yyy (可选，默认为输出目录的当前目录)
输出: 文件/工具集合
"""
import os
import sys
import re
import argparse
from typing import List

import yaml
from bmcgo.errors import ConfigException, NotFoundException

from bmcgo_pro.bmcgo_config import BmcgoConfig
from bmcgo_pro.utils.tools import Tools
from bmcgo_pro.utils.artget_tools import ArtgetDownloadTool

tools = Tools()
cwd = os.getcwd()


class ArchiveSource:
    def __init__(self, args: List[str]):
        parser = argparse.ArgumentParser(description="Archive Source收集脚本")
        parser.add_argument("-config", "--config_yml", help="Archive Source配置的路径", required=True)
        parser.add_argument("-src", "--source", help="文件/工具制品来源主路径", required=True)
        parser.add_argument("-dest", "--destination", help="Archive Source的文件/工具存放目的路径", required=True)
        parsed_args, _ = parser.parse_known_args(args)
        self.config_yml = parsed_args.config_yml
        self.source_dir = os.path.join(cwd, parsed_args.source)
        self.destination = os.path.join(cwd, parsed_args.destination)
        self.bconfig = BmcgoConfig()
        if not os.path.isfile(self.config_yml):
            raise ConfigException(f"配置yml文件{self.config_yml}不存在")

    @staticmethod
    def get_compress_files(files_dir, source_files):
        files = []
        for file_name in os.listdir(files_dir):
            for source_file in source_files:
                pattern = re.compile(f"{source_file}")
                if pattern.fullmatch(file_name):
                    files.append(file_name)
        return files

    def run(self):
        archive_source_config = self.get_archive_source_config()
        for tool in archive_source_config:
            src_path: str = os.path.expanduser(tool.get("src_path"))
            if not os.path.isabs(src_path):
                src_path = os.path.join(self.source_dir, src_path)
            real_src_path = src_path.rstrip("/*")
            if not os.path.exists(real_src_path):
                raise FileNotFoundError(f"{real_src_path}工具原始目录或文件不存在。")
            tool_type = tool.get("type")
            compresses = tool.get("compress", [])
            moves = tool.get("move", [])
            destination = os.path.join(self.destination, tool.get("destination", ""))
            tools.run_command(f"mkdir -p {destination}")
            if tool_type == "artget":
                self.artget_pull(src_path, destination, moves, compresses=compresses)
                continue
            if tool_type == "file":
                tools.run_command(f"cp -pf '{src_path}' '{destination}'", sudo=True)
                continue
            if tool_type == "dir":
                self.copy_files(src_path, destination, moves, compresses=compresses)
                continue

    def get_archive_source_config(self):
        if not os.path.isfile(self.config_yml):
            raise NotFoundException(f"{self.config_yml}文件不存在。")
        with open(self.config_yml) as f:
            config_data: dict = yaml.safe_load(f)
            return config_data.get("archive_source")

    def artget_pull(self, src_path: str, destination: str, moves: List[dict], compresses: List[dict]):
        real_src_path = os.path.join(cwd, src_path)
        artget_tool = ArtgetDownloadTool(real_src_path, destination)
        artget_tool.download()
        # 签名文件不需要进行删除
        signature_types = ["asc", "hwp7s", "p7s"]
        for file in os.listdir(destination):
            file_type = file.split(".")[-1]
            file_dest = os.path.join(destination, file)
            if file_type in signature_types:
                os.remove(file_dest)
                continue

        self.move_files(destination, moves)
        self.compress_files(destination, compresses)

    def copy_files(self, src_path: str, destination: str, moves: List[dict], compresses: List[dict]):
        for file in os.listdir(src_path):
            path = os.path.join(src_path, file)
            tools.run_command(f"cp -rpf '{path}' '{destination}'", sudo=True)
        files_dir = os.path.join(destination)
        self.move_files(files_dir, moves)
        self.compress_files(files_dir, compresses)

    def move_files(self, files_dir: str, moves: List[dict]):
        if not moves:
            return

        for root, _, files in os.walk(files_dir):
            for file in files:
                self.move_file(os.path.join(root, file), moves)

    def move_file(self, file_path: str, moves: List[dict]):
        file_name = os.path.basename(file_path)
        for move in moves:
            source = move.get("source")
            move_dest: str = os.path.join(self.destination, move.get("dest"))
            pattern = re.compile(f"{source}")
            move_path = move_dest
            if not move_dest.endswith("/"):
                move_path = os.path.dirname(move_dest)
            if not os.path.exists(move_path):
                tools.run_command(f"mkdir -p {move_path}")
            if pattern.fullmatch(file_name):
                tools.run_command(f"mv -f '{file_path}' '{move_dest}'")

    def compress_files(self, files_dir: str, compresses: List[dict]):
        if not compresses:
            return
        cur_dir = os.getcwd()
        os.chdir(files_dir)
        for compress in compresses:
            sources = compress.get("source", [])
            target_path = os.path.join(files_dir, compress.get("target"))
            files = self.get_compress_files(files_dir, sources)
            tools.run_command(["tar", "-zcf", target_path, *files])
            tools.run_command(["rm", "-rf", *files])
        os.chdir(cur_dir)


if __name__ == "__main__":
    archive_source = ArchiveSource(sys.argv)
    archive_source.run()
