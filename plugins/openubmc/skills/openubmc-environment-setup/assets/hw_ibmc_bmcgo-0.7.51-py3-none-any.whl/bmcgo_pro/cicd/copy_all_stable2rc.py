#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright © Huawei Technologies Co., Ltd. 2024. All rights reserved.
import os
from typing import List
from concurrent.futures import ProcessPoolExecutor, Future

from bmcgo import misc
from bmcgo.component.component_helper import STAGE_STABLE, STAGE_RC
from bmcgo_pro.utils.tools import Tools

tools = Tools()


class CopyAllStable2rc:
    def __init__(self):
        pass

    @staticmethod
    def copy_stable2rc(comp: str):
        com_folder = os.path.join(tools.conan_data, comp)
        cwd = os.getcwd()
        os.chdir(com_folder)
        for version in os.listdir(com_folder):
            pkg = f"{comp}/{version}@{misc.conan_user()}/{STAGE_STABLE}"
            if not os.path.exists(
                os.path.join(tools.conan_data, pkg.replace("@", "/"))
            ):
                continue
            tools.run_command(f"conan copy {pkg} {misc.conan_user()}/{STAGE_RC} --all --force")
        os.chdir(cwd)

    @staticmethod
    def copy_all_stable2rc():
        comps = os.listdir(tools.conan_data)
        tools.log.info(f"创建多进程获取复制conan data下所有组件的stable到rc版本...")
        pool = ProcessPoolExecutor()
        future_tasks: List[Future] = []
        for comp in comps:
            task = pool.submit(CopyAllStable2rc.copy_stable2rc, comp)
            future_tasks.append(task)

        pool.shutdown()
        for task in future_tasks:
            task_exception = task.exception()
            if task_exception is not None:
                raise task_exception

    def run(self):
        self.copy_all_stable2rc()


if __name__ == "__main__":
    gen = CopyAllStable2rc()
    gen.run()
