#!/usr/bin/env python3
# coding:utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
import sqlite3
from sqlite3 import Connection
import os
import shutil
import logging

# 在代码开头添加基本配置
logging.basicConfig(level=logging.INFO)


def merge_sqlite_databases(base_path, merge_path):
    """
    合并两个 SQLite 数据库文件，专门处理 recipes 和 packages 表
    
    参数:
        base_path (str): 基础文件路径(将把数据合并到这个数据库)
        merge_path (str): 合并文件路径(将从这个数据库读取数据)
    """
    base_db_path = os.path.join(base_path, "cache.sqlite3")
    merge_db_path = os.path.join(merge_path, "cache.sqlite3")
    # 检查文件是否存在
    if not os.path.exists(base_db_path):
        raise FileNotFoundError(f"数据库文件 A 不存在: {base_db_path}")
    
    if not os.path.exists(merge_db_path):
        raise FileNotFoundError(f"数据库文件 B 不存在: {merge_db_path}")
    
    # 连接数据库
    conn_base = sqlite3.connect(base_db_path)
    conn_merge = sqlite3.connect(merge_db_path)
    
    merge_table(base_path, merge_path, conn_base, conn_merge)
    
    # 提交更改并关闭连接
    conn_base.commit()
    conn_base.close()
    conn_merge.close()
    logging.info("数据库合并完成!")


def merge_table(base_path, merge_path, conn_base: Connection, conn_merge: Connection):
    # 定义要处理的表
    tables = ['recipes', 'packages']
    for table_name in tables:
        logging.info(f"处理表: {table_name}")

        cursor_merge = conn_merge.cursor()
        # 获取表结构信息
        cursor_merge.execute(f"PRAGMA table_info({table_name})")
        columns_info = cursor_merge.fetchall()
        columns = [col[1] for col in columns_info]
        
        # 构建列名字符串
        columns_str = ', '.join(columns)
        
        # 获取主键列（如果有）
        if table_name == "recipes":
            primary_keys = ["reference", "rrev"]
        else:
            primary_keys = ["reference", "rrev", "pkgid"]
        
        # 如果没有明确的主键，使用所有列作为比较条件
        if not primary_keys:
            primary_keys = columns
            logging.info(f"警告: 表 {table_name} 没有主键，将使用所有列进行比较，可能会影响性能")
        
        # 从数据库B中读取所有数据
        cursor_merge.execute(f"SELECT {columns_str} FROM {table_name}")
        rows = cursor_merge.fetchall()

        insert_table(base_path, merge_path, conn_base, table_name, columns, primary_keys, rows)


def insert_table(base_path, merge_path, conn_base: Connection, table_name, columns: list, primary_keys, rows):
    # 构建列名字符串
    columns_str = ', '.join(columns)
    placeholders = ', '.join(['?'] * len(columns))
    cursor_base = conn_base.cursor()

    # 插入数据
    count_inserted = 0
    count_skipped = 0
    for row in rows:
        try:
            # 构建WHERE条件用于检查记录是否存在
            where_condition = ' AND '.join([f"{key}=?" for key in primary_keys])
            primary_key_values = [row[columns.index(key)] for key in primary_keys]
            
            # 检查记录是否已存在
            check_sql = f"SELECT 1 FROM {table_name} WHERE {where_condition}"
            cursor_base.execute(check_sql, primary_key_values)
            
            if cursor_base.fetchone():
                count_skipped += 1
            else:
                # 插入新记录
                insert_sql = f"INSERT INTO {table_name} ({columns_str}) VALUES ({placeholders})"
                cursor_base.execute(insert_sql, row)
                logging.info(row)
                src = os.path.join(merge_path, row[columns.index("path")])
                dst = os.path.join(base_path, row[columns.index("path")])
                shutil.move(src, dst)
                count_inserted += 1
        except sqlite3.Error as e:
            logging.warning(f"处理表 {table_name} 时出错: {e}")
            continue

    logging.info(f"表 {table_name}: 插入了 {count_inserted} 条记录, 跳过了 {count_skipped} 条已存在的记录")


if __name__ == "__main__":
    # 使用示例
    conan_base_dir = os.path.join(os.path.expanduser('~'), ".conan2", "p")  # 主conan路径
    conan_merge_dir = os.path.join(os.path.expanduser('~'), ".conan2", "p_tomerge")  # 用来合并的conan路径
    
    try:
        merge_sqlite_databases(conan_base_dir, conan_merge_dir)
    except Exception as e:
        logging.info(f"合并过程中发生错误: {e}")