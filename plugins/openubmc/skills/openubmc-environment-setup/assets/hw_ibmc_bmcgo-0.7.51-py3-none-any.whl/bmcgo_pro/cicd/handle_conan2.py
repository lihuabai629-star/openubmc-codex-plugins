#!/usr/bin/env python3
# coding:utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
import sqlite3
import os
import logging

from bmcgo_pro.utils.tools import Tools

tools = Tools()


def handle_conan_recipes(base_path):
    tools.run_command("conan cache clean")
    db_path = os.path.join(base_path, "cache.sqlite3")
    # 检查文件是否存在
    if not os.path.exists(db_path):
        raise FileNotFoundError(f"数据库文件 不存在: {db_path}")

    # 连接数据库
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute(f"SELECT path FROM recipes")
        rows = cursor.fetchall()
        # 删除文件夹中的c文件
        tools.run_command(f"find {base_path}  -name '*.c' -type f -delete")
        for row in rows:
            conandata_file = os.path.join(base_path, row[0], "e/conandata.yml")
            conanmanifest_file = os.path.join(base_path, row[0], "e/conanmanifest.txt")
            #清理url
            tools.run_command(f"sed -i 's/url: [^[:space:]]*/url: null/g' {conandata_file}", ignore_error=True)
            conandata_md5_ret, _ = tools.pipe_command([f"md5sum {conandata_file}"], capture_output=True)
            new_data_md5 = conandata_md5_ret.split()[0]
            tools.run_command(
                f"sed -i 's/conandata.yml: [^[:space:]]*/conandata.yml: {new_data_md5}/g' {conanmanifest_file}",
                ignore_error=True,
            )
        # 关闭连接
        cursor.close()
    except sqlite3.Error as e:
        logging.error(f"处理过程中发生错误: {e}")
    finally:
        conn.close()


if __name__ == "__main__":
    # 使用示例
    conan_base_dir = os.path.join(os.path.expanduser('~'), ".conan2", "p")  # 主conan路径
    
    try:
        handle_conan_recipes(conan_base_dir)
    except Exception as e:
        logging.info(f"合并过程中发生错误: {e}")
