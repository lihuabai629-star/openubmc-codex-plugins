#!/usr/bin/python3
# coding: utf-8
# 版权所有 (c) 华为技术有限公司 2023-2023
import sys
import shutil
import os


def run():
    from bmcgo import misc

    shutil.rmtree(misc.CACHE_DIR, ignore_errors=True)
    os.makedirs(misc.CACHE_DIR)
    from bmcgo_pro.cli.cli import main

    sys.exit(main(sys.argv[1:]))


if __name__ == "__main__":
    run()
